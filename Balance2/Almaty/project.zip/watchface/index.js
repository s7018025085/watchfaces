import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { launchApp, SYSTEM_APP_CALENDAR, SYSTEM_APP_HR, SYSTEM_APP_SPORT, SYSTEM_APP_STATUS, SYSTEM_APP_WEATHER } from '@zos/router'
import { Time, Battery, Step, Calorie, Barometer, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _barometer = null;
let _heart = null;

// Dual scene runtime: Normal and AOD are both exported into this one watchface.
// Zepp OS controls visibility through the documented widget show_level property.
WatchFace({
  build() {
    const self = this;

    // Normal scene widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "chatgpt_image_21_sent_2026_g_2.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_fill_rect_001 = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 92, y: 322, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_0_fill_rect_001.setAlpha(255);
          const normal_w_1_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 322, w: 80, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_2_fill_rect_002 = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 150, y: 372, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_2_fill_rect_002.setAlpha(255);
          const normal_w_3_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 322, w: 70, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_4_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 360, y: 322, w: 70, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_5_fill_rect_003 = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 294, y: 372, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_5_fill_rect_003.setAlpha(255);
          const normal_w_6_time_hms_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 150, w: 480, h: 90, text_size: 80, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_7_fill_rect_004 = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 420, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_7_fill_rect_004.setAlpha(255);
          const normal_w_8_date_full_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 147, y: 368, w: 90, h: 40, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_9_altitude_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 290, y: 368, w: 90, h: 40, text_size: 26, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_10_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 226, y: 422, w: 80, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_11_weather_icon_001 = createWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 50, w: 64, h: 64, image_array: ["weather/0_cloudy.png", "weather/1_showers.png", "weather/2_snow_showers.png", "weather/3_sunny.png", "weather/4_overcast.png", "weather/5_light_rain.png", "weather/6_light_snow.png", "weather/7_moderate_rain.png", "weather/8_moderate_snow.png", "weather/9_heavy_snow.png", "weather/10_heavy_rain.png", "weather/11_sandstorm.png", "weather/12_rain_snow.png", "weather/13_fog.png", "weather/14_hazy.png", "weather/15_thunderstorm.png", "weather/16_snowstorm.png", "weather/17_floating_dust.png", "weather/18_very_heavy_rainstorm.png", "weather/19_rain_hail.png", "weather/20_thunderstorm_hail.png", "weather/21_heavy_rainstorm.png", "weather/22_dust.png", "weather/23_heavy_sandstorm.png", "weather/24_rainstorm.png", "weather/25_unknown.png", "weather/26_cloudy_night.png", "weather/27_showers_night.png", "weather/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 3, alpha: 255 });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 20, y: 100, w: 120, h: 40, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_tap_0_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 322, w: 80, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STATUS, native: true }); } catch (e) {} } });
          normal_tap_0_tap_001.setAlpha(0);
          const normal_tap_1_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 322, w: 70, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_HR, native: true }); } catch (e) {} } });
          normal_tap_1_tap_001.setAlpha(0);
          const normal_tap_2_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 360, y: 322, w: 70, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_SPORT, native: true }); } catch (e) {} } });
          normal_tap_2_tap_001.setAlpha(0);
          const normal_tap_3_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 150, w: 480, h: 90, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          normal_tap_3_tap_001.setAlpha(0);
          const normal_tap_4_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 147, y: 368, w: 90, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          normal_tap_4_tap_001.setAlpha(0);
          const normal_tap_5_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 50, w: 64, h: 64, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_5_tap_001.setAlpha(0);
          const normal_tap_6_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 20, y: 100, w: 120, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_6_tap_001.setAlpha(0);
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _barometer = new Barometer(); } catch (e) {}
          try { _heart = new HeartRate(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_6_time_hms_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", true) });
            normal_w_8_date_full_001.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_1_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_1_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heart ? _heart.getCurrent() : null;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_3_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_4_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_4_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _barometer ? _barometer.getAltitude() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_9_altitude_001.setProperty(prop.MORE, { text: "" + txt + " м" });
            } catch (e) { normal_w_9_altitude_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_10_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_10_battery_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_time_hms_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 0, y: 150, w: 480, h: 90, text_size: 80, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_time_hms_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", true) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
