# AOD Studio runtime export

This project exports Normal and AOD together into watchface/index.js. Both sets of widgets are created in the same WatchFace build; Normal uses show_level.ONLY_NORMAL and AOD uses show_level.ONLY_AOD. app.json enables watchface lockscreen/AOD support. The editor configuration aod-config.json is also included for round-trip editing.

Important: AOD support depends on the target Zepp OS firmware/device. The exporter does not claim unsupported widget APIs.
