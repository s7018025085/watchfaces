import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { setBrightness, getBrightness, setAutoBrightness, getAutoBrightness } from '@zos/display'
import { launchApp, SYSTEM_APP_CALENDAR, SYSTEM_APP_HR, SYSTEM_APP_STATUS, SYSTEM_APP_WEATHER } from '@zos/router'
import { Time, Battery, Step, HeartRate, Vibrator, VIBRATOR_SCENE_SHORT_LIGHT, VIBRATOR_SCENE_SHORT_MIDDLE, VIBRATOR_SCENE_SHORT_STRONG } from '@zos/sensor'
import { setInterval, clearInterval, setTimeout, clearTimeout } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// ---- Анимация текста (AmazFace): общий рантайм --------------------------------
var __TA = { list: [], all: [], timer: 0, paused: false };
var __taFx = {};
function __taClamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function __taEase(name, t) {
  t = __taClamp(t, 0, 1);
  if (name === 'in') return t * t * t;
  if (name === 'out') { var u = 1 - t; return 1 - u * u * u; }
  if (name === 'inout') return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  return t;
}
function __taMix(c1, c2, t) {
  var r = Math.round(((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
  var g = Math.round(((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
  var b = Math.round((c1 & 255) * (1 - t) + (c2 & 255) * t);
  return (r << 16) | (g << 8) | b;
}
function __taChars(s) {
  var out = [], i = 0, n, c;
  s = String(s == null ? '' : s);
  n = s.length;
  while (i < n) {
    c = s.charCodeAt(i);
    if (c >= 0xD800 && c <= 0xDBFF && i + 1 < n) { out.push(s.substr(i, 2)); i += 2; }
    else { out.push(s.charAt(i)); i += 1; }
  }
  return out;
}
function __taParseNum(s) {
  var m = /-?\d[\d,]*(?:\.\d+)?/.exec(String(s == null ? '' : s));
  if (!m) return null;
  var tok = m[0], clean = tok.replace(/,/g, ''), dot = clean.indexOf('.');
  return { pre: String(s).slice(0, m.index), post: String(s).slice(m.index + tok.length), val: parseFloat(clean), dec: dot >= 0 ? clean.length - dot - 1 : 0, sep: tok.indexOf(',') >= 0 };
}
function __taFmtNum(n, dec, sep) {
  var s = Math.abs(n).toFixed(dec), parts;
  if (sep) { parts = s.split('.'); parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ','); s = parts.join('.'); }
  return (n < 0 && parseFloat(s.replace(/,/g, '')) !== 0 ? '-' : '') + s;
}
function __taGroups(s) {
  var out = [], re = /\d+/g, m;
  s = String(s == null ? '' : s);
  while ((m = re.exec(s)) !== null) out.push({ i: m.index, s: m[0] });
  return out;
}
function __taPhase(a, el) {
  var c = a.cfg, d = c.delay || 0, dur = Math.max(1, a.durOv || c.dur), n = c.rep || 0, gap = c.pause || 0, t, cyc, rep, q, k;
  if (a.perp) return { k: 0, e: 0, ms: Math.max(0, el), rep: 0, done: false, hold: false };
  if (el < d) return { k: 0, e: __taEase(c.ease, 0), ms: 0, rep: 0, done: false, hold: true };
  t = el - d; cyc = dur + gap;
  if (t >= n * cyc + dur) return { k: 1, e: 1, ms: dur, rep: n, done: true, hold: false };
  rep = Math.floor(t / cyc); q = t - rep * cyc; k = q >= dur ? 1 : q / dur;
  return { k: k, e: __taEase(c.ease, k), ms: q >= dur ? dur : q, rep: rep, done: false, hold: false };
}
function __taFinal(a) {
  var s = { text: a.text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: true, alpha: 255 }, fx = __taFx[a.cfg.fx];
  if (fx.final) fx.final(a, s);
  return s;
}
function __taSample(a, el) {
  var ph = __taPhase(a, el), s = __taFinal(a), fx = __taFx[a.cfg.fx], o, key;
  if (ph.done) return { s: s, done: true, ph: ph };
  o = fx.frame(a, ph.k, ph);
  for (key in o) { if (Object.prototype.hasOwnProperty.call(o, key)) s[key] = o[key]; }
  return { s: s, done: false, ph: ph };
}
function __taAlpha(target, v) {
  var wd = target;
  if (!wd) return;
  try { wd.setAlpha(v); } catch (e) {}
}
function __taApply(a, s) {
  var o = {}, any = false, L = a.last, cut, tx = s.text, rest;
  if (a.cellLayout) {
    __taApplyCells(a, s);
    a.last = { text: tx, text2: null, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
    return;
  }
  if (a.w2) {
    cut = tx.indexOf(a.cfg.sep);
    rest = cut >= 0 ? tx.slice(cut + a.cfg.sep.length) : '';
    if (cut >= 0) tx = tx.slice(0, cut);
    if (rest !== L.text2) { try { a.w2.setProperty(prop.MORE, { text: rest }); } catch (e1) {} L.text2 = rest; }
  }
  if (tx !== L.text) { o.text = tx; any = true; }
  if (s.color !== L.color) { o.color = s.color; any = true; }
  if (s.x !== L.x) { o.x = s.x; any = true; }
  if (s.y !== L.y) { o.y = s.y; any = true; }
  if (s.size !== L.size) { o.text_size = s.size; any = true; }
  if (a.c && s.vis !== L.vis) { try { a.c.setProperty(prop.VISIBLE, s.vis); } catch (e2) {} }
  if (s.alpha !== L.alpha && s.alpha !== undefined) {
    __taAlpha(a.w, s.alpha); __taAlpha(a.w2, s.alpha); __taAlpha(a.c, s.alpha);
  }
  a.last = { text: tx, text2: L.text2, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
  if (any && a.w) { try { a.w.setProperty(prop.MORE, o); } catch (e3) {} }
}
function __taShow(a) { __taApply(a, __taFinal(a)); }
// Условия повторного запуска эффектов при изменении исходного текста.
// Для «Проявления» и «Пульсации размера» посимвольный режим дополнительно
// ограничивает сами стили изменившимися разрядами; остальные эффекты фильтруют запуск целиком.
function __taChangeAllowed(a, oldText, newText) {
  var mode = a.cfg.track || 'all', oldD, newD, i, off;
  if (mode === 'all') return true;
  if (mode === 'off') return false;
  oldD = String(oldText == null ? '' : oldText).replace(/[^0-9]/g, '');
  newD = String(newText == null ? '' : newText).replace(/[^0-9]/g, '');
  if (mode === 'changed') return oldD !== newD;
  if (mode === 'seconds' && !a.cfg.trackSec) return false;
  if (mode === 'units') off = 1;
  else if (mode === 'tens') off = 2;
  else if (mode === 'seconds') {
    for (i = 1; i <= 2; i++) {
      if (oldD.charAt(oldD.length - i) !== newD.charAt(newD.length - i)) return true;
    }
    return false;
  } else return true;
  if (oldD.length < off || newD.length < off) return false;
  return oldD.charAt(oldD.length - off) !== newD.charAt(newD.length - off);
}
// Определяет только цифры, которым разрешено анимироваться в посимвольных режимах.
function __taCharTargets(a, why) {
  var cur = __taChars(a.text), old = __taChars(a.prevText || ''), mode = a.cfg.track || 'all';
  var digits = [], target = {}, i, idx, off;
  for (i = 0; i < cur.length; i++) if (cur[i] >= '0' && cur[i] <= '9') digits.push(i);
  if (why === 'open') {
    if (mode === 'seconds' && a.cfg.trackSec) {
      off = Math.max(0, digits.length - 2);
      for (i = off; i < digits.length; i++) target[digits[i]] = true;
    } else if (mode === 'tens' || mode === 'units') {
      off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
      if (off >= 0) target[digits[off]] = true;
    } else if (mode === 'changed') {
      for (i = 0; i < digits.length; i++) target[digits[i]] = true;
    }
    return target;
  }
  if (why !== 'update' && why !== 'wake') return target;
  if (mode === 'seconds') {
    if (!a.cfg.trackSec) return target;
    off = Math.max(0, digits.length - 2);
    for (i = off; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else if (mode === 'tens' || mode === 'units') {
    off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
    if (off >= 0) { idx = digits[off]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else {
    for (i = 0; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  }
  return target;
}
function __taApplyCells(a, s) {
  var l = a.cellLayout, ws = l.widgets, chars = __taChars(s.text), n = ws.length;
  var count = Math.min(chars.length, n), gap = Number(l.gap || 0), total = 0, start, x, cellX, i, ch, col, size, o, prev, w, cw, scale, renderW, al, widths = [];
  // La anchura de composición siempre usa la métrica base para que una pulsación
  // no empuje las cifras vecinas. Solo se ensancha la celda animada, simétricamente.
  for (i = 0; i < count; i++) {
    ch = chars[i]; cw = Math.max(1, Number((l.charWidths && l.charWidths[ch]) || l.defaultWidth || 1));
    widths[i] = cw; total += cw;
  }
  if (count > 1) total += gap * (count - 1);
  if (l.align === 'LEFT') start = Number(l.x || 0);
  else if (l.align === 'RIGHT') start = Number(l.x || 0) + Number(l.w || 0) - total;
  else start = Number(l.x || 0) + Number(l.w || 0) / 2 - total / 2;
  x = start;
  if (!a.cellLast) a.cellLast = [];
  for (i = 0; i < n; i++) {
    ch = i < count ? chars[i] : '';
    cw = i < count ? widths[i] : Math.max(1, Number(l.defaultWidth || 1));
    col = s.charColors && s.charColors[i] != null ? s.charColors[i] : s.color;
    size = s.charSizes && s.charSizes[i] != null ? s.charSizes[i] : s.size;
    scale = a.base.size > 0 ? Math.max(1, Number(size || a.base.size) / a.base.size) : 1;
    renderW = Math.max(cw, Math.ceil(cw * scale));
    cellX = x - (renderW - cw) / 2;
    prev = a.cellLast[i] || { text: null, color: null, size: null, x: null, w: null, alpha: 255 };
    al = s.charAlphas && s.charAlphas[i] != null ? s.charAlphas[i] : (s.alpha == null ? 255 : s.alpha);
    o = {};
    if (ch !== prev.text) o.text = ch;
    if (col !== prev.color) o.color = col;
    if (size !== prev.size) o.text_size = size;
    if (Math.round(cellX) !== prev.x) o.x = Math.round(cellX);
    if (renderW !== prev.w) o.w = renderW;
    w = ws[i];
    if (Object.keys(o).length && w) { try { w.setProperty(prop.MORE, o); } catch (e) {} }
    if (al !== prev.alpha) __taAlpha(w, al);
    a.cellLast[i] = { text: ch, color: col, size: size, x: Math.round(cellX), w: renderW, alpha: al };
    x += cw + gap;
  }
}

function __taEnsure() {
  var ms = 1000, i;
  if (__TA.timer || !__TA.list.length) return;
  for (i = 0; i < __TA.list.length; i++) { if (__TA.list[i].step < ms) ms = __TA.list[i].step; }
  __TA.timer = setInterval(__taStep, Math.max(30, ms));
}
function __taDrop(a) {
  var i = __TA.list.indexOf(a);
  if (i >= 0) __TA.list.splice(i, 1);
  if (!__TA.list.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taStep() {
  var now = Date.now(), keep = [], i, a, r, fx;
  for (i = 0; i < __TA.list.length; i++) {
    a = __TA.list[i];
    r = __taSample(a, now - a.t0);
    fx = __taFx[a.cfg.fx];
    if (r.done) { a.on = false; if (fx.done) fx.done(a); __taShow(a); }
    else { __taApply(a, r.s); keep.push(a); }
  }
  __TA.list = keep;
  if (!keep.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taBegin(a, why) {
  var fx = __taFx[a.cfg.fx];
  a.durOv = 0;
  if (fx.init) fx.init(a, why);
  a.t0 = Date.now(); a.on = true; a.why = why;
}
function __taPlay(a, why) {
  var r;
  if (__TA.paused) return;
  if (a.on && a.cfg.retrig === 'ignore') return;
  __taBegin(a, why);
  r = __taSample(a, 0);
  __taApply(a, r.s);
  if (__TA.list.indexOf(a) < 0) __TA.list.push(a);
  __taEnsure();
}
function __taStop(a) { a.on = false; __taDrop(a); __taShow(a); }
function __taSetText(a, text) {
  var c = a.cfg, fx = __taFx[c.fx], old = a.text, changed;
  text = text == null ? '' : String(text);
  changed = text !== old;
  a.prevText = old;
  a.text = text;
  if (fx.live) { fx.live(a, old, text, changed); return; }
  if (!a.opened) {
    if (fx.can && !fx.can(a)) { __taShow(a); return; }
    a.opened = true;
    if (c.open) __taPlay(a, 'open'); else __taShow(a);
    return;
  }
  if (!changed) { if (!a.on) __taShow(a); return; }
  // Применяется одинаково ко всем эффектам с обработчиком изменения (в том числе
  // count/flash/flip, у которых специальная обработка обновления значения).
  // При проигнорированном изменении сразу показываем новое значение без старого кадра.
  if (!__taChangeAllowed(a, old, text)) { if (a.on) __taStop(a); else __taShow(a); return; }
  if (fx.onChange) { fx.onChange(a, old, text); return; }
  if (c.change && (!fx.can || fx.can(a))) { __taPlay(a, 'update'); return; }
  if (!a.on) __taShow(a);
}
function __taCreate(w, cfg, base, w2, cw, cellLayout) {
  var fx = __taFx[cfg.fx];
  var a = { w: w, w2: w2 || null, c: cw || null, cellLayout: cellLayout || null, cellLast: [], charMode: !!cfg.charMode || !!cellLayout, charTargets: null, cfg: cfg, base: base, text: '', prevText: '', t0: 0, on: false, opened: false, why: '', durOv: 0, perp: !!(fx.perp && cfg.iv < 1000), blink: 0, cnt: null, curV: null, fl: null, step: 50, last: { text: null, text2: null, color: base.fin, x: base.x, y: base.y, size: base.size, vis: true, alpha: 255 } };
  a.step = fx.step ? fx.step(cfg) : 50;
  __TA.all.push(a);
  return a;
}
function __taPause() {
  var i, a;
  __TA.paused = true;
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = [];
  for (i = 0; i < __TA.all.length; i++) { a = __TA.all[i]; a.on = false; __taShow(a); }
}
function __taResume() {
  var now = Date.now(), i, a, fx;
  __TA.paused = false;
  for (i = 0; i < __TA.all.length; i++) {
    a = __TA.all[i]; fx = __taFx[a.cfg.fx];
    if (!a.opened) continue;
    if (fx.resume) { fx.resume(a); continue; }
    if (a.cfg.wake && now - a.t0 > 800) __taPlay(a, 'wake');
  }
}
function __taDestroy() {
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = []; __TA.all = []; __TA.paused = false;
}

__taFx.reveal = {
  step: function () { return 50; },
  init: function (a, why) { if (a.charMode) a.charTargets = __taCharTargets(a, why); },
  frame: function (a, k, ph) {
    var colors, alphas, ch, i, al;
    if (a.cfg.ta) {
      // «Из прозрачного»: цвет сразу конечный, меняется только прозрачность 0 → 255.
      al = Math.round(255 * ph.e);
      if (a.charMode) {
        alphas = []; ch = __taChars(a.text);
        for (i = 0; i < ch.length; i++) alphas[i] = a.charTargets && a.charTargets[i] ? al : 255;
        return { charAlphas: alphas };
      }
      return { alpha: al };
    }
    if (a.charMode) {
      colors = []; ch = __taChars(a.text);
      for (i = 0; i < ch.length; i++) colors[i] = a.charTargets && a.charTargets[i] ? __taMix(a.cfg.c1, a.base.fin, ph.e) : null;
      return { charColors: colors };
    }
    return { color: __taMix(a.cfg.c1, a.base.fin, ph.e) };
  }
};


const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Dual scene runtime: Normal and AOD are both exported into this one watchface.
// Zepp OS controls visibility through the documented widget show_level property.
WatchFace({
  build() {
    const self = this;

    // Normal scene widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "oranzhevyy_tsiferblat.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 291, y: 270, w: 130, h: 50, text_size: 36, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_1_text_002 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 317, y: 328, w: 130, h: 50, text_size: 36, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_2_text_004 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 96, y: 222, w: 130, h: 40, text_size: 26, color: 0x000000, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 340, y: 106, w: 50, h: 40, text_size: 27, color: 0xf22c2c, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_HIGH, unit_type: 1 });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 284, y: 75, w: 120, h: 40, text_size: 32, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_w_5_weather_icon_001 = createWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 258, y: 55, w: 70, h: 70, image_array: ["weather/70x70/0_cloudy.png", "weather/70x70/1_showers.png", "weather/70x70/2_snow_showers.png", "weather/70x70/3_sunny.png", "weather/70x70/4_overcast.png", "weather/70x70/5_light_rain.png", "weather/70x70/6_light_snow.png", "weather/70x70/7_moderate_rain.png", "weather/70x70/8_moderate_snow.png", "weather/70x70/9_heavy_snow.png", "weather/70x70/10_heavy_rain.png", "weather/70x70/11_sandstorm.png", "weather/70x70/12_rain_snow.png", "weather/70x70/13_fog.png", "weather/70x70/14_hazy.png", "weather/70x70/15_thunderstorm.png", "weather/70x70/16_snowstorm.png", "weather/70x70/17_floating_dust.png", "weather/70x70/18_very_heavy_rainstorm.png", "weather/70x70/19_rain_hail.png", "weather/70x70/20_thunderstorm_hail.png", "weather/70x70/21_heavy_rainstorm.png", "weather/70x70/22_dust.png", "weather/70x70/23_heavy_sandstorm.png", "weather/70x70/24_rainstorm.png", "weather/70x70/25_unknown.png", "weather/70x70/26_cloudy_night.png", "weather/70x70/27_showers_night.png", "weather/70x70/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 4, alpha: 255 });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 278, y: 106, w: 50, h: 40, text_size: 27, color: 0x3366ff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_LOW, unit_type: 1 });
          const normal_w_7_text_003 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 279, y: 399, w: 50, h: 40, text_size: 26, color: 0x030100, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_8_triangle_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 264, y: 118, w: 12, h: 12, src: "triangle_triangle_001_2.png" });
          normal_w_8_triangle_001.setAlpha(255);
          const normal_w_9_triangle_002 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 328, y: 117, w: 12, h: 12, src: "triangle_triangle_002_2.png" });
          normal_w_9_triangle_002.setAlpha(255);
          const normal_w_10_text_005_w = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 205, y: 40, w: 70, h: 50, text_size: 50, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_200_rostex.regular.ttf", text: "" });
          const normal_w_10_text_005_a = __taCreate(normal_w_10_text_005_w, { fx: "reveal", dur: 800, delay: 600, ease: "out", rep: 0, pause: 500, retrig: "ignore", open: true, wake: true, change: false, track: "all", trackSec: false, charMode: false, c1: 0xbc552a, ta: 1 }, { x: 205, y: 40, color: 0x000000, fin: 0x000000, size: 50 });
          const normal_w_10_text_005 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_10_text_005_a, o.text); } else { normal_w_10_text_005_w.setProperty(k, o); } } };
          __taSetText(normal_w_10_text_005_a, "12");
          const normal_w_11_weekday_strip_001_marker_0_fill = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 262, y: 254, w: 18, h: 2, radius: 8, color: 0xe50134 });
          normal_w_11_weekday_strip_001_marker_0_fill.setAlpha(255);
          normal_w_11_weekday_strip_001_marker_0_fill.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_marker_1_fill = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 288, y: 254, w: 18, h: 2, radius: 8, color: 0xe50134 });
          normal_w_11_weekday_strip_001_marker_1_fill.setAlpha(255);
          normal_w_11_weekday_strip_001_marker_1_fill.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_marker_2_fill = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 313, y: 254, w: 18, h: 2, radius: 8, color: 0xe50134 });
          normal_w_11_weekday_strip_001_marker_2_fill.setAlpha(255);
          normal_w_11_weekday_strip_001_marker_2_fill.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_marker_3_fill = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 339, y: 254, w: 18, h: 2, radius: 8, color: 0xe50134 });
          normal_w_11_weekday_strip_001_marker_3_fill.setAlpha(255);
          normal_w_11_weekday_strip_001_marker_3_fill.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_marker_4_fill = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 365, y: 254, w: 18, h: 2, radius: 8, color: 0xe50134 });
          normal_w_11_weekday_strip_001_marker_4_fill.setAlpha(255);
          normal_w_11_weekday_strip_001_marker_4_fill.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_marker_5_fill = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 391, y: 254, w: 18, h: 2, radius: 8, color: 0xe50134 });
          normal_w_11_weekday_strip_001_marker_5_fill.setAlpha(255);
          normal_w_11_weekday_strip_001_marker_5_fill.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_marker_6_fill = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 416, y: 254, w: 18, h: 2, radius: 8, color: 0xe50134 });
          normal_w_11_weekday_strip_001_marker_6_fill.setAlpha(255);
          normal_w_11_weekday_strip_001_marker_6_fill.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_text_0 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 258, y: 223, w: 26, h: 40, text: "ПН", text_size: 15, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V });
          const normal_w_11_weekday_strip_001_active_text_0 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 258, y: 223, w: 26, h: 40, text: "ПН", text_size: 15, color: 0xe50134, align_h: align.CENTER_H, align_v: align.CENTER_V });
          normal_w_11_weekday_strip_001_active_text_0.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_text_1 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 284, y: 223, w: 26, h: 40, text: "ВТ", text_size: 15, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V });
          const normal_w_11_weekday_strip_001_active_text_1 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 284, y: 223, w: 26, h: 40, text: "ВТ", text_size: 15, color: 0xe50134, align_h: align.CENTER_H, align_v: align.CENTER_V });
          normal_w_11_weekday_strip_001_active_text_1.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_text_2 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 309, y: 223, w: 26, h: 40, text: "СР", text_size: 15, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V });
          const normal_w_11_weekday_strip_001_active_text_2 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 309, y: 223, w: 26, h: 40, text: "СР", text_size: 15, color: 0xe50134, align_h: align.CENTER_H, align_v: align.CENTER_V });
          normal_w_11_weekday_strip_001_active_text_2.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_text_3 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 335, y: 223, w: 26, h: 40, text: "ЧТ", text_size: 15, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V });
          const normal_w_11_weekday_strip_001_active_text_3 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 335, y: 223, w: 26, h: 40, text: "ЧТ", text_size: 15, color: 0xe50134, align_h: align.CENTER_H, align_v: align.CENTER_V });
          normal_w_11_weekday_strip_001_active_text_3.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_text_4 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 361, y: 223, w: 26, h: 40, text: "ПТ", text_size: 15, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V });
          const normal_w_11_weekday_strip_001_active_text_4 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 361, y: 223, w: 26, h: 40, text: "ПТ", text_size: 15, color: 0xe50134, align_h: align.CENTER_H, align_v: align.CENTER_V });
          normal_w_11_weekday_strip_001_active_text_4.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_text_5 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 387, y: 223, w: 26, h: 40, text: "СБ", text_size: 15, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V });
          const normal_w_11_weekday_strip_001_active_text_5 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 387, y: 223, w: 26, h: 40, text: "СБ", text_size: 15, color: 0xe50134, align_h: align.CENTER_H, align_v: align.CENTER_V });
          normal_w_11_weekday_strip_001_active_text_5.setProperty(prop.VISIBLE, false);
          const normal_w_11_weekday_strip_001_text_6 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 412, y: 223, w: 26, h: 40, text: "ВС", text_size: 15, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V });
          const normal_w_11_weekday_strip_001_active_text_6 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 412, y: 223, w: 26, h: 40, text: "ВС", text_size: 15, color: 0xe50134, align_h: align.CENTER_H, align_v: align.CENTER_V });
          normal_w_11_weekday_strip_001_active_text_6.setProperty(prop.VISIBLE, false);
          let normal_w_11_weekday_strip_001_last_weekday = -1;
          const normal_w_12_text_006_w = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 120, y: 70, w: 70, h: 50, text_size: 50, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_200_rostex.regular.ttf", text: "" });
          const normal_w_12_text_006_a = __taCreate(normal_w_12_text_006_w, { fx: "reveal", dur: 800, delay: 500, ease: "out", rep: 0, pause: 500, retrig: "ignore", open: true, wake: true, change: false, track: "all", trackSec: false, charMode: false, c1: 0xa54828, ta: 1 }, { x: 120, y: 70, color: 0x000000, fin: 0x000000, size: 50 });
          const normal_w_12_text_006 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_12_text_006_a, o.text); } else { normal_w_12_text_006_w.setProperty(k, o); } } };
          __taSetText(normal_w_12_text_006_a, "11");
          const normal_w_13_text_007_w = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 68, y: 130, w: 70, h: 50, text_size: 50, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_200_rostex.regular.ttf", text: "" });
          const normal_w_13_text_007_a = __taCreate(normal_w_13_text_007_w, { fx: "reveal", dur: 800, delay: 400, ease: "out", rep: 0, pause: 500, retrig: "ignore", open: true, wake: true, change: false, track: "all", trackSec: false, charMode: false, c1: 0x8c3c22, ta: 1 }, { x: 68, y: 130, color: 0x000000, fin: 0x000000, size: 50 });
          const normal_w_13_text_007 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_13_text_007_a, o.text); } else { normal_w_13_text_007_w.setProperty(k, o); } } };
          __taSetText(normal_w_13_text_007_a, "10");
          const normal_w_14_text_008_w = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 63, y: 303, w: 70, h: 50, text_size: 50, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_200_rostex.regular.ttf", text: "" });
          const normal_w_14_text_008_a = __taCreate(normal_w_14_text_008_w, { fx: "reveal", dur: 800, delay: 200, ease: "out", rep: 0, pause: 500, retrig: "ignore", open: true, wake: true, change: false, track: "all", trackSec: false, charMode: false, c1: 0xc85a2c, ta: 1 }, { x: 63, y: 303, color: 0x000000, fin: 0x000000, size: 50 });
          const normal_w_14_text_008 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_14_text_008_a, o.text); } else { normal_w_14_text_008_w.setProperty(k, o); } } };
          __taSetText(normal_w_14_text_008_a, "8");
          const normal_w_15_text_009_w = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 123, y: 368, w: 70, h: 50, text_size: 50, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_200_rostex.regular.ttf", text: "" });
          const normal_w_15_text_009_a = __taCreate(normal_w_15_text_009_w, { fx: "reveal", dur: 800, delay: 100, ease: "out", rep: 0, pause: 500, retrig: "ignore", open: true, wake: true, change: false, track: "all", trackSec: false, charMode: false, c1: 0xf1702f, ta: 1 }, { x: 123, y: 368, color: 0x000000, fin: 0x000000, size: 50 });
          const normal_w_15_text_009 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_15_text_009_a, o.text); } else { normal_w_15_text_009_w.setProperty(k, o); } } };
          __taSetText(normal_w_15_text_009_a, "7");
          const normal_w_16_text_010_w = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 350, y: 137, w: 70, h: 50, text_size: 50, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_200_rostex.regular.ttf", text: "" });
          const normal_w_16_text_010_a = __taCreate(normal_w_16_text_010_w, { fx: "reveal", dur: 800, delay: 700, ease: "out", rep: 0, pause: 500, retrig: "ignore", open: true, wake: true, change: false, track: "all", trackSec: false, charMode: false, c1: 0xf97a2e, ta: 1 }, { x: 350, y: 137, color: 0x000000, fin: 0x000000, size: 50 });
          const normal_w_16_text_010 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_16_text_010_a, o.text); } else { normal_w_16_text_010_w.setProperty(k, o); } } };
          __taSetText(normal_w_16_text_010_a, "2");
          const normal_w_17_text_013 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 240, y: 186, w: 200, h: 50, text_size: 49, color: 0x171717, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_200_rostex.regular.ttf", text: "" });
          const normal_w_18_text_011_w = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 204, y: 390, w: 70, h: 50, text_size: 50, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_200_rostex.regular.ttf", text: "" });
          const normal_w_18_text_011_a = __taCreate(normal_w_18_text_011_w, { fx: "reveal", dur: 800, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "ignore", open: true, wake: true, change: false, track: "all", trackSec: false, charMode: false, c1: 0xf87329, ta: 1 }, { x: 204, y: 390, color: 0x000000, fin: 0x000000, size: 50 });
          const normal_w_18_text_011 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_18_text_011_a, o.text); } else { normal_w_18_text_011_w.setProperty(k, o); } } };
          __taSetText(normal_w_18_text_011_a, "6");
          const normal_w_19_text_012_w = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 33, y: 217, w: 70, h: 50, text_size: 50, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_200_rostex.regular.ttf", text: "" });
          const normal_w_19_text_012_a = __taCreate(normal_w_19_text_012_w, { fx: "reveal", dur: 800, delay: 300, ease: "out", rep: 0, pause: 500, retrig: "ignore", open: true, wake: true, change: false, track: "all", trackSec: false, charMode: false, c1: 0x9e4425, ta: 1 }, { x: 33, y: 217, color: 0x000000, fin: 0x000000, size: 50 });
          const normal_w_19_text_012 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_19_text_012_a, o.text); } else { normal_w_19_text_012_w.setProperty(k, o); } } };
          __taSetText(normal_w_19_text_012_a, "9");
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 32, hour_posY: 178, hour_path: "oranzhevyy_tsiferblat_2.png" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 27, minute_posY: 215, minute_path: "oranzhevyy.png" });
          // Секундная стрелка: плавный ход не подтверждён официальной документацией
          // (⚠ unverified) — отдельный IMG сохраняет порядок слоя.
          const normal_w_second_smooth_214 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "oranzhevyy_tsiferblat_i.png", pos_x: 209, pos_y: 5, center_x: 240, center_y: 240 });
          const normal_tap_0_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 291, y: 270, w: 130, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STATUS, native: true }); } catch (e) {} } });
          normal_tap_0_tap_001.setAlpha(0);
          const normal_tap_1_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 317, y: 328, w: 130, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_HR, native: true }); } catch (e) {} } });
          normal_tap_1_tap_001.setAlpha(0);
          const normal_tap_2_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 96, y: 222, w: 130, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          normal_tap_2_tap_001.setAlpha(0);
          const normal_tap_3_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 284, y: 75, w: 120, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_3_tap_001.setAlpha(0);
          const normal_tap_4_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 258, y: 55, w: 64, h: 64, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_4_tap_001.setAlpha(0);
          const normal_tap_5_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 279, y: 399, w: 140, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_normal_(!__flashOn_normal_); } catch (e) {} } });
          normal_tap_5_tap_001.setAlpha(0);
          const normal_tap_6_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 63, y: 303, w: 70, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afOpenSettings(); } catch (e) {} } });
          normal_tap_6_tap_001.setAlpha(0);
          let __flashOn_normal_ = false;
          const __flash_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0xffffff });
          const __flashBtn_normal_ = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_normal_(false); } catch (e) {} } });
          __flashBtn_normal_.setAlpha(0);
          let __flashSaved_normal_ = null;
          function __flashBr_normal_(on) {
            try {
              if (on) {
                if (__flashSaved_normal_) return;
                __flashSaved_normal_ = { auto: !!getAutoBrightness(), level: getBrightness() };
                setAutoBrightness({ autoBright: false });
                setBrightness({ brightness: 100 });
              } else if (__flashSaved_normal_) {
                const s = __flashSaved_normal_;
                __flashSaved_normal_ = null;
                if (typeof s.level === 'number') setBrightness({ brightness: s.level });
                setAutoBrightness({ autoBright: s.auto });
              }
            } catch (e) {}
          }
          function __flashSet_normal_(on) {
            try {
              __flashOn_normal_ = !!on;
              __flash_normal_.setProperty(prop.VISIBLE, __flashOn_normal_);
              __flashBtn_normal_.setProperty(prop.VISIBLE, __flashOn_normal_);
            } catch (e) {}
            try { __flashBr_normal_(__flashOn_normal_); } catch (e) {}
          }
          __flashSet_normal_(false);
          self._flashOffs = self._flashOffs || [];
          self._flashOffs.push(() => __flashSet_normal_(false));
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            createWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} try { const fo = self._flashOffs || []; for (let i = 0; i < fo.length; i++) { try { fo[i](); } catch (e) {} } } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_2_text_004.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
            { const _wd = ((now.getDay() + 6) % 7); if (normal_w_11_weekday_strip_001_last_weekday !== _wd) { normal_w_11_weekday_strip_001_last_weekday = _wd; normal_w_11_weekday_strip_001_marker_0_fill.setProperty(prop.VISIBLE, _wd === 0); normal_w_11_weekday_strip_001_marker_1_fill.setProperty(prop.VISIBLE, _wd === 1); normal_w_11_weekday_strip_001_marker_2_fill.setProperty(prop.VISIBLE, _wd === 2); normal_w_11_weekday_strip_001_marker_3_fill.setProperty(prop.VISIBLE, _wd === 3); normal_w_11_weekday_strip_001_marker_4_fill.setProperty(prop.VISIBLE, _wd === 4); normal_w_11_weekday_strip_001_marker_5_fill.setProperty(prop.VISIBLE, _wd === 5); normal_w_11_weekday_strip_001_marker_6_fill.setProperty(prop.VISIBLE, _wd === 6); normal_w_11_weekday_strip_001_text_0.setProperty(prop.VISIBLE, _wd !== 0); normal_w_11_weekday_strip_001_active_text_0.setProperty(prop.VISIBLE, _wd === 0); normal_w_11_weekday_strip_001_text_1.setProperty(prop.VISIBLE, _wd !== 1); normal_w_11_weekday_strip_001_active_text_1.setProperty(prop.VISIBLE, _wd === 1); normal_w_11_weekday_strip_001_text_2.setProperty(prop.VISIBLE, _wd !== 2); normal_w_11_weekday_strip_001_active_text_2.setProperty(prop.VISIBLE, _wd === 2); normal_w_11_weekday_strip_001_text_3.setProperty(prop.VISIBLE, _wd !== 3); normal_w_11_weekday_strip_001_active_text_3.setProperty(prop.VISIBLE, _wd === 3); normal_w_11_weekday_strip_001_text_4.setProperty(prop.VISIBLE, _wd !== 4); normal_w_11_weekday_strip_001_active_text_4.setProperty(prop.VISIBLE, _wd === 4); normal_w_11_weekday_strip_001_text_5.setProperty(prop.VISIBLE, _wd !== 5); normal_w_11_weekday_strip_001_active_text_5.setProperty(prop.VISIBLE, _wd === 5); normal_w_11_weekday_strip_001_text_6.setProperty(prop.VISIBLE, _wd !== 6); normal_w_11_weekday_strip_001_active_text_6.setProperty(prop.VISIBLE, _wd === 6); } }
            normal_w_17_text_013.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_0_text_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_0_text_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 26) ? String(v) : '--';
              normal_w_1_text_002.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_1_text_002.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_7_text_003.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "% " : '--') });
            } catch (e) { normal_w_7_text_003.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
          self._smoothTimerNormal = setInterval(() => {
            try {
              const now = _time ? new Date(_time.getTime()) : new Date();
              let deg = (now.getSeconds() + now.getMilliseconds() / 1000) * 6;
              normal_w_second_smooth_214.setProperty(prop.MORE, { angle: deg });
            } catch (e) {
              if (self._smoothTimerNormal) { clearInterval(self._smoothTimerNormal); self._smoothTimerNormal = null; }
            }
          }, 26);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_text_013 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 240, y: 186, w: 200, h: 50, text_size: 49, color: 0xf58438, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_200_rostex.regular.ttf", text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_text_013.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
// Runtime settings panel. Preferences live in the watchface's own hmFS data file.
    const __afSettingsPath = "amazface_settings_4069837_1793084307590.json";
    const __afPanelW = 480;
    const __afPanelH = 480;
    const __afHourlyPrefs = {
      hourlyEnabled: false,
      nightQuiet: true, nightStart: 22, nightEnd: 7,
      napQuiet: false, napStart: 13, napEnd: 14,
      strength: 1,
    };
    function __afNormalizePrefs(value) {
      if (!value || typeof value !== 'object') return;
      if (typeof value.hourlyEnabled === 'boolean') __afHourlyPrefs.hourlyEnabled = value.hourlyEnabled;
      if (typeof value.nightQuiet === 'boolean') __afHourlyPrefs.nightQuiet = value.nightQuiet;
      if (typeof value.napQuiet === 'boolean') __afHourlyPrefs.napQuiet = value.napQuiet;
      ['nightStart', 'nightEnd', 'napStart', 'napEnd'].forEach(function (key) {
        const n = Number(value[key]);
        if (n >= 0 && n <= 23 && Math.floor(n) === n) __afHourlyPrefs[key] = n;
      });
      const strength = Number(value.strength);
      if (strength >= 0 && strength <= 2 && Math.floor(strength) === strength) __afHourlyPrefs.strength = strength;
    }
    function __afLoadPrefs() {
      try {
        const result = hmFS.stat(__afSettingsPath);
        if (!result || result[1] !== 0 || !result[0] || result[0].size <= 0 || result[0].size > 1024) return;
        const file = hmFS.open(__afSettingsPath, hmFS.O_RDONLY);
        if (typeof file !== 'number' || file < 0) return;
        try {
          const bytes = new Uint8Array(result[0].size);
          hmFS.read(file, bytes.buffer, 0, bytes.length);
          __afNormalizePrefs(JSON.parse(String.fromCharCode.apply(null, bytes)));
        } finally { hmFS.close(file); }
      } catch (e) {}
    }
    function __afSavePrefs() {
      let file = -1;
      try {
        const raw = JSON.stringify(__afHourlyPrefs);
        const bytes = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) & 255;
        file = hmFS.open(__afSettingsPath, hmFS.O_RDWR | hmFS.O_CREAT | hmFS.O_TRUNC);
        if (typeof file === 'number' && file >= 0) hmFS.write(file, bytes.buffer, 0, bytes.length);
      } catch (e) {
      } finally {
        try { if (file >= 0) hmFS.close(file); } catch (e) {}
      }
    }
    __afLoadPrefs();

    const __afPanelScale = Math.min(__afPanelW, __afPanelH) / 480;
    const __afPanelPad = Math.max(8, Math.round(18 * __afPanelScale));
    const __afPanelSafePad = Math.max(6, Math.round(12 * __afPanelScale));
    const __afPanelHeaderH = Math.min(__afPanelH, Math.max(28, Math.round(44 * __afPanelScale)));
    const __afPanelBottomPad = Math.max(12, Math.round(30 * __afPanelScale));
    const __afPanelRowH = Math.max(16, Math.min(
      Math.max(18, Math.round(38 * __afPanelScale)),
      Math.floor((__afPanelH - __afPanelHeaderH - __afPanelPad - __afPanelBottomPad) / 10)
    ));
    const __afPanelHeight = Math.min(__afPanelH, __afPanelHeaderH + 10 * __afPanelRowH + __afPanelPad + __afPanelBottomPad);
    const __afPanelTop = __afPanelH - __afPanelHeight;
    const __afPanelRowY = __afPanelTop + __afPanelHeaderH + __afPanelPad;
    const __afPanelFont = Math.max(12, Math.min(Math.round(20 * __afPanelScale), Math.round((__afPanelRowH - 2) * 0.62)));
    const __afPanelStepW = Math.max(24, Math.round(46 * __afPanelScale));
    let __afPanelVisible = false;
    let __afPanelPage = 0;
    function __afPanelCircleInset(y) {
      const halfW = __afPanelW / 2;
      const halfH = __afPanelH / 2;
      const normalized = Math.max(-1, Math.min(1, (y - halfH) / Math.max(1, halfH)));
      return halfW * (1 - Math.sqrt(Math.max(0, 1 - normalized * normalized)));
    }
    function __afPanelRowBox(y, height) {
      const inset = Math.max(__afPanelCircleInset(y), __afPanelCircleInset(y + height));
      const x = Math.ceil(inset + __afPanelSafePad);
      const right = Math.floor(__afPanelW - inset - __afPanelSafePad);
      return { x: x, w: Math.max(1, right - x) };
    }
    function __afPanelSetVisible(w, visible) { w.setProperty(prop.VISIBLE, !!visible); }
    function __afPanelSetText(w, text, x, y, width, height) {
      w.setProperty(prop.MORE, { x: x, y: y, w: width, h: height, text: text });
    }
    function __afPanelSetRowText(w, text, y, height) {
      const box = __afPanelRowBox(y, height);
      __afPanelSetText(w, text, box.x, y, box.w, height);
    }
    function __afPanelButton(x, y, width, height, text, click) {
      const w = createWidget(widget.BUTTON, {
        show_level: show_level.ONLY_NORMAL,
        x: x, y: y, w: width, h: height, text: text,
        color: 0xffffff, text_size: __afPanelFont,
        normal_color: 0x253140, press_color: 0x3a4b60,
        radius: Math.max(4, Math.round(8 * __afPanelScale)),
        click_func: click,
      });
      __afPanelSetVisible(w, false);
      return w;
    }
    function __afPanelHour(value) { return (value < 10 ? '0' : '') + value + ':00'; }
    function __afPanelTimeRow(label, key, row, items) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const stepW = Math.min(__afPanelStepW, Math.max(20, Math.floor((box.w - 8) / 3)));
      const midW = Math.max(1, box.w - 2 * stepW - 4);
      const minus = __afPanelButton(box.x, y, stepW, h, '−', function () {
        __afHourlyPrefs[key] = (__afHourlyPrefs[key] + 23) % 24;
        __afSavePrefs(); __afPanelRefresh();
      });
      const value = __afPanelButton(box.x + stepW + 2, y, midW, h, label, function () {});
      const plus = __afPanelButton(box.x + box.w - stepW, y, stepW, h, '+', function () {
        __afHourlyPrefs[key] = (__afHourlyPrefs[key] + 1) % 24;
        __afSavePrefs(); __afPanelRefresh();
      });
      items.push(minus, value, plus);
      return { value: value, x: box.x + stepW + 2, y: y, w: midW, h: h };
    }
    function __afPanelRowButton(y, text, click) {
      const h = __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      return __afPanelButton(box.x, y, box.w, h, text, click);
    }

    // The transparent screen-sized button makes the lower sheet modal while it is open.
    const __afPanelScrim = createWidget(widget.BUTTON, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: 0, w: __afPanelW, h: __afPanelH, text: '',
      normal_src: '', press_src: '', click_func: function () {},
    });
    __afPanelScrim.setAlpha(0);
    __afPanelSetVisible(__afPanelScrim, false);
    const __afPanelBg = createWidget(widget.FILL_RECT, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: __afPanelTop, w: __afPanelW, h: __afPanelHeight, color: 0x111923,
    });
    __afPanelSetVisible(__afPanelBg, false);
    const __afPanelHeaderY = __afPanelTop + 2;
    const __afPanelHeaderInnerH = Math.max(20, __afPanelHeaderH - 4);
    const __afPanelHeaderBox = __afPanelRowBox(__afPanelHeaderY, __afPanelHeaderInnerH);
    const __afPanelCloseSize = Math.min(__afPanelHeaderInnerH, Math.max(24, Math.round(40 * __afPanelScale)));
    const __afPanelTitle = __afPanelButton(__afPanelHeaderBox.x, __afPanelHeaderY, Math.max(1, __afPanelHeaderBox.w - __afPanelCloseSize - 4), __afPanelHeaderInnerH, 'Настройки циферблата', function () {});
    const __afPanelClose = __afPanelButton(__afPanelHeaderBox.x + __afPanelHeaderBox.w - __afPanelCloseSize, __afPanelHeaderY, __afPanelCloseSize, __afPanelHeaderInnerH, '×', function () {
      __afPanelVisible = false; __afPanelRefresh();
    });
    let __afVibTestStatus = '';
    // Тестовый режим: вибрация раз в минуту, без «тишины». Нарочно не сохраняется
    // в файл — после перезапуска циферблата он снова выключен.
    let __afMinuteTest = false;
    const __afPanelMenu = __afPanelRowButton(__afPanelRowY, 'Почасовая вибрация  ›', function () {
      __afPanelPage = 1; __afVibTestStatus = ''; __afPanelRefresh();
    });
    const __afMinuteToggle = __afPanelRowButton(__afPanelRowY + __afPanelRowH, '', function () {
      __afMinuteTest = !__afMinuteTest;
      __afHourlyControllerRefresh(); __afPanelRefresh();
    });
    const __afVibrationDetails = [];
    const __afHourlyToggle = __afPanelRowButton(__afPanelRowY, '', function () {
      __afHourlyPrefs.hourlyEnabled = !__afHourlyPrefs.hourlyEnabled;
      __afHourlyControllerRefresh();
      __afSavePrefs(); __afPanelRefresh();
    });
    __afVibrationDetails.push(__afHourlyToggle);
    const __afNightToggle = __afPanelRowButton(__afPanelRowY + __afPanelRowH, '', function () {
      __afHourlyPrefs.nightQuiet = !__afHourlyPrefs.nightQuiet;
      __afSavePrefs(); __afPanelRefresh();
    });
    __afVibrationDetails.push(__afNightToggle);
    const __afNightStart = __afPanelTimeRow('Ночь с 22:00', 'nightStart', 2, __afVibrationDetails);
    const __afNightEnd = __afPanelTimeRow('Ночь до 07:00', 'nightEnd', 3, __afVibrationDetails);
    const __afNapToggle = __afPanelRowButton(__afPanelRowY + 4 * __afPanelRowH, '', function () {
      __afHourlyPrefs.napQuiet = !__afHourlyPrefs.napQuiet;
      __afSavePrefs(); __afPanelRefresh();
    });
    __afVibrationDetails.push(__afNapToggle);
    const __afNapStart = __afPanelTimeRow('Сон с 13:00', 'napStart', 5, __afVibrationDetails);
    const __afNapEnd = __afPanelTimeRow('Сон до 14:00', 'napEnd', 6, __afVibrationDetails);
    const __afStrength = __afPanelRowButton(__afPanelRowY + 7 * __afPanelRowH, '', function () {
      __afHourlyPrefs.strength = (__afHourlyPrefs.strength + 1) % 3;
      __afSavePrefs(); __afPanelRefresh();
    });
    __afVibrationDetails.push(__afStrength);
    // Проверка идёт тем же путём (__afVibrate), что и почасовой сигнал, но игнорирует
    // «тишину» и переключатель почасовой вибрации. Результат пишется в подпись кнопки.
    const __afVibTest = __afPanelRowButton(__afPanelRowY + 8 * __afPanelRowH, '', function () {
      const error = __afVibrate(__afHourlyPrefs.strength);
      __afVibTestStatus = error ? 'ошибка ' + String(error).slice(0, 16) : 'отправлено';
      __afPanelRefresh();
    });
    __afVibrationDetails.push(__afVibTest);
    const __afPanelBack = __afPanelRowButton(__afPanelRowY + 9 * __afPanelRowH, '‹ Назад', function () {
      __afPanelPage = 0; __afVibTestStatus = ''; __afPanelRefresh();
    });
    __afVibrationDetails.push(__afPanelBack);
    function __afPanelRefresh() {
      __afPanelSetVisible(__afPanelScrim, __afPanelVisible);
      __afPanelSetVisible(__afPanelBg, __afPanelVisible);
      __afPanelSetVisible(__afPanelTitle, __afPanelVisible);
      __afPanelSetVisible(__afPanelClose, __afPanelVisible);
      __afPanelSetVisible(__afPanelMenu, __afPanelVisible && __afPanelPage === 0);
      __afPanelSetVisible(__afMinuteToggle, __afPanelVisible && __afPanelPage === 0);
      __afVibrationDetails.forEach(function (w) { __afPanelSetVisible(w, __afPanelVisible && __afPanelPage === 1); });
      __afPanelSetText(__afPanelTitle, __afPanelPage === 0 ? 'Настройки циферблата' : 'Почасовая вибрация', __afPanelHeaderBox.x, __afPanelHeaderY, Math.max(1, __afPanelHeaderBox.w - __afPanelCloseSize - 4), __afPanelHeaderInnerH);
      __afPanelSetRowText(__afPanelMenu, 'Почасовая вибрация  ›', __afPanelRowY, __afPanelRowH - 2);
      __afPanelSetRowText(__afMinuteToggle, 'Тест каждую минуту: ' + (__afMinuteTest ? 'ВКЛ' : 'ВЫКЛ'), __afPanelRowY + __afPanelRowH, __afPanelRowH - 2);
      __afPanelSetRowText(__afHourlyToggle, 'Почасовая вибрация: ' + (__afHourlyPrefs.hourlyEnabled ? 'ВКЛ' : 'ВЫКЛ'), __afPanelRowY, __afPanelRowH - 2);
      __afPanelSetRowText(__afNightToggle, 'Ночная тишина: ' + (__afHourlyPrefs.nightQuiet ? 'ВКЛ' : 'ВЫКЛ'), __afPanelRowY + __afPanelRowH, __afPanelRowH - 2);
      __afPanelSetText(__afNightStart.value, 'Ночь с ' + __afPanelHour(__afHourlyPrefs.nightStart), __afNightStart.x, __afNightStart.y, __afNightStart.w, __afNightStart.h);
      __afPanelSetText(__afNightEnd.value, 'Ночь до ' + __afPanelHour(__afHourlyPrefs.nightEnd), __afNightEnd.x, __afNightEnd.y, __afNightEnd.w, __afNightEnd.h);
      __afPanelSetRowText(__afNapToggle, 'Дневной сон: ' + (__afHourlyPrefs.napQuiet ? 'ВКЛ' : 'ВЫКЛ'), __afPanelRowY + 4 * __afPanelRowH, __afPanelRowH - 2);
      __afPanelSetText(__afNapStart.value, 'Сон с ' + __afPanelHour(__afHourlyPrefs.napStart), __afNapStart.x, __afNapStart.y, __afNapStart.w, __afNapStart.h);
      __afPanelSetText(__afNapEnd.value, 'Сон до ' + __afPanelHour(__afHourlyPrefs.napEnd), __afNapEnd.x, __afNapEnd.y, __afNapEnd.w, __afNapEnd.h);
      const strengths = ['низкая', 'средняя', 'высокая'];
      __afPanelSetRowText(__afStrength, 'Сила вибрации: ' + strengths[__afHourlyPrefs.strength], __afPanelRowY + 7 * __afPanelRowH, __afPanelRowH - 2);
      __afPanelSetRowText(__afVibTest, __afVibTestStatus ? 'Проверка: ' + __afVibTestStatus : 'Проверить вибрацию', __afPanelRowY + 8 * __afPanelRowH, __afPanelRowH - 2);
      __afPanelSetRowText(__afPanelBack, '‹ Назад', __afPanelRowY + 9 * __afPanelRowH, __afPanelRowH - 2);
    }
    function __afOpenSettings() {
      __afPanelVisible = true; __afPanelPage = 0; __afPanelRefresh();
    }
    __afPanelRefresh();
// Один общий контроллер: определяет Normal/AOD и не даёт двум сценам задвоить сигнал.
    let __afHourlyVibrator = null;
    let __afHourlyVibratorLegacy = false;
    let __afHourlyLastKey = null;
    let __afMinuteLastKey = null;
    // Возвращает '' при успехе или короткий текст ошибки.
    function __afVibrate(strength) {
      try {
        if (!__afHourlyVibrator) {
          if (typeof Vibrator === 'function') {
            try { __afHourlyVibrator = new Vibrator(); __afHourlyVibratorLegacy = false; } catch (e) { __afHourlyVibrator = null; }
          }
          if (!__afHourlyVibrator && typeof hmSensor !== 'undefined') {
            __afHourlyVibrator = hmSensor.createSensor(hmSensor.id.VIBRATE);
            __afHourlyVibratorLegacy = true;
          }
          if (!__afHourlyVibrator) return 'нет API вибрации';
          self._hourlyVibrator = __afHourlyVibrator;
        }
        const level = strength === 0 || strength === 2 ? strength : 1;
        __afHourlyVibrator.stop();
        if (__afHourlyVibratorLegacy) {
          __afHourlyVibrator.scene = [23, 24, 25][level];
        } else {
          __afHourlyVibrator.setMode([VIBRATOR_SCENE_SHORT_LIGHT, VIBRATOR_SCENE_SHORT_MIDDLE, VIBRATOR_SCENE_SHORT_STRONG][level]);
        }
        __afHourlyVibrator.start();
        if (self._hourlyVibrationStopTimer) clearTimeout(self._hourlyVibrationStopTimer);
        self._hourlyVibrationStopTimer = setTimeout(function () {
          try { __afHourlyVibrator.stop(); } catch (e) {}
          self._hourlyVibrationStopTimer = null;
        }, 1500);
        return '';
      } catch (e) {
        return String(e && e.message ? e.message : e);
      }
    }
    const __afHourlyCheck = function () {
      try {
        // Если системный API типа экрана недоступен, не блокируем сигнал молча.
        if (typeof hmSetting !== 'undefined' && hmSetting && typeof hmSetting.getScreenType === 'function') {
          const screenType = hmSetting.getScreenType();
          const screenTypes = hmSetting.screen_type || {};
          if (screenType !== screenTypes.WATCHFACE && screenType !== screenTypes.AOD) return;
        }
        if (!__afHourlyPrefs.hourlyEnabled && !__afMinuteTest) return;
        const now = new Date();
        if (__afMinuteTest) {
          // Тест: один сигнал на каждую новую минуту, «тишина» и окно часа не учитываются.
          const minuteKey = [now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), now.getMinutes()].join("-");
          if (minuteKey === __afMinuteLastKey) return;
          if (__afVibrate(__afHourlyPrefs.strength) === '') __afMinuteLastKey = minuteKey;
          return;
        }
        // Окно — первые две минуты часа: в AOD и после выхода из сна таймер может
        // запоздать; ключ часа ниже гарантирует один сигнал на час.
        if (now.getMinutes() > 1) return;
        const hour = now.getHours();
        const inQuietWindow = function (enabled, start, end) {
          if (!enabled || start === end) return false;
          if (start < end) return hour >= start && hour < end;
          return hour >= start || hour < end;
        };
        if (inQuietWindow(__afHourlyPrefs.nightQuiet, __afHourlyPrefs.nightStart, __afHourlyPrefs.nightEnd) ||
            inQuietWindow(__afHourlyPrefs.napQuiet, __afHourlyPrefs.napStart, __afHourlyPrefs.napEnd)) return;
        const hourKey = [now.getFullYear(), now.getMonth(), now.getDate(), now.getHours()].join("-");
        if (hourKey === __afHourlyLastKey) return;
        if (__afVibrate(__afHourlyPrefs.strength) === '') __afHourlyLastKey = hourKey;
      } catch (e) {}
    };
    const __afHourlyControllerRefresh = function () {
      if (__afHourlyPrefs.hourlyEnabled || __afMinuteTest) {
        if (self._hourlyVibrationTimer == null) {
          __afHourlyCheck();
          self._hourlyVibrationTimer = setInterval(__afHourlyCheck, 1000);
        }
      } else {
        if (self._hourlyVibrationTimer != null) { clearInterval(self._hourlyVibrationTimer); self._hourlyVibrationTimer = null; }
        if (self._hourlyVibrationStopTimer != null) { clearTimeout(self._hourlyVibrationStopTimer); self._hourlyVibrationStopTimer = null; }
        try { if (__afHourlyVibrator) __afHourlyVibrator.stop(); } catch (e) {}
      }
    };
    __afHourlyControllerRefresh();
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._hourlyVibrationTimer) { clearInterval(this._hourlyVibrationTimer); this._hourlyVibrationTimer = null; }
    if (this._hourlyVibrationStopTimer) { clearTimeout(this._hourlyVibrationStopTimer); this._hourlyVibrationStopTimer = null; }
    try { if (this._hourlyVibrator) this._hourlyVibrator.stop(); } catch (e) {}
    try { __taDestroy(); } catch (e) {}
    try { __heartStop(); } catch (e) {}
    try { const fo = this._flashOffs || []; for (let i = 0; i < fo.length; i++) { try { fo[i](); } catch (e) {} } } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
