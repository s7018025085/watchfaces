import { createWidget, widget, align, text_style, prop, show_level, data_type, event } from '@zos/ui'
import { launchApp, SYSTEM_APP_CALENDAR, SYSTEM_APP_HR, SYSTEM_APP_SPORT, SYSTEM_APP_STATUS, SYSTEM_APP_WEATHER } from '@zos/router'
import { Time, Battery, Step, Calorie, Barometer, HeartRate } from '@zos/sensor'
import { LocalStorage } from '@zos/storage'
import { setInterval, clearInterval, setTimeout, clearTimeout } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// ---- Анимация текста (AmazFace): общий рантайм --------------------------------
var __TA = { list: [], all: [], timer: 0, paused: false };
var __taFx = {};
function __taClamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function __taEase(name, t) {
  t = __taClamp(t, 0, 1);
  if (name === 'in') return t * t * t;
  if (name === 'out') { var u = 1 - t; return 1 - u * u * u; }
  if (name === 'inout') return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  return t;
}
function __taMix(c1, c2, t) {
  var r = Math.round(((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
  var g = Math.round(((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
  var b = Math.round((c1 & 255) * (1 - t) + (c2 & 255) * t);
  return (r << 16) | (g << 8) | b;
}
function __taChars(s) {
  var out = [], i = 0, n, c;
  s = String(s == null ? '' : s);
  n = s.length;
  while (i < n) {
    c = s.charCodeAt(i);
    if (c >= 0xD800 && c <= 0xDBFF && i + 1 < n) { out.push(s.substr(i, 2)); i += 2; }
    else { out.push(s.charAt(i)); i += 1; }
  }
  return out;
}
function __taParseNum(s) {
  var m = /-?\d[\d,]*(?:\.\d+)?/.exec(String(s == null ? '' : s));
  if (!m) return null;
  var tok = m[0], clean = tok.replace(/,/g, ''), dot = clean.indexOf('.');
  return { pre: String(s).slice(0, m.index), post: String(s).slice(m.index + tok.length), val: parseFloat(clean), dec: dot >= 0 ? clean.length - dot - 1 : 0, sep: tok.indexOf(',') >= 0 };
}
function __taFmtNum(n, dec, sep) {
  var s = Math.abs(n).toFixed(dec), parts;
  if (sep) { parts = s.split('.'); parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ','); s = parts.join('.'); }
  return (n < 0 && parseFloat(s.replace(/,/g, '')) !== 0 ? '-' : '') + s;
}
function __taGroups(s) {
  var out = [], re = /\d+/g, m;
  s = String(s == null ? '' : s);
  while ((m = re.exec(s)) !== null) out.push({ i: m.index, s: m[0] });
  return out;
}
function __taPhase(a, el) {
  var c = a.cfg, d = c.delay || 0, dur = Math.max(1, a.durOv || c.dur), n = c.rep || 0, gap = c.pause || 0, t, cyc, rep, q, k;
  if (a.perp) return { k: 0, e: 0, ms: Math.max(0, el), rep: 0, done: false, hold: false };
  if (el < d) return { k: 0, e: __taEase(c.ease, 0), ms: 0, rep: 0, done: false, hold: true };
  t = el - d; cyc = dur + gap;
  if (t >= n * cyc + dur) return { k: 1, e: 1, ms: dur, rep: n, done: true, hold: false };
  rep = Math.floor(t / cyc); q = t - rep * cyc; k = q >= dur ? 1 : q / dur;
  return { k: k, e: __taEase(c.ease, k), ms: q >= dur ? dur : q, rep: rep, done: false, hold: false };
}
function __taFinal(a) {
  var s = { text: a.text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: true, alpha: 255 }, fx = __taFx[a.cfg.fx];
  if (fx.final) fx.final(a, s);
  return s;
}
function __taSample(a, el) {
  var ph = __taPhase(a, el), s = __taFinal(a), fx = __taFx[a.cfg.fx], o, key;
  if (ph.done) return { s: s, done: true, ph: ph };
  o = fx.frame(a, ph.k, ph);
  for (key in o) { if (Object.prototype.hasOwnProperty.call(o, key)) s[key] = o[key]; }
  return { s: s, done: false, ph: ph };
}
function __taAlpha(target, v) {
  var wd = target;
  if (!wd) return;
  try { wd.setAlpha(v); } catch (e) {}
}
function __taApply(a, s) {
  var o = {}, any = false, L = a.last, cut, tx = s.text, rest;
  if (a.cellLayout) {
    __taApplyCells(a, s);
    a.last = { text: tx, text2: null, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
    return;
  }
  if (a.w2) {
    cut = tx.indexOf(a.cfg.sep);
    rest = cut >= 0 ? tx.slice(cut + a.cfg.sep.length) : '';
    if (cut >= 0) tx = tx.slice(0, cut);
    if (rest !== L.text2) { try { a.w2.setProperty(prop.MORE, { text: rest }); } catch (e1) {} L.text2 = rest; }
  }
  if (tx !== L.text) { o.text = tx; any = true; }
  if (s.color !== L.color) { o.color = s.color; any = true; }
  if (s.x !== L.x) { o.x = s.x; any = true; }
  if (s.y !== L.y) { o.y = s.y; any = true; }
  if (s.size !== L.size) { o.text_size = s.size; any = true; }
  if (a.c && s.vis !== L.vis) { try { a.c.setProperty(prop.VISIBLE, s.vis); } catch (e2) {} }
  if (s.alpha !== L.alpha && s.alpha !== undefined) {
    __taAlpha(a.w, s.alpha); __taAlpha(a.w2, s.alpha); __taAlpha(a.c, s.alpha);
  }
  a.last = { text: tx, text2: L.text2, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
  if (any && a.w) { try { a.w.setProperty(prop.MORE, o); } catch (e3) {} }
}
function __taShow(a) { __taApply(a, __taFinal(a)); }
// Условия повторного запуска эффектов при изменении исходного текста.
// Для «Проявления» и «Пульсации размера» посимвольный режим дополнительно
// ограничивает сами стили изменившимися разрядами; остальные эффекты фильтруют запуск целиком.
function __taChangeAllowed(a, oldText, newText) {
  var mode = a.cfg.track || 'all', oldD, newD, i, off;
  if (mode === 'all') return true;
  if (mode === 'off') return false;
  oldD = String(oldText == null ? '' : oldText).replace(/[^0-9]/g, '');
  newD = String(newText == null ? '' : newText).replace(/[^0-9]/g, '');
  if (mode === 'changed') return oldD !== newD;
  if (mode === 'seconds' && !a.cfg.trackSec) return false;
  if (mode === 'units') off = 1;
  else if (mode === 'tens') off = 2;
  else if (mode === 'seconds') {
    for (i = 1; i <= 2; i++) {
      if (oldD.charAt(oldD.length - i) !== newD.charAt(newD.length - i)) return true;
    }
    return false;
  } else return true;
  if (oldD.length < off || newD.length < off) return false;
  return oldD.charAt(oldD.length - off) !== newD.charAt(newD.length - off);
}
// Определяет только цифры, которым разрешено анимироваться в посимвольных режимах.
function __taCharTargets(a, why) {
  var cur = __taChars(a.text), old = __taChars(a.prevText || ''), mode = a.cfg.track || 'all';
  var digits = [], target = {}, i, idx, off;
  for (i = 0; i < cur.length; i++) if (cur[i] >= '0' && cur[i] <= '9') digits.push(i);
  if (why === 'open') {
    if (mode === 'seconds' && a.cfg.trackSec) {
      off = Math.max(0, digits.length - 2);
      for (i = off; i < digits.length; i++) target[digits[i]] = true;
    } else if (mode === 'tens' || mode === 'units') {
      off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
      if (off >= 0) target[digits[off]] = true;
    } else if (mode === 'changed') {
      for (i = 0; i < digits.length; i++) target[digits[i]] = true;
    }
    return target;
  }
  if (why !== 'update' && why !== 'wake') return target;
  if (mode === 'seconds') {
    if (!a.cfg.trackSec) return target;
    off = Math.max(0, digits.length - 2);
    for (i = off; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else if (mode === 'tens' || mode === 'units') {
    off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
    if (off >= 0) { idx = digits[off]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else {
    for (i = 0; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  }
  return target;
}
function __taApplyCells(a, s) {
  var l = a.cellLayout, ws = l.widgets, chars = __taChars(s.text), n = ws.length;
  var count = Math.min(chars.length, n), gap = Number(l.gap || 0), total = 0, start, x, cellX, i, ch, col, size, o, prev, w, cw, scale, renderW, al, widths = [];
  // La anchura de composición siempre usa la métrica base para que una pulsación
  // no empuje las cifras vecinas. Solo se ensancha la celda animada, simétricamente.
  for (i = 0; i < count; i++) {
    ch = chars[i]; cw = Math.max(1, Number((l.charWidths && l.charWidths[ch]) || l.defaultWidth || 1));
    widths[i] = cw; total += cw;
  }
  if (count > 1) total += gap * (count - 1);
  if (l.align === 'LEFT') start = Number(l.x || 0);
  else if (l.align === 'RIGHT') start = Number(l.x || 0) + Number(l.w || 0) - total;
  else start = Number(l.x || 0) + Number(l.w || 0) / 2 - total / 2;
  x = start;
  if (!a.cellLast) a.cellLast = [];
  for (i = 0; i < n; i++) {
    ch = i < count ? chars[i] : '';
    cw = i < count ? widths[i] : Math.max(1, Number(l.defaultWidth || 1));
    col = s.charColors && s.charColors[i] != null ? s.charColors[i] : s.color;
    size = s.charSizes && s.charSizes[i] != null ? s.charSizes[i] : s.size;
    scale = a.base.size > 0 ? Math.max(1, Number(size || a.base.size) / a.base.size) : 1;
    renderW = Math.max(cw, Math.ceil(cw * scale));
    cellX = x - (renderW - cw) / 2;
    prev = a.cellLast[i] || { text: null, color: null, size: null, x: null, w: null, alpha: 255 };
    al = s.charAlphas && s.charAlphas[i] != null ? s.charAlphas[i] : (s.alpha == null ? 255 : s.alpha);
    o = {};
    if (ch !== prev.text) o.text = ch;
    if (col !== prev.color) o.color = col;
    if (size !== prev.size) o.text_size = size;
    if (Math.round(cellX) !== prev.x) o.x = Math.round(cellX);
    if (renderW !== prev.w) o.w = renderW;
    w = ws[i];
    if (Object.keys(o).length && w) { try { w.setProperty(prop.MORE, o); } catch (e) {} }
    if (al !== prev.alpha) __taAlpha(w, al);
    a.cellLast[i] = { text: ch, color: col, size: size, x: Math.round(cellX), w: renderW, alpha: al };
    x += cw + gap;
  }
}

function __taEnsure() {
  var ms = 1000, i;
  if (__TA.timer || !__TA.list.length) return;
  for (i = 0; i < __TA.list.length; i++) { if (__TA.list[i].step < ms) ms = __TA.list[i].step; }
  __TA.timer = setInterval(__taStep, Math.max(30, ms));
}
function __taDrop(a) {
  var i = __TA.list.indexOf(a);
  if (i >= 0) __TA.list.splice(i, 1);
  if (!__TA.list.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taStep() {
  var now = Date.now(), keep = [], i, a, r, fx;
  for (i = 0; i < __TA.list.length; i++) {
    a = __TA.list[i];
    r = __taSample(a, now - a.t0);
    fx = __taFx[a.cfg.fx];
    if (r.done) { a.on = false; if (fx.done) fx.done(a); __taShow(a); }
    else { __taApply(a, r.s); keep.push(a); }
  }
  __TA.list = keep;
  if (!keep.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taBegin(a, why) {
  var fx = __taFx[a.cfg.fx];
  a.durOv = 0;
  if (fx.init) fx.init(a, why);
  a.t0 = Date.now(); a.on = true; a.why = why;
}
function __taPlay(a, why) {
  var r;
  if (__TA.paused) return;
  if (a.on && a.cfg.retrig === 'ignore') return;
  __taBegin(a, why);
  r = __taSample(a, 0);
  __taApply(a, r.s);
  if (__TA.list.indexOf(a) < 0) __TA.list.push(a);
  __taEnsure();
}
function __taStop(a) { a.on = false; __taDrop(a); __taShow(a); }
function __taSetText(a, text) {
  var c = a.cfg, fx = __taFx[c.fx], old = a.text, changed;
  text = text == null ? '' : String(text);
  changed = text !== old;
  a.prevText = old;
  a.text = text;
  if (fx.live) { fx.live(a, old, text, changed); return; }
  if (!a.opened) {
    if (fx.can && !fx.can(a)) { __taShow(a); return; }
    a.opened = true;
    if (c.open) __taPlay(a, 'open'); else __taShow(a);
    return;
  }
  if (!changed) { if (!a.on) __taShow(a); return; }
  // Применяется одинаково ко всем эффектам с обработчиком изменения (в том числе
  // count/flash/flip, у которых специальная обработка обновления значения).
  // При проигнорированном изменении сразу показываем новое значение без старого кадра.
  if (!__taChangeAllowed(a, old, text)) { if (a.on) __taStop(a); else __taShow(a); return; }
  if (fx.onChange) { fx.onChange(a, old, text); return; }
  if (c.change && (!fx.can || fx.can(a))) { __taPlay(a, 'update'); return; }
  if (!a.on) __taShow(a);
}
function __taCreate(w, cfg, base, w2, cw, cellLayout) {
  var fx = __taFx[cfg.fx];
  var a = { w: w, w2: w2 || null, c: cw || null, cellLayout: cellLayout || null, cellLast: [], charMode: !!cfg.charMode || !!cellLayout, charTargets: null, cfg: cfg, base: base, text: '', prevText: '', t0: 0, on: false, opened: false, why: '', durOv: 0, perp: !!(fx.perp && cfg.iv < 1000), blink: 0, cnt: null, curV: null, fl: null, step: 50, last: { text: null, text2: null, color: base.fin, x: base.x, y: base.y, size: base.size, vis: true, alpha: 255 } };
  a.step = fx.step ? fx.step(cfg) : 50;
  __TA.all.push(a);
  return a;
}
function __taPause() {
  var i, a;
  __TA.paused = true;
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = [];
  for (i = 0; i < __TA.all.length; i++) { a = __TA.all[i]; a.on = false; __taShow(a); }
}
function __taResume() {
  var now = Date.now(), i, a, fx;
  __TA.paused = false;
  for (i = 0; i < __TA.all.length; i++) {
    a = __TA.all[i]; fx = __taFx[a.cfg.fx];
    if (!a.opened) continue;
    if (fx.resume) { fx.resume(a); continue; }
    if (a.cfg.wake && now - a.t0 > 800) __taPlay(a, 'wake');
  }
}
function __taDestroy() {
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = []; __TA.all = []; __TA.paused = false;
}

__taFx.reveal = {
  step: function () { return 50; },
  init: function (a, why) { if (a.charMode) a.charTargets = __taCharTargets(a, why); },
  frame: function (a, k, ph) {
    var colors, alphas, ch, i, al;
    if (a.cfg.ta) {
      // «Из прозрачного»: цвет сразу конечный, меняется только прозрачность 0 → 255.
      al = Math.round(255 * ph.e);
      if (a.charMode) {
        alphas = []; ch = __taChars(a.text);
        for (i = 0; i < ch.length; i++) alphas[i] = a.charTargets && a.charTargets[i] ? al : 255;
        return { charAlphas: alphas };
      }
      return { alpha: al };
    }
    if (a.charMode) {
      colors = []; ch = __taChars(a.text);
      for (i = 0; i < ch.length; i++) colors[i] = a.charTargets && a.charTargets[i] ? __taMix(a.cfg.c1, a.base.fin, ph.e) : null;
      return { charColors: colors };
    }
    return { color: __taMix(a.cfg.c1, a.base.fin, ph.e) };
  }
};
__taFx.roll = {
  step: function (c) { return Math.max(30, Math.min(100, Math.round(1000 / Math.max(1, c.speed)))); },
  can: function (a) { return /\d/.test(a.text); },
  frame: function (a, k, ph) {
    var c = a.cfg, ch = __taChars(a.text), prevChars = __taChars(a.prevText || ''), idx = [], prev = [], q, n, tick, sg, w, mx, v, stopK;
    for (q = 0; q < ch.length; q++) { if (ch[q] >= '0' && ch[q] <= '9') idx.push(q); }
    for (q = 0; q < prevChars.length; q++) { if (prevChars[q] >= '0' && prevChars[q] <= '9') prev.push(prevChars[q]); }
    n = idx.length;
    if (!n) return {};
    tick = Math.floor((ph.ms / 1000) * c.speed);
    sg = c.dir === 'down' ? -1 : 1;
    for (w = 0; w < n; w++) {
      if (c.digits === 'off' ||
          (c.digits === 'seconds' && (!c.sec || w < n - 2)) ||
          (c.digits === 'tens' && w !== n - 2) ||
          (c.digits === 'units' && w !== n - 1) ||
          (c.digits === 'changed' && prev.length === n && prev[w] === ch[idx[w]])) continue;
      stopK = c.order === 'ltr' ? (w + 1) / n : 1;
      if (k >= stopK) continue;
      mx = (c.mask && c.mask[w] !== undefined && c.mask[w] !== null) ? c.mask[w] : 9;
      v = (((tick * sg + w * 3) % (mx + 1)) + (mx + 1)) % (mx + 1);
      ch[idx[w]] = String(v);
    }
    return { text: ch.join('') };
  }
};


const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _barometer = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}
import { readFileSync, writeFileSync } from '@zos/fs'

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    const __afEd = [];

    const __afProfileWidgets = { day: [], night: [] };
    const __afProfileWidgetState = new Map();
    let __afActiveProfile = '';
    function __afCreateProfileWidget(profile, id, options) {
      const w = createWidget(id, options);
      const record = { widget: w, profile: profile, visible: true };
      __afProfileWidgetState.set(w, record);
      __afProfileWidgets[profile].push(record);
      try { w.setProperty(prop.VISIBLE, profile === __afActiveProfile); } catch (e) {}
      return w;
    }
    function __afCreateDayWidget(id, options) { return __afCreateProfileWidget('day', id, options); }
    function __afCreateNightWidget(id, options) { return __afCreateProfileWidget('night', id, options); }
    function __afSetProfileVisible(w, visible) {
      const record = __afProfileWidgetState.get(w);
      if (!record) { try { w.setProperty(prop.VISIBLE, !!visible); } catch (e) {} return; }
      record.visible = !!visible;
      try { w.setProperty(prop.VISIBLE, record.visible && record.profile === __afActiveProfile); } catch (e) {}
    }
    function __afProfileApply(profile) {
      profile = profile === 'night' ? 'night' : 'day';
      if (profile === __afActiveProfile) return;
      try { const offs = self._flashOffs || []; for (let i = 0; i < offs.length; i++) { try { offs[i](); } catch (e) {} } } catch (e) {}
      __afActiveProfile = profile;
      ['day', 'night'].forEach(function (key) {
        const list = __afProfileWidgets[key] || [];
        for (let i = 0; i < list.length; i++) {
          const record = list[i];
          try { record.widget.setProperty(prop.VISIBLE, record.visible && key === profile); } catch (e) {}
        }
      });
    }
    let __afProfileTime = null;
    try { __afProfileTime = new Time(); } catch (e) {}
    function __afProfileRefresh() {
      const mode = __afProfilePrefs.profileMode || 'day';
      let target = mode === 'night' ? 'night' : 'day';
      if (mode === 'auto') {
        const now = __afProfileTime ? new Date(__afProfileTime.getTime()) : new Date();
        const hour = now.getHours();
        const start = Number(__afProfilePrefs.profileStart);
        const end = Number(__afProfilePrefs.profileEnd);
        const night = start !== end && (start < end ? hour >= start && hour < end : hour >= start || hour < end);
        target = night ? 'night' : 'day';
      }
      __afProfileApply(target);
      try { if (typeof __afPanelRefresh === 'function') __afPanelRefresh(); } catch (e) {}
    }
// ---- Плавающий AOD: настройки с часов (файл hmFS), единый таймер для всех плавающих текстов ----
    const __afFloatPath = "amazface_float_3412828_1792695551407.json";
    const __afFloatDef = {"iv":5,"st":6,"mg":12};
    const __afFloatCur = { on: true, iv: 5, st: 6, mg: 12 };
    const __afFloatItems = [];
    let __afFloatSeen = '';
    let __afFloatSaveOk = true;
    // Файл читается/пишется через @zos/fs (readFileSync/writeFileSync, каталог /data циферблата).
    function __afFloatRaw() {
      try {
        const t = readFileSync({ path: __afFloatPath, options: { encoding: 'utf8' } });
        return (typeof t === 'string' && t.length <= 512) ? t : '';
      } catch (e) { return ''; }
    }
    function __afFloatParse(raw) {
      try {
        const data = JSON.parse(raw);
        if (!data || typeof data !== 'object') return false;
        if (typeof data.on === 'boolean') __afFloatCur.on = data.on;
        if ([1, 5, 10, 30, 60].indexOf(data.iv) >= 0) __afFloatCur.iv = data.iv;
        if (typeof data.st === 'number' && data.st >= 1 && data.st <= 60) __afFloatCur.st = Math.round(data.st);
        if (typeof data.mg === 'number' && data.mg >= 0 && data.mg <= 120) __afFloatCur.mg = Math.round(data.mg);
        return true;
      } catch (e) { return false; }
    }
    function __afFloatLoad() {
      const raw = __afFloatRaw();
      if (raw) { __afFloatSeen = raw; __afFloatParse(raw); }
    }
    function __afFloatSave() {
      try {
        const raw = JSON.stringify({ on: __afFloatCur.on, iv: __afFloatCur.iv, st: __afFloatCur.st, mg: __afFloatCur.mg });
        writeFileSync({ path: __afFloatPath, data: raw, options: { encoding: 'utf8' } });
        __afFloatSeen = raw;
        __afFloatSaveOk = (__afFloatRaw() === raw);
      } catch (e) { __afFloatSaveOk = false; }
    }
    // AOD может работать в другом запуске кода, чем панель настроек, поэтому на каждом тике
    // сверяем файл: изменились настройки — применяем (выкл. → тексты на место, частота → новый таймер).
    function __afFloatSync() {
      const raw = __afFloatRaw();
      if (!raw || raw === __afFloatSeen) return false;
      __afFloatSeen = raw;
      const wasOn = __afFloatCur.on, wasIv = __afFloatCur.iv;
      if (!__afFloatParse(raw)) return false;
      if (wasOn !== __afFloatCur.on || wasIv !== __afFloatCur.iv) {
        if (!__afFloatCur.on) { for (let i = 0; i < __afFloatItems.length; i++) { try { __afFloatItems[i].reset(); } catch (e) {} } }
        __afFloatRestart();
        return true;
      }
      return false;
    }
    function __afFloatRestart() {
      try { if (self._floatTimers) { for (let i = 0; i < self._floatTimers.length; i++) clearInterval(self._floatTimers[i]); } } catch (e) {}
      self._floatTimers = [];
      if (!__afFloatCur.on) return;
      self._floatTimers.push(setInterval(function () {
        if (__afFloatSync()) return;
        for (let i = 0; i < __afFloatItems.length; i++) { try { __afFloatItems[i].step(); } catch (e) {} }
      }, __afFloatCur.iv * 1000));
    }
    function __afFloatRegister(step, reset) {
      __afFloatItems.push({ step: step, reset: reset });
      __afFloatRestart();
    }
    // Вызывается панелью после любого изменения: выключили — тексты возвращаются на место.
    function __afFloatApply() {
      if (!__afFloatCur.on) { for (let i = 0; i < __afFloatItems.length; i++) { try { __afFloatItems[i].reset(); } catch (e) {} } }
      __afFloatRestart();
      __afFloatSave();
    }
    __afFloatLoad();
    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __afBgL_normal_ = ["chatgpt_image_21_sent_2026_g.png", "mrachnye_postery_mobland_v_setke_edited_bg_5_2.png", "mrachnye_postery_mobland_v_setke_edited_bg_4.png"];
          let __afBgI_normal_ = 0;
          try { const __s = new LocalStorage().getItem("afbg_normal_"); const __n = parseInt(__s, 10); if (__n >= 0 && __n < __afBgL_normal_.length) __afBgI_normal_ = __n; } catch (e) {}
          const __afBgA_normal_ = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: __afBgL_normal_[__afBgI_normal_] });
          __afBgA_normal_.setAlpha(255);
          const __afBgB_normal_ = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: __afBgL_normal_[__afBgI_normal_] });
          __afBgB_normal_.setAlpha(0);
          let __afBgT_normal_ = null;
          function __afBgGo_normal_(d) {
            const n = __afBgL_normal_.length; if (n < 2) return;
            const prev = __afBgI_normal_; let j = prev + (d < 0 ? -1 : 1);
            if (j >= n) j = 0; if (j < 0) j = n - 1;
            if (j === prev) return;
            __afBgI_normal_ = j;
            try { new LocalStorage().setItem("afbg_normal_", String(j)); } catch (e) {}
            if (__afBgT_normal_) { clearInterval(__afBgT_normal_); __afBgT_normal_ = null; try { __afBgA_normal_.setProperty(prop.SRC, __afBgL_normal_[prev]); __afBgB_normal_.setAlpha(0); } catch (e) {} }
            try { __afBgB_normal_.setProperty(prop.SRC, __afBgL_normal_[j]); __afBgB_normal_.setAlpha(0); } catch (e) { try { __afBgA_normal_.setProperty(prop.SRC, __afBgL_normal_[j]); } catch (e2) {} return; }
            let k = 0;
            __afBgT_normal_ = setInterval(() => { k++; try { __afBgB_normal_.setAlpha(Math.round(255 * k / 10)); if (k >= 10) { clearInterval(__afBgT_normal_); __afBgT_normal_ = null; __afBgA_normal_.setProperty(prop.SRC, __afBgL_normal_[j]); __afBgB_normal_.setAlpha(0); } } catch (e) { clearInterval(__afBgT_normal_); __afBgT_normal_ = null; } }, 30);
          }
          const __afBgTap_normal_ = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, normal_src: "", press_src: "", click_func: () => { try { __afBgGo_normal_(1); } catch (e) {} } });
          __afBgTap_normal_.setAlpha(0);
          (self._afBgCleanup = self._afBgCleanup || []).push(() => { try { if (__afBgT_normal_) { clearInterval(__afBgT_normal_); __afBgT_normal_ = null; } } catch (e) {} });
          const normal_w_0_fill_rect_001 = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 92, y: 322, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_0_fill_rect_001.setAlpha(255);
          const normal_w_1_steps_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 85, y: 322, w: 90, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "steps_001", n: "Шаги", d: "STEP", h: normal_w_1_steps_001, x: 85, y: 322, w: 90, ht: 30, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_2_fill_rect_002 = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 150, y: 372, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_2_fill_rect_002.setAlpha(255);
          const normal_w_3_heart_rate_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 322, w: 70, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "heart_rate_001", n: "Пульс", d: "HEART", h: normal_w_3_heart_rate_001, x: 230, y: 322, w: 70, ht: 30, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_4_calories_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 358, y: 322, w: 74, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "calories_001", n: "Калории", d: "CALORIE", h: normal_w_4_calories_001, x: 358, y: 322, w: 74, ht: 30, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_5_fill_rect_003 = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 294, y: 372, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_5_fill_rect_003.setAlpha(255);
          const normal_w_6_fill_rect_004 = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 420, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_6_fill_rect_004.setAlpha(255);
          const normal_w_7_date_full_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 368, w: 105, h: 40, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "date_full_001", n: "Дата", d: "DATE", h: normal_w_7_date_full_001, x: 140, y: 368, w: 105, ht: 40, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_8_altitude_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 288, y: 368, w: 95, h: 40, text_size: 26, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "altitude_001", n: "Высота", d: "ALTITUDE", h: normal_w_8_altitude_001, x: 288, y: 368, w: 95, ht: 40, s: 26, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_9_battery_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 229, y: 420, w: 83, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "battery_001", n: "Заряд батаре", d: "BATTERY", h: normal_w_9_battery_001, x: 229, y: 420, w: 83, ht: 30, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_10_weather_icon_001 = __afCreateDayWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 50, w: 64, h: 64, image_array: ["weather/64x64/0_cloudy.png", "weather/64x64/1_showers.png", "weather/64x64/2_snow_showers.png", "weather/64x64/3_sunny.png", "weather/64x64/4_overcast.png", "weather/64x64/5_light_rain.png", "weather/64x64/6_light_snow.png", "weather/64x64/7_moderate_rain.png", "weather/64x64/8_moderate_snow.png", "weather/64x64/9_heavy_snow.png", "weather/64x64/10_heavy_rain.png", "weather/64x64/11_sandstorm.png", "weather/64x64/12_rain_snow.png", "weather/64x64/13_fog.png", "weather/64x64/14_hazy.png", "weather/64x64/15_thunderstorm.png", "weather/64x64/16_snowstorm.png", "weather/64x64/17_floating_dust.png", "weather/64x64/18_very_heavy_rainstorm.png", "weather/64x64/19_rain_hail.png", "weather/64x64/20_thunderstorm_hail.png", "weather/64x64/21_heavy_rainstorm.png", "weather/64x64/22_dust.png", "weather/64x64/23_heavy_sandstorm.png", "weather/64x64/24_rainstorm.png", "weather/64x64/25_unknown.png", "weather/64x64/26_cloudy_night.png", "weather/64x64/27_showers_night.png", "weather/64x64/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 3, alpha: 255 });
          const normal_w_11_weather_temp_001 = __afCreateDayWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 20, y: 100, w: 120, h: 40, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          __afEd.push({ id: "weather_temp_001", n: "Температура", d: "WEATHER_TEMP", h: normal_w_11_weather_temp_001, x: 20, y: 100, w: 120, ht: 40, s: 32, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_12_text_002_ch0 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const normal_w_12_text_002_ch1 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const normal_w_12_text_002_ch2 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const normal_w_12_text_002_ch3 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const normal_w_12_text_002_ch4 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const normal_w_12_text_002_ch5 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const normal_w_12_text_002_ch6 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const normal_w_12_text_002_ch7 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const normal_w_12_text_002_a = __taCreate(null, { fx: "reveal", dur: 400, delay: 0, ease: "in", rep: 0, pause: 500, retrig: "ignore", open: false, wake: false, change: true, track: "changed", trackSec: true, charMode: true, c1: 0x1d4fa8 }, { x: 9, y: 100, color: 0xffffff, fin: 0xffffff, size: 100 }, null, null, { widgets: [normal_w_12_text_002_ch0, normal_w_12_text_002_ch1, normal_w_12_text_002_ch2, normal_w_12_text_002_ch3, normal_w_12_text_002_ch4, normal_w_12_text_002_ch5, normal_w_12_text_002_ch6, normal_w_12_text_002_ch7], charWidths: {"0":53,"1":53,"2":53,"3":53,"4":53,"5":53,"6":53,"7":53,"8":53,"9":53,"-":33,"+":53,",":30,".":30,"%":86," ":21,":":30,"/":34}, defaultWidth: 53, x: 9, w: 462, align: "CENTER_H", gap: 0 });
          const normal_w_12_text_002 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_12_text_002_a, o.text); } else { for (let i = 0; i < 8; i++) { [normal_w_12_text_002_ch0, normal_w_12_text_002_ch1, normal_w_12_text_002_ch2, normal_w_12_text_002_ch3, normal_w_12_text_002_ch4, normal_w_12_text_002_ch5, normal_w_12_text_002_ch6, normal_w_12_text_002_ch7][i].setProperty(k, o); } } } };
          const normal_tap_0_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 322, w: 80, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STATUS, native: true }); } catch (e) {} } });
          normal_tap_0_tap_001.setAlpha(0);
          const normal_tap_1_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 322, w: 70, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_HR, native: true }); } catch (e) {} } });
          normal_tap_1_tap_001.setAlpha(0);
          const normal_tap_2_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 360, y: 322, w: 70, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_SPORT, native: true }); } catch (e) {} } });
          normal_tap_2_tap_001.setAlpha(0);
          const normal_tap_3_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 147, y: 368, w: 90, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          normal_tap_3_tap_001.setAlpha(0);
          const normal_tap_4_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 50, w: 64, h: 64, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_4_tap_001.setAlpha(0);
          const normal_tap_5_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 20, y: 100, w: 120, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_5_tap_001.setAlpha(0);
          const normal_tap_6_tap_zone_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 190, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afBgGo_normal_(1); } catch (e) {} } });
          normal_tap_6_tap_zone_001.setAlpha(0);
          const normal_tap_7_tap_zone_002 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 410, y: 200, w: 70, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afBgGo_normal_(-1); } catch (e) {} } });
          normal_tap_7_tap_zone_002.setAlpha(0);
          const normal_tap_8_tap_zone_003 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 50, y: 360, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afOpenSettings(); } catch (e) {} } });
          normal_tap_8_tap_zone_003.setAlpha(0);
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            __afCreateDayWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _barometer = new Barometer(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_7_date_full_001.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
            normal_w_12_text_002.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", true) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_1_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_1_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_3_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_4_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_4_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _barometer ? _barometer.getAltitude() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_8_altitude_001.setProperty(prop.MORE, { text: "" + txt + " м" });
            } catch (e) { normal_w_8_altitude_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_9_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_9_battery_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // Night profile widgets — isolated lexical scope
    {
          const __bgColor_night_ = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_night_.setAlpha(255);
          const __afBgL_night_ = ["chatgpt_image_21_sent_2026_g.png", "mrachnye_postery_mobland_v_setke_edited_bg_5_2.png", "mrachnye_postery_mobland_v_setke_edited_bg_4.png"];
          let __afBgI_night_ = 0;
          try { const __s = new LocalStorage().getItem("afbg_night_"); const __n = parseInt(__s, 10); if (__n >= 0 && __n < __afBgL_night_.length) __afBgI_night_ = __n; } catch (e) {}
          const __afBgA_night_ = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: __afBgL_night_[__afBgI_night_] });
          __afBgA_night_.setAlpha(255);
          const __afBgB_night_ = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: __afBgL_night_[__afBgI_night_] });
          __afBgB_night_.setAlpha(0);
          let __afBgT_night_ = null;
          function __afBgGo_night_(d) {
            const n = __afBgL_night_.length; if (n < 2) return;
            const prev = __afBgI_night_; let j = prev + (d < 0 ? -1 : 1);
            if (j >= n) j = 0; if (j < 0) j = n - 1;
            if (j === prev) return;
            __afBgI_night_ = j;
            try { new LocalStorage().setItem("afbg_night_", String(j)); } catch (e) {}
            if (__afBgT_night_) { clearInterval(__afBgT_night_); __afBgT_night_ = null; try { __afBgA_night_.setProperty(prop.SRC, __afBgL_night_[prev]); __afBgB_night_.setAlpha(0); } catch (e) {} }
            try { __afBgB_night_.setProperty(prop.SRC, __afBgL_night_[j]); __afBgB_night_.setAlpha(0); } catch (e) { try { __afBgA_night_.setProperty(prop.SRC, __afBgL_night_[j]); } catch (e2) {} return; }
            let k = 0;
            __afBgT_night_ = setInterval(() => { k++; try { __afBgB_night_.setAlpha(Math.round(255 * k / 10)); if (k >= 10) { clearInterval(__afBgT_night_); __afBgT_night_ = null; __afBgA_night_.setProperty(prop.SRC, __afBgL_night_[j]); __afBgB_night_.setAlpha(0); } } catch (e) { clearInterval(__afBgT_night_); __afBgT_night_ = null; } }, 30);
          }
          const __afBgTap_night_ = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, normal_src: "", press_src: "", click_func: () => { try { __afBgGo_night_(1); } catch (e) {} } });
          __afBgTap_night_.setAlpha(0);
          (self._afBgCleanup = self._afBgCleanup || []).push(() => { try { if (__afBgT_night_) { clearInterval(__afBgT_night_); __afBgT_night_ = null; } } catch (e) {} });
          const night_w_0_fill_rect_001 = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 92, y: 322, w: 70, h: 30, radius: 0, color: 0x00133c });
          night_w_0_fill_rect_001.setAlpha(255);
          const night_w_1_steps_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 85, y: 322, w: 90, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:steps_001", n: "Шаги", d: "STEP", h: night_w_1_steps_001, x: 85, y: 322, w: 90, ht: 30, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const night_w_2_fill_rect_002 = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 150, y: 372, w: 70, h: 30, radius: 0, color: 0x00133c });
          night_w_2_fill_rect_002.setAlpha(255);
          const night_w_3_heart_rate_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 322, w: 70, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:heart_rate_001", n: "Пульс", d: "HEART", h: night_w_3_heart_rate_001, x: 230, y: 322, w: 70, ht: 30, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const night_w_4_calories_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 358, y: 322, w: 74, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:calories_001", n: "Калории", d: "CALORIE", h: night_w_4_calories_001, x: 358, y: 322, w: 74, ht: 30, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const night_w_5_fill_rect_003 = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 294, y: 372, w: 70, h: 30, radius: 0, color: 0x00133c });
          night_w_5_fill_rect_003.setAlpha(255);
          const night_w_6_fill_rect_004 = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 420, w: 70, h: 30, radius: 0, color: 0x00133c });
          night_w_6_fill_rect_004.setAlpha(255);
          const night_w_7_date_full_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 368, w: 105, h: 40, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "night:date_full_001", n: "Дата", d: "DATE", h: night_w_7_date_full_001, x: 140, y: 368, w: 105, ht: 40, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const night_w_8_altitude_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 288, y: 368, w: 95, h: 40, text_size: 26, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:altitude_001", n: "Высота", d: "ALTITUDE", h: night_w_8_altitude_001, x: 288, y: 368, w: 95, ht: 40, s: 26, c: 0xffffff, ah: "CENTER_H" });
          const night_w_9_battery_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 229, y: 420, w: 83, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:battery_001", n: "Заряд батаре", d: "BATTERY", h: night_w_9_battery_001, x: 229, y: 420, w: 83, ht: 30, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const night_w_10_weather_icon_001 = __afCreateNightWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 50, w: 64, h: 64, image_array: ["weather/64x64/0_cloudy.png", "weather/64x64/1_showers.png", "weather/64x64/2_snow_showers.png", "weather/64x64/3_sunny.png", "weather/64x64/4_overcast.png", "weather/64x64/5_light_rain.png", "weather/64x64/6_light_snow.png", "weather/64x64/7_moderate_rain.png", "weather/64x64/8_moderate_snow.png", "weather/64x64/9_heavy_snow.png", "weather/64x64/10_heavy_rain.png", "weather/64x64/11_sandstorm.png", "weather/64x64/12_rain_snow.png", "weather/64x64/13_fog.png", "weather/64x64/14_hazy.png", "weather/64x64/15_thunderstorm.png", "weather/64x64/16_snowstorm.png", "weather/64x64/17_floating_dust.png", "weather/64x64/18_very_heavy_rainstorm.png", "weather/64x64/19_rain_hail.png", "weather/64x64/20_thunderstorm_hail.png", "weather/64x64/21_heavy_rainstorm.png", "weather/64x64/22_dust.png", "weather/64x64/23_heavy_sandstorm.png", "weather/64x64/24_rainstorm.png", "weather/64x64/25_unknown.png", "weather/64x64/26_cloudy_night.png", "weather/64x64/27_showers_night.png", "weather/64x64/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 3, alpha: 255 });
          const night_w_11_weather_temp_001 = __afCreateNightWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 20, y: 100, w: 120, h: 40, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          __afEd.push({ id: "night:weather_temp_001", n: "Температура", d: "WEATHER_TEMP", h: night_w_11_weather_temp_001, x: 20, y: 100, w: 120, ht: 40, s: 32, c: 0xffffff, ah: "CENTER_H" });
          const night_w_12_text_002_ch0 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const night_w_12_text_002_ch1 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const night_w_12_text_002_ch2 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const night_w_12_text_002_ch3 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const night_w_12_text_002_ch4 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const night_w_12_text_002_ch5 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const night_w_12_text_002_ch6 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const night_w_12_text_002_ch7 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 100, w: 53, h: 179, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const night_w_12_text_002_a = __taCreate(null, { fx: "reveal", dur: 400, delay: 0, ease: "in", rep: 0, pause: 500, retrig: "ignore", open: false, wake: false, change: true, track: "changed", trackSec: true, charMode: true, c1: 0x1d4fa8 }, { x: 9, y: 100, color: 0xffffff, fin: 0xffffff, size: 100 }, null, null, { widgets: [night_w_12_text_002_ch0, night_w_12_text_002_ch1, night_w_12_text_002_ch2, night_w_12_text_002_ch3, night_w_12_text_002_ch4, night_w_12_text_002_ch5, night_w_12_text_002_ch6, night_w_12_text_002_ch7], charWidths: {"0":53,"1":53,"2":53,"3":53,"4":53,"5":53,"6":53,"7":53,"8":53,"9":53,"-":33,"+":53,",":30,".":30,"%":86," ":21,":":30,"/":34}, defaultWidth: 53, x: 9, w: 462, align: "CENTER_H", gap: 0 });
          const night_w_12_text_002 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(night_w_12_text_002_a, o.text); } else { for (let i = 0; i < 8; i++) { [night_w_12_text_002_ch0, night_w_12_text_002_ch1, night_w_12_text_002_ch2, night_w_12_text_002_ch3, night_w_12_text_002_ch4, night_w_12_text_002_ch5, night_w_12_text_002_ch6, night_w_12_text_002_ch7][i].setProperty(k, o); } } } };
          const night_tap_0_tap_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 322, w: 80, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STATUS, native: true }); } catch (e) {} } });
          night_tap_0_tap_001.setAlpha(0);
          const night_tap_1_tap_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 322, w: 70, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_HR, native: true }); } catch (e) {} } });
          night_tap_1_tap_001.setAlpha(0);
          const night_tap_2_tap_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 360, y: 322, w: 70, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_SPORT, native: true }); } catch (e) {} } });
          night_tap_2_tap_001.setAlpha(0);
          const night_tap_3_tap_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 147, y: 368, w: 90, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          night_tap_3_tap_001.setAlpha(0);
          const night_tap_4_tap_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 50, w: 64, h: 64, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          night_tap_4_tap_001.setAlpha(0);
          const night_tap_5_tap_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 20, y: 100, w: 120, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          night_tap_5_tap_001.setAlpha(0);
          const night_tap_6_tap_zone_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 190, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afBgGo_night_(1); } catch (e) {} } });
          night_tap_6_tap_zone_001.setAlpha(0);
          const night_tap_7_tap_zone_002 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 410, y: 200, w: 70, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afBgGo_night_(-1); } catch (e) {} } });
          night_tap_7_tap_zone_002.setAlpha(0);
          const night_tap_8_tap_zone_003 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 50, y: 360, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afOpenSettings(); } catch (e) {} } });
          night_tap_8_tap_zone_003.setAlpha(0);
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            __afCreateNightWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _barometer = new Barometer(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNight() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            night_w_7_date_full_001.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
            night_w_12_text_002.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", true) });
          }
          _tickNight();
          self._timeTimerNight = setInterval(_tickNight, 1000);
      
          function _tickSensorsNight() {
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              night_w_1_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_1_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              night_w_3_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_3_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              night_w_4_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_4_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _barometer ? _barometer.getAltitude() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              night_w_8_altitude_001.setProperty(prop.MORE, { text: "" + txt + " м" });
            } catch (e) { night_w_8_altitude_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              night_w_9_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { night_w_9_battery_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNight();
          self._sensorTimerNight = setInterval(_tickSensorsNight, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_text_002 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: -5, y: 150, w: 490, h: 80, text_size: 100, color: 0x246adb, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          // Плавающий текст AOD: шаг 6px, обновление раз в 5 с, настройки из панели на часах (⚠ unverified, см. docs/AOD_FLOAT.md)
          let aod_w_0_text_002_fl_x = -5, aod_w_0_text_002_fl_y = 150, aod_w_0_text_002_fl_dx = 1, aod_w_0_text_002_fl_dy = 1;
          function aod_w_0_text_002_fl_in(px, py) { const r = 240 - __afFloatCur.mg; const xs = [px, px + 490], ys = [py, py + 80]; for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { const dx = xs[i] - 240, dy = ys[j] - 240; if (dx * dx + dy * dy > r * r) return false; } return true; }
          function aod_w_0_text_002_fl_step() {
            try {
              const sx = __afFloatCur.st, sy = Math.max(1, Math.round(__afFloatCur.st * 0.6));
              if (!aod_w_0_text_002_fl_in(aod_w_0_text_002_fl_x, aod_w_0_text_002_fl_y)) {
                // Старт вне допустимой области: возвращаем текст к центру экрана.
                aod_w_0_text_002_fl_x += (240 - (aod_w_0_text_002_fl_x + 490 / 2)) > 0 ? sx : -sx;
                aod_w_0_text_002_fl_y += (240 - (aod_w_0_text_002_fl_y + 80 / 2)) > 0 ? sy : -sy;
              } else {
                let nx = aod_w_0_text_002_fl_x + aod_w_0_text_002_fl_dx * sx;
                if (!aod_w_0_text_002_fl_in(nx, aod_w_0_text_002_fl_y)) { aod_w_0_text_002_fl_dx = -aod_w_0_text_002_fl_dx; nx = aod_w_0_text_002_fl_x + aod_w_0_text_002_fl_dx * sx; if (!aod_w_0_text_002_fl_in(nx, aod_w_0_text_002_fl_y)) nx = aod_w_0_text_002_fl_x; }
                let ny = aod_w_0_text_002_fl_y + aod_w_0_text_002_fl_dy * sy;
                if (!aod_w_0_text_002_fl_in(nx, ny)) { aod_w_0_text_002_fl_dy = -aod_w_0_text_002_fl_dy; ny = aod_w_0_text_002_fl_y + aod_w_0_text_002_fl_dy * sy; if (!aod_w_0_text_002_fl_in(nx, ny)) ny = aod_w_0_text_002_fl_y; }
                aod_w_0_text_002_fl_x = nx; aod_w_0_text_002_fl_y = ny;
              }
              aod_w_0_text_002.setProperty(prop.MORE, { x: Math.round(aod_w_0_text_002_fl_x), y: Math.round(aod_w_0_text_002_fl_y) });
            } catch (e) {}
          }
          function aod_w_0_text_002_fl_reset() { aod_w_0_text_002_fl_x = -5; aod_w_0_text_002_fl_y = 150; aod_w_0_text_002_fl_dx = 1; aod_w_0_text_002_fl_dy = 1; try { aod_w_0_text_002.setProperty(prop.MORE, { x: -5, y: 150 }); } catch (e) {} }
          __afFloatRegister(aod_w_0_text_002_fl_step, aod_w_0_text_002_fl_reset);
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_text_002.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
// Параметры расписания живут только в памяти текущего запуска циферблата.
    const __afPanelW = 480;
    const __afPanelH = 480;
    const __afProfilePrefs = { profileMode: "auto", profileStart: 22, profileEnd: 7 };

    const __afPanelScale = Math.min(__afPanelW, __afPanelH) / 480;
    const __afPanelPad = Math.max(6, Math.round(10 * __afPanelScale));
    const __afPanelSafePad = Math.max(6, Math.round(12 * __afPanelScale));
    // Шапка ниже и выше прежней: у верха круглого экрана по ширине помещается меньше 40 px.
    const __afPanelHeaderH = Math.min(__afPanelH, Math.max(40, Math.round(68 * __afPanelScale)));
    const __afPanelHeaderTop = Math.round(22 * __afPanelScale);
    const __afPanelBottomPad = Math.max(8, Math.round(12 * __afPanelScale));
    const __afPanelRowH = Math.max(16, Math.min(
      Math.max(18, Math.round(44 * __afPanelScale)),
      Math.floor((__afPanelH - __afPanelHeaderH - __afPanelPad - __afPanelBottomPad) / 10)
    ));
    const __afPanelHeight = Math.min(__afPanelH, __afPanelHeaderH + 10 * __afPanelRowH + __afPanelPad + __afPanelBottomPad);
    const __afPanelTop = __afPanelH - __afPanelHeight;
    const __afPanelRowY = __afPanelTop + __afPanelHeaderH + __afPanelPad;
    const __afPanelFont = Math.max(12, Math.min(Math.round(20 * __afPanelScale), Math.round((__afPanelRowH - 2) * 0.62)));
    const __afPanelStepW = Math.max(24, Math.round(46 * __afPanelScale));
    let __afPanelVisible = false;
    let __afPanelPage = 0;
    function __afPanelCircleInset(y) {
      const halfW = __afPanelW / 2;
      const halfH = __afPanelH / 2;
      const normalized = Math.max(-1, Math.min(1, (y - halfH) / Math.max(1, halfH)));
      return halfW * (1 - Math.sqrt(Math.max(0, 1 - normalized * normalized)));
    }
    function __afPanelRowBox(y, height) {
      const inset = Math.max(__afPanelCircleInset(y), __afPanelCircleInset(y + height));
      const x = Math.ceil(inset + __afPanelSafePad);
      const right = Math.floor(__afPanelW - inset - __afPanelSafePad);
      return { x: x, w: Math.max(1, right - x) };
    }
    function __afPanelSetVisible(w, visible) { w.setProperty(prop.VISIBLE, !!visible); }
    function __afPanelSetText(w, text, x, y, width, height) {
      w.setProperty(prop.MORE, { x: x, y: y, w: width, h: height, text: text });
    }
    function __afPanelSetRowText(w, text, y, height) {
      const box = __afPanelRowBox(y, height);
      __afPanelSetText(w, text, box.x, y, box.w, height);
    }
    function __afPanelButton(x, y, width, height, text, click) {
      const w = createWidget(widget.BUTTON, {
        show_level: show_level.ONLY_NORMAL,
        x: x, y: y, w: width, h: height, text: text,
        color: 0xffffff, text_size: __afPanelFont,
        normal_color: 0x253140, press_color: 0x3a4b60,
        radius: Math.max(4, Math.round(8 * __afPanelScale)),
        click_func: click,
      });
      __afPanelSetVisible(w, false);
      return w;
    }
    function __afPanelHour(value) { return (value < 10 ? '0' : '') + value + ':00'; }
    function __afPanelLargeRowHeight(y) { return Math.min(__afPanelRowH + 10, Math.max(1, __afPanelH - y)); }
    function __afPanelTimeRow(label, key, row, items, large) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = large ? __afPanelLargeRowHeight(y) : __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const desiredStepW = large ? Math.max(54, Math.round(72 * __afPanelScale)) : __afPanelStepW;
      const stepW = Math.min(desiredStepW, Math.max(20, Math.floor((box.w - 8) / 3)));
      const midW = Math.max(1, box.w - 2 * stepW - 4);
      const minus = __afPanelButton(box.x, y, stepW, h, '−', function () {
        __afProfilePrefs[key] = (__afProfilePrefs[key] + 23) % 24;
        __afProfileRefresh(); __afPanelRefresh();
      });
      const value = __afPanelButton(box.x + stepW + 2, y, midW, h, label, function () {});
      const plus = __afPanelButton(box.x + box.w - stepW, y, stepW, h, '+', function () {
        __afProfilePrefs[key] = (__afProfilePrefs[key] + 1) % 24;
        __afProfileRefresh(); __afPanelRefresh();
      });
      items.push(minus, value, plus);
      return { value: value, x: box.x + stepW + 2, y: y, w: midW, h: h };
    }
    function __afPanelRowButton(y, text, click, height) {
      const h = Math.min(height || __afPanelRowH - 2, Math.max(1, __afPanelH - y));
      const box = __afPanelRowBox(y, h);
      return __afPanelButton(box.x, y, box.w, h, text, click);
    }

    // The transparent screen-sized button makes the lower sheet modal while it is open.
    const __afPanelScrim = createWidget(widget.BUTTON, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: 0, w: __afPanelW, h: __afPanelH, text: '',
      normal_src: '', press_src: '', click_func: function () {},
    });
    __afPanelScrim.setAlpha(0);
    __afPanelSetVisible(__afPanelScrim, false);
    const __afPanelBg = createWidget(widget.FILL_RECT, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: __afPanelTop, w: __afPanelW, h: __afPanelHeight, color: 0x111923,
    });
    __afPanelSetVisible(__afPanelBg, false);
    const __afPanelHeaderY = __afPanelTop + __afPanelHeaderTop;
    const __afPanelHeaderInnerH = Math.max(20, __afPanelHeaderH - __afPanelHeaderTop - 2);
    const __afPanelHeaderBox = __afPanelRowBox(__afPanelHeaderY, __afPanelHeaderInnerH);
    // Слева небольшая шестерёнка (просто значок), справа крупная кнопка «Закрыть» с зазором от неё.
    const __afPanelHeaderGap = Math.max(8, Math.round(14 * __afPanelScale));
    const __afPanelGearW = Math.max(24, Math.min(Math.round(40 * __afPanelScale), Math.floor(__afPanelHeaderBox.w / 4)));
    const __afPanelCloseSize = Math.max(30, __afPanelHeaderBox.w - __afPanelGearW - __afPanelHeaderGap);
    const __afPanelTitle = __afPanelButton(__afPanelHeaderBox.x, __afPanelHeaderY, __afPanelGearW, __afPanelHeaderInnerH, '⚙', function () {});
    const __afPanelClose = __afPanelButton(__afPanelHeaderBox.x + __afPanelHeaderBox.w - __afPanelCloseSize, __afPanelHeaderY, __afPanelCloseSize, __afPanelHeaderInnerH, '×  Закрыть', function () {
      __afPanelVisible = false; __afPanelRefresh();
    });
    
    const __afProfileMenu = __afPanelRowButton(__afPanelRowY, 'День и ночь  ›', function () {
      __afPanelPage = 1; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY));
    const __afProfileDetails = [];
    const __afProfileMode = __afPanelRowButton(__afPanelRowY, '', function () {
      const modes = ['auto', 'day', 'night'];
      const i = modes.indexOf(__afProfilePrefs.profileMode);
      __afProfilePrefs.profileMode = modes[(i + 1 + modes.length) % modes.length];
      __afProfileRefresh(); __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY));
    __afProfileDetails.push(__afProfileMode);
    const __afProfileStart = __afPanelTimeRow('Ночной профиль с 22:00', 'profileStart', 2, __afProfileDetails, true);
    const __afProfileEnd = __afPanelTimeRow('Дневной профиль с 07:00', 'profileEnd', 4, __afProfileDetails, true);
    const __afProfileBack = __afPanelRowButton(__afPanelRowY + 9 * __afPanelRowH, '‹ Назад', function () {
      __afPanelPage = 0; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY + 9 * __afPanelRowH));
    __afProfileDetails.push(__afProfileBack);
    function __afPanelRefresh() {
      __afPanelSetVisible(__afPanelScrim, __afPanelVisible);
      __afPanelSetVisible(__afPanelBg, __afPanelVisible);
      __afPanelSetVisible(__afPanelTitle, __afPanelVisible);
      __afPanelSetVisible(__afPanelClose, __afPanelVisible);
      
      __afPanelSetVisible(__afProfileMenu, __afPanelVisible && __afPanelPage === 0);
      __afProfileDetails.forEach(function (w) { __afPanelSetVisible(w, __afPanelVisible && __afPanelPage === 1); });
      __afPanelSetText(__afPanelTitle, '⚙', __afPanelHeaderBox.x, __afPanelHeaderY, __afPanelGearW, __afPanelHeaderInnerH);
      
      __afPanelSetRowText(__afProfileMenu, 'День и ночь  ›', __afPanelRowY, __afPanelLargeRowHeight(__afPanelRowY));
      const profileNames = { auto: 'АВТО', day: 'ДЕНЬ', night: 'НОЧЬ' };
      __afPanelSetRowText(__afProfileMode, 'Режим циферблата: ' + (profileNames[__afProfilePrefs.profileMode] || 'АВТО'), __afPanelRowY, __afPanelLargeRowHeight(__afPanelRowY));
      __afPanelSetText(__afProfileStart.value, 'Ночной профиль с ' + __afPanelHour(__afProfilePrefs.profileStart), __afProfileStart.x, __afProfileStart.y, __afProfileStart.w, __afProfileStart.h);
      __afPanelSetText(__afProfileEnd.value, 'Дневной профиль с ' + __afPanelHour(__afProfilePrefs.profileEnd), __afProfileEnd.x, __afProfileEnd.y, __afProfileEnd.w, __afProfileEnd.h);
      __afPanelSetRowText(__afProfileBack, '‹ Назад', __afPanelRowY + 9 * __afPanelRowH, __afPanelLargeRowHeight(__afPanelRowY + 9 * __afPanelRowH));
      try { __afEdRefresh(); } catch (e) {}
      try { __afFlRefresh(); } catch (e) {}
    }
    function __afOpenSettings() {
      __afPanelVisible = true; __afPanelPage = 0; __afPanelRefresh();
    }
    // ---- Редактор текста на часах: список -> экран редактирования выбранного текста ----
    const __afEdPath = "amazface_edits_3412828_1792695551407.json";
    const __afEdSt = {};
    let __afEdSel = 0;
    let __afEdProfile = '';
    let __afEdPos = false;
    let __afEdPosSide = 'bottom';
    let __afEdPosLastT = 0;
    let __afEdPosLastDir = '';
    let __afEdPosRun = 0;
    let __afEdRH = __afPanelRowH;
    let __afEdStep = 2;
    let __afEdListPage = 0;
    const __afEdPerPage = 5;
    const __afEdColors = [
      0xff3b30, 0xff9500, 0xffcc00, 0x34c759, 0x00c7be, 0x0a84ff, 0xbf5af2, 0xff2d92,
      0x000000, 0xffffff, 0xd0d0d0, 0x909090, 0x8e1b14, 0xa85d00, 0x1d7a34, 0x0050a8,
    ];
    function __afEdCurrentItems() {
      const night = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night';
      return __afEd.filter(function (it) { return (String(it.id).indexOf('night:') === 0) === night; });
    }
    function __afEdLoad() {
      try {
        const result = hmFS.stat(__afEdPath);
        if (!result || result[1] !== 0 || !result[0] || result[0].size <= 0 || result[0].size > 8192) return;
        const file = hmFS.open(__afEdPath, hmFS.O_RDONLY);
        if (typeof file !== 'number' || file < 0) return;
        try {
          const bytes = new Uint8Array(result[0].size);
          hmFS.read(file, bytes.buffer, 0, bytes.length);
          const data = JSON.parse(String.fromCharCode.apply(null, bytes));
          if (!data || typeof data !== 'object') return;
          for (let i = 0; i < __afEd.length; i++) {
            const v = data[__afEd[i].id];
            if (Array.isArray(v) && v.length === 4) __afEdSt[__afEd[i].id] = [Number(v[0]) || 0, Number(v[1]) || 0, Number(v[2]) || 0, Number(v[3]) >= 0 ? Number(v[3]) : -1];
          }
        } finally { hmFS.close(file); }
      } catch (e) {}
    }
    function __afEdSave() {
      let file = -1;
      try {
        const out = {};
        for (const id in __afEdSt) {
          const v = __afEdSt[id];
          if (v[0] !== 0 || v[1] !== 0 || v[2] !== 0 || v[3] >= 0) out[id] = v;
        }
        const raw = JSON.stringify(out);
        const bytes = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) & 255;
        file = hmFS.open(__afEdPath, hmFS.O_RDWR | hmFS.O_CREAT | hmFS.O_TRUNC);
        if (typeof file === 'number' && file >= 0) hmFS.write(file, bytes.buffer, 0, bytes.length);
      } catch (e) {
      } finally {
        try { if (file >= 0) hmFS.close(file); } catch (e) {}
      }
    }
    function __afEdChanged(it) {
      const v = __afEdSt[it.id];
      return !!v && (v[0] !== 0 || v[1] !== 0 || v[2] !== 0 || v[3] >= 0);
    }
    function __afEdGeom(it) {
      const st = __afEdSt[it.id] || [0, 0, 0, -1];
      const ns = Math.max(8, Math.min(200, Math.round(it.s + st[2])));
      const nw = Math.max(1, Math.round(it.w * ns / it.s));
      const nh = Math.max(1, Math.round(it.ht * ns / it.s));
      let nx = it.x + st[0];
      if (it.ah === 'RIGHT') nx -= (nw - it.w);
      else if (it.ah !== 'LEFT') nx -= Math.floor((nw - it.w) / 2);
      const ny = it.y + st[1] - Math.floor((nh - it.ht) / 2);
      return { x: nx, y: ny, w: nw, h: nh, s: ns, c: st[3] >= 0 ? st[3] : it.c };
    }
    function __afEdApply(it) {
      const g = __afEdGeom(it);
      try { it.h.setProperty(prop.MORE, { x: g.x, y: g.y, w: g.w, h: g.h, text_size: g.s, color: g.c }); } catch (e) {}
    }
    function __afEdTouch(it) {
      return __afEdSt[it.id] || (__afEdSt[it.id] = [0, 0, 0, -1]);
    }
    function __afEdChange(k, d) {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      const st = __afEdTouch(it);
      st[k] += d;
      if (k === 2 && it.s + st[2] < 8) st[2] = 8 - it.s;
      if (k === 2 && it.s + st[2] > 200) st[2] = 200 - it.s;
      __afEdApply(it); __afEdSave(); __afPanelRefresh();
    }
    function __afEdSetColor(c) {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      __afEdTouch(it)[3] = c;
      __afEdApply(it); __afEdSave(); __afPanelRefresh();
    }
    function __afEdResetOne() {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      delete __afEdSt[it.id];
      __afEdApply(it); __afEdSave(); __afPanelRefresh();
    }
    function __afEdResetAll() {
      const items = __afEdCurrentItems();
      for (let i = 0; i < items.length; i++) { delete __afEdSt[items[i].id]; __afEdApply(items[i]); }
      __afEdSave(); __afPanelRefresh();
    }
    __afEdLoad();
    (function () { for (let i = 0; i < __afEd.length; i++) { if (__afEdSt[__afEd[i].id]) __afEdApply(__afEd[i]); } })();

    // Страница 3 — список текстов, страница 4 — редактирование выбранного.
    const __afEdListAll = [];
    const __afEdEditAll = [];
    const __afEdStatic = [];
    function __afEdBtn(list, x, y, w, h, text, click) {
      const b = __afPanelButton(x, y, w, h, text, click);
      list.push(b);
      if (text) __afEdStatic.push({ w: b, t: text, x: x, y: y, bw: w, h: h });
      return b;
    }
    function __afEdTitle(list, row, color) {
      const y = __afPanelRowY + row * __afEdRH;
      const h = __afEdRH - 2;
      const box = __afPanelRowBox(y, h);
      const w = createWidget(widget.TEXT, {
        show_level: show_level.ONLY_NORMAL,
        x: box.x, y: y, w: box.w, h: h, text: '',
        color: color, text_size: __afPanelFont,
        align_h: align.CENTER_H, align_v: align.CENTER_V,
      });
      __afPanelSetVisible(w, false);
      list.push(w);
      return { w: w, x: box.x, y: y, bw: box.w, h: h };
    }
    function __afEdFull(list, row, text, click) {
      const y = __afPanelRowY + row * __afEdRH;
      const h = __afEdRH - 2;
      const box = __afPanelRowBox(y, h);
      const b = __afEdBtn(list, box.x, y, box.w, h, text, click);
      return { w: b, x: box.x, y: y, bw: box.w, h: h };
    }
    // Общая ширина для нескольких строк: на круглом экране у каждой строки своя, а колонки должны быть ровными.
    function __afEdSharedBox(rows) {
      let left = 0, right = __afPanelW;
      rows.forEach(function (row) {
        const b = __afPanelRowBox(__afPanelRowY + row * __afEdRH, __afEdRH - 2);
        left = Math.max(left, b.x); right = Math.min(right, b.x + b.w);
      });
      return { x: left, w: Math.max(1, right - left) };
    }
    function __afEdHalves(list, row, textA, clickA, textB, clickB, shared) {
      const y = __afPanelRowY + row * __afEdRH;
      const h = __afEdRH - 2;
      const box = shared || __afPanelRowBox(y, h);
      const half = Math.floor((box.w - 4) / 2);
      const a = __afEdBtn(list, box.x, y, half, h, textA, clickA);
      const b = __afEdBtn(list, box.x + box.w - half, y, half, h, textB, clickB);
      return { a: a, b: b, ax: box.x, bx: box.x + box.w - half, y: y, bw: half, h: h };
    }
    function __afEdPages() { return Math.max(1, Math.ceil(__afEdCurrentItems().length / __afEdPerPage)); }

    const __afEdMenu = __afPanelRowButton(__afPanelRowY + 2 * __afPanelRowH, 'Редактор текста  ›', function () {
      __afEdSel = 0; __afEdListPage = 0; __afEdPos = false; __afPanelPage = 3; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY + 2 * __afPanelRowH));

    // Список: 9 строк вместо 10 — кнопки выше, в них проще попасть пальцем.
    __afEdRH = Math.floor(10 * __afPanelRowH / 9);
    const __afEdListTitle = __afEdTitle(__afEdListAll, 0, 0xffd60a);
    const __afEdItems = [];
    (function () {
      for (let slot = 0; slot < __afEdPerPage; slot++) {
        (function (sl) {
          const y = __afPanelRowY + (1 + sl) * __afEdRH;
          const h = __afEdRH - 2;
          const box = __afPanelRowBox(y, h);
          const b = __afEdBtn(__afEdListAll, box.x, y, box.w, h, '', function () {
            const idx = __afEdListPage * __afEdPerPage + sl;
            if (idx < __afEdCurrentItems().length) { __afEdSel = idx; __afEdPos = false; __afPanelPage = 4; __afPanelRefresh(); }
          });
          __afEdItems.push({ w: b, x: box.x, y: y, bw: box.w, h: h });
        })(slot);
      }
    })();
    __afEdHalves(__afEdListAll, 6, '‹ Пред.', function () {
      __afEdListPage = (__afEdListPage + __afEdPages() - 1) % __afEdPages(); __afPanelRefresh();
    }, 'След. ›', function () {
      __afEdListPage = (__afEdListPage + 1) % __afEdPages(); __afPanelRefresh();
    });
    __afEdFull(__afEdListAll, 7, 'Сбросить все правки', function () { __afEdResetAll(); });
    __afEdFull(__afEdListAll, 8, '‹ Назад', function () {
      __afPanelPage = 0; __afPanelRefresh();
    });

    // Редактирование выбранного текста: 8 крупных строк (были 10 мелких).
    __afEdRH = Math.floor(10 * __afPanelRowH / 8);
    const __afEdEditTitle = __afEdTitle(__afEdEditAll, 0, 0xffd60a);
    const __afEdValues = __afEdTitle(__afEdEditAll, 1, 0xffffff);
    (function () {
      const box = __afEdSharedBox([2, 3]);
      for (let r = 0; r < 2; r++) {
        const y = __afPanelRowY + (2 + r) * __afEdRH;
        const h = __afEdRH - 2;
        const gap = 2;
        const cw = Math.max(8, Math.floor((box.w - gap * 7) / 8));
        for (let c = 0; c < 8; c++) {
          (function (color) {
            const sw = createWidget(widget.BUTTON, {
              show_level: show_level.ONLY_NORMAL,
              x: box.x + c * (cw + gap), y: y, w: cw, h: h, text: '',
              normal_color: color, press_color: color,
              radius: Math.max(3, Math.round(6 * __afPanelScale)),
              click_func: function () { __afEdSetColor(color); },
            });
            __afPanelSetVisible(sw, false);
            __afEdEditAll.push(sw);
          })(__afEdColors[r * 8 + c]);
        }
      }
    })();
    const __afEdCtlBox = __afEdSharedBox([4]);
    __afEdHalves(__afEdEditAll, 4, '−  Размер', function () { __afEdChange(2, -__afEdStep); }, '+  Размер', function () { __afEdChange(2, __afEdStep); }, __afEdCtlBox);
    __afEdFull(__afEdEditAll, 5, 'Переместить на экране', function () {
      __afEdPosEnter();
    });
    const __afEdRow6 = __afEdHalves(__afEdEditAll, 6, '', function () {
      __afEdStep = __afEdStep === 2 ? 5 : 2; __afPanelRefresh();
    }, 'Сбросить', function () { __afEdResetOne(); });
    __afEdFull(__afEdEditAll, 7, '‹ К списку', function () {
      __afPanelPage = 3; __afEdPos = false; __afPanelRefresh();
    });
    const __afEdFrame = createWidget(widget.STROKE_RECT, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: 0, w: 10, h: 10, line_width: 2, color: 0xffd60a,
    });
    __afPanelSetVisible(__afEdFrame, false);

    // Экран «Переместить на экране»: циферблат + рамка вокруг текста + полупрозрачный крест.
    // Кнопки лежат у края экрана, противоположного тексту, и переезжают, когда текст пересекает середину.
    // Сдвиги применяются сразу, а в файл попадают по «OK».
    const __afEdPosAll = [];
    const __afEdPosBtns = {};
    const __afEdPosHold = {};
    let __afEdPosStopAll = function () {};
    (function () {
      const font = Math.max(18, Math.round(34 * __afPanelScale));
      // Зажатие: первый сдвиг сразу, через 450 мс — повтор каждые 90 мс, пока палец на кнопке.
      // Если события нажатия/отпускания на часах не сработают, обычный тап всё равно двигает на 1 px.
      function holdStop(key) {
        const h = __afEdPosHold[key];
        if (!h) return;
        try { if (h.delay) clearTimeout(h.delay); } catch (e) {}
        try { if (h.timer) clearInterval(h.timer); } catch (e) {}
        h.delay = 0; h.timer = 0;
      }
      function mk(key, text, color, dx, dy, tap) {
        __afEdPosHold[key] = { delay: 0, timer: 0, down: false };
        const b = createWidget(widget.BUTTON, {
          show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 10, h: 10, text: text,
          color: 0xffffff, text_size: font,
          normal_color: color, press_color: 0x5d7694,
          radius: Math.max(6, Math.round(14 * __afPanelScale)),
          click_func: function () {
            const h = __afEdPosHold[key];
            if (tap) { tap(); return; }
            if (h.down) { h.down = false; holdStop(key); return; }
            __afEdPosMove(dx, dy);
          },
        });
        if (!tap) {
          try {
            if (typeof event !== 'undefined' && b.addEventListener) {
              b.addEventListener(event.CLICK_DOWN, function () {
                const h = __afEdPosHold[key];
                holdStop(key);
                h.down = true;
                __afEdPosMove(dx, dy);
                h.delay = setTimeout(function () {
                  h.timer = setInterval(function () { __afEdPosMove(dx, dy); }, 90);
                }, 450);
              });
              b.addEventListener(event.CLICK_UP, function () { holdStop(key); });
              b.addEventListener(event.MOVE_OUT, function () { holdStop(key); __afEdPosHold[key].down = false; });
            }
          } catch (e) {}
        }
        try { b.setAlpha(150); } catch (e) {}
        __afPanelSetVisible(b, false);
        __afEdPosAll.push(b);
        __afEdPosBtns[key] = b;
      }
      __afEdPosStopAll = function () { for (const k in __afEdPosHold) holdStop(k); };
      mk('up', '↑', 0x253140, 0, -1);
      mk('left', '←', 0x253140, -1, 0);
      mk('ok', 'OK', 0x1f7a3a, 0, 0, function () { __afEdPosDone(); });
      mk('right', '→', 0x253140, 1, 0);
      mk('down', '↓', 0x253140, 0, 1);
    })();
    function __afEdPosLayout() {
      const cw = Math.round(100 * __afPanelScale);
      const ch = Math.round(64 * __afPanelScale);
      const gap = Math.max(2, Math.round(4 * __afPanelScale));
      const margin = Math.round(30 * __afPanelScale);
      const totalW = 3 * cw + 2 * gap;
      const totalH = 3 * ch + 2 * gap;
      const x0 = Math.round((__afPanelW - totalW) / 2);
      const y0 = __afEdPosSide === 'top' ? margin : __afPanelH - margin - totalH;
      const pw = cw + gap, ph = ch + gap;
      const cells = { up: [1, 0], left: [0, 1], ok: [1, 1], right: [2, 1], down: [1, 2] };
      for (const key in cells) {
        __afEdPosBtns[key].setProperty(prop.MORE, { x: x0 + cells[key][0] * pw, y: y0 + cells[key][1] * ph, w: cw, h: ch });
      }
    }
    // Текст ниже середины → кнопки сверху, и наоборот. Мёртвая зона в 24 px не даёт крестику
    // прыгать из-под пальца, пока текст ползёт через середину экрана.
    function __afEdPosUpdateSide(strict) {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      const g = __afEdGeom(it);
      const cy = g.y + g.h / 2;
      const mid = __afPanelH / 2;
      const dead = strict ? 0 : Math.round(24 * __afPanelScale);
      let side = __afEdPosSide;
      if (cy >= mid + dead) side = 'top';
      else if (cy < mid - dead) side = 'bottom';
      else if (strict) side = cy >= mid ? 'top' : 'bottom';
      __afEdPosSide = side;
    }
    function __afEdPosEnter() {
      __afEdPos = true; __afEdPosRun = 0; __afEdPosLastDir = ''; __afEdPosLastT = 0;
      __afEdPosUpdateSide(true);
      __afPanelRefresh();
    }
    // Один тап = 1 px. Если тапать в одну сторону подряд и быстро, шаг растёт (1 → 2 → 4 → 8),
    // пауза или смена направления возвращают шаг к 1 px.
    function __afEdPosMove(dx, dy) {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      let now = 0;
      try { now = Date.now(); } catch (e) { now = 0; }
      const dir = dx + ',' + dy;
      if (now && dir === __afEdPosLastDir && now - __afEdPosLastT < 600) __afEdPosRun++; else __afEdPosRun = 0;
      __afEdPosLastDir = dir; __afEdPosLastT = now;
      const mult = __afEdPosRun < 5 ? 1 : (__afEdPosRun < 10 ? 2 : (__afEdPosRun < 18 ? 4 : 8));
      const st = __afEdTouch(it);
      const ox = st[0], oy = st[1];
      st[0] += dx * mult; st[1] += dy * mult;
      const g = __afEdGeom(it);
      const cx = g.x + g.w / 2, cy = g.y + g.h / 2;
      if (cx < 0 || cx > __afPanelW || cy < 0 || cy > __afPanelH) { st[0] = ox; st[1] = oy; return; }
      __afEdApply(it);
      __afEdPosUpdateSide(false);
      __afPanelRefresh();
    }
    function __afEdPosDone() {
      __afEdPosStopAll();
      __afEdPos = false;
      __afEdSave();
      __afPanelRefresh();
    }

    function __afEdCut(text, n) {
      text = String(text);
      return text.length > n ? text.slice(0, n - 1) + '.' : text;
    }
    function __afEdRefresh() {
      const vis = __afPanelVisible;
      const activeProfile = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night' ? 'night' : 'day';
      if (__afEdProfile && __afEdProfile !== activeProfile && (__afPanelPage === 3 || __afPanelPage === 4)) {
        __afPanelPage = 3; __afEdSel = 0; __afEdListPage = 0; __afEdPos = false;
      }
      __afEdProfile = activeProfile;
      const onList = vis && __afPanelPage === 3;
      const inEd = vis && __afPanelPage === 4;
      const onEd = inEd && !__afEdPos;
      const onPos = inEd && __afEdPos;
      const currentItems = __afEdCurrentItems();
      if (__afEdSel >= currentItems.length) __afEdSel = 0;
      const it = currentItems[__afEdSel];
      __afPanelSetVisible(__afEdMenu, vis && __afPanelPage === 0);
      __afEdListAll.forEach(function (w) { __afPanelSetVisible(w, onList); });
      __afEdEditAll.forEach(function (w) { __afPanelSetVisible(w, onEd); });
      __afEdPosAll.forEach(function (w) { __afPanelSetVisible(w, onPos); });
      // Рамка только на экране перемещения: поверх панели она перекрывала бы кнопки.
      __afPanelSetVisible(__afEdFrame, onPos && !!it);
      if (onPos) {
        __afEdPosLayout();
        __afPanelSetVisible(__afPanelBg, false);
        __afPanelSetVisible(__afPanelTitle, false);
        __afPanelSetVisible(__afPanelClose, false);
      }
      __afPanelSetRowText(__afEdMenu, 'Редактор текста  ›', __afPanelRowY + 2 * __afPanelRowH, __afPanelLargeRowHeight(__afPanelRowY + 2 * __afPanelRowH));
      __afEdStatic.forEach(function (r) { __afPanelSetText(r.w, r.t, r.x, r.y, r.bw, r.h); });
      if (onList) {
        const sceneName = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night' ? 'Ночь' : 'День';
        __afPanelSetText(__afEdListTitle.w, (currentItems.length ? 'Тексты: ' : 'Нет текстов: ') + sceneName + ' ' + (__afEdListPage + 1) + '/' + __afEdPages(), __afEdListTitle.x, __afEdListTitle.y, __afEdListTitle.bw, __afEdListTitle.h);
        for (let sl = 0; sl < __afEdItems.length; sl++) {
          const idx = __afEdListPage * __afEdPerPage + sl;
          const row = __afEdItems[sl];
          const item = currentItems[idx];
          if (!item) { __afPanelSetVisible(row.w, false); continue; }
          const label = (__afEdChanged(item) ? '* ' : '') + (idx + 1) + '. ' + item.n + (item.d ? ' - ' + item.d : '');
          __afPanelSetText(row.w, __afEdCut(label, 26), row.x, row.y, row.bw, row.h);
        }
      }
      if (inEd && it) {
        const g = __afEdGeom(it);
        try { __afEdFrame.setProperty(prop.MORE, { x: g.x - 2, y: g.y - 2, w: g.w + 4, h: g.h + 4 }); } catch (e) {}
      }
      if (onEd && it) {
        const g = __afEdGeom(it);
        const st = __afEdSt[it.id] || [0, 0, 0, -1];
        const sceneTag = activeProfile === 'night' ? ' [НОЧЬ]' : ' [ДЕНЬ]';
        __afPanelSetText(__afEdEditTitle.w, __afEdCut(it.n + (it.d ? ' - ' + it.d : '') + sceneTag, 26), __afEdEditTitle.x, __afEdEditTitle.y, __afEdEditTitle.bw, __afEdEditTitle.h);
        __afPanelSetText(__afEdValues.w, 'Размер ' + g.s + '   X ' + (it.x + st[0]) + '   Y ' + (it.y + st[1]), __afEdValues.x, __afEdValues.y, __afEdValues.bw, __afEdValues.h);
        __afPanelSetText(__afEdRow6.a, 'Шаг размера: ' + __afEdStep, __afEdRow6.ax, __afEdRow6.y, __afEdRow6.bw, __afEdRow6.h);
      }
    }
    // ---- Плавающий AOD: вкл./выкл., частота, шаг, отступ ----
    const __afFlIvList = [1, 5, 10, 30, 60];
    const __afFlStList = [1, 2, 3, 4, 6, 8, 10, 15, 20, 30, 40, 60];
    const __afFlMgList = [0, 6, 12, 20, 30, 40, 60, 90];
    function __afFlMove(list, value, dir) {
      let i = 0;
      for (let k = 0; k < list.length; k++) if (Math.abs(list[k] - value) < Math.abs(list[i] - value)) i = k;
      i = Math.max(0, Math.min(list.length - 1, i + dir));
      return list[i];
    }
    function __afFlIvText(v) { return v === 60 ? 'Частота 1 мин' : 'Частота ' + v + ' с'; }
    function __afPanelValueRow(row, items, onMinus, onPlus) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelLargeRowHeight(y);
      const box = __afPanelRowBox(y, h);
      const stepW = Math.min(Math.max(54, Math.round(72 * __afPanelScale)), Math.max(20, Math.floor((box.w - 8) / 3)));
      const midW = Math.max(1, box.w - 2 * stepW - 4);
      const minus = __afPanelButton(box.x, y, stepW, h, '−', onMinus);
      const value = __afPanelButton(box.x + stepW + 2, y, midW, h, '', function () {});
      const plus = __afPanelButton(box.x + box.w - stepW, y, stepW, h, '+', onPlus);
      items.push(minus, value, plus);
      return { value: value, x: box.x + stepW + 2, y: y, w: midW, h: h };
    }
    const __afFlMenuY = __afPanelRowY + 4 * __afPanelRowH;
    const __afFlMenu = __afPanelRowButton(__afFlMenuY, 'Плавающий AOD  ›', function () {
      __afPanelPage = 5; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afFlMenuY));
    const __afFlDetails = [];
    const __afFlToggle = __afPanelRowButton(__afPanelRowY, '', function () {
      __afFloatCur.on = !__afFloatCur.on; __afFloatApply(); __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY));
    __afFlDetails.push(__afFlToggle);
    const __afFlIv = __afPanelValueRow(2, __afFlDetails,
      function () { __afFloatCur.iv = __afFlMove(__afFlIvList, __afFloatCur.iv, -1); __afFloatApply(); __afPanelRefresh(); },
      function () { __afFloatCur.iv = __afFlMove(__afFlIvList, __afFloatCur.iv, 1); __afFloatApply(); __afPanelRefresh(); });
    const __afFlSt = __afPanelValueRow(4, __afFlDetails,
      function () { __afFloatCur.st = __afFlMove(__afFlStList, __afFloatCur.st, -1); __afFloatApply(); __afPanelRefresh(); },
      function () { __afFloatCur.st = __afFlMove(__afFlStList, __afFloatCur.st, 1); __afFloatApply(); __afPanelRefresh(); });
    const __afFlMg = __afPanelValueRow(6, __afFlDetails,
      function () { __afFloatCur.mg = __afFlMove(__afFlMgList, __afFloatCur.mg, -1); __afFloatApply(); __afPanelRefresh(); },
      function () { __afFloatCur.mg = __afFlMove(__afFlMgList, __afFloatCur.mg, 1); __afFloatApply(); __afPanelRefresh(); });
    const __afFlBackY = __afPanelRowY + 9 * __afPanelRowH;
    const __afFlBack = __afPanelRowButton(__afFlBackY, '‹ Назад', function () {
      __afPanelPage = 0; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afFlBackY));
    __afFlDetails.push(__afFlBack);
    function __afFlRefresh() {
      const vis = __afPanelVisible;
      __afPanelSetVisible(__afFlMenu, vis && __afPanelPage === 0);
      __afFlDetails.forEach(function (w) { __afPanelSetVisible(w, vis && __afPanelPage === 5); });
      __afPanelSetRowText(__afFlMenu, 'Плавающий AOD  ›', __afFlMenuY, __afPanelLargeRowHeight(__afFlMenuY));
      __afPanelSetRowText(__afFlToggle, 'Плавающий AOD: ' + (__afFloatCur.on ? 'ВКЛ' : 'ВЫКЛ'), __afPanelRowY, __afPanelLargeRowHeight(__afPanelRowY));
      __afPanelSetText(__afFlIv.value, __afFlIvText(__afFloatCur.iv), __afFlIv.x, __afFlIv.y, __afFlIv.w, __afFlIv.h);
      __afPanelSetText(__afFlSt.value, 'Шаг ' + __afFloatCur.st + ' px', __afFlSt.x, __afFlSt.y, __afFlSt.w, __afFlSt.h);
      __afPanelSetText(__afFlMg.value, 'Отступ ' + __afFloatCur.mg + ' px', __afFlMg.x, __afFlMg.y, __afFlMg.w, __afFlMg.h);
      __afPanelSetRowText(__afFlBack, __afFloatSaveOk ? '‹ Назад' : '‹ Назад · ошибка записи', __afFlBackY, __afPanelLargeRowHeight(__afFlBackY));
    }
    __afPanelRefresh();
    __afProfileRefresh();
    self._dayNightTimer = setInterval(__afProfileRefresh, 30000);
    try { createWidget(widget.WIDGET_DELEGATE, { resume_call: function () { try { __afProfileRefresh(); } catch (e) {} } }); } catch (e) {}
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._timeTimerNight) { clearInterval(this._timeTimerNight); this._timeTimerNight = null; }
    if (this._sensorTimerNight) { clearInterval(this._sensorTimerNight); this._sensorTimerNight = null; }
    if (this._smoothTimerNight) { clearInterval(this._smoothTimerNight); this._smoothTimerNight = null; }
    if (this._dayNightTimer) { clearInterval(this._dayNightTimer); this._dayNightTimer = null; }
    try { __taDestroy(); } catch (e) {}
    if (this._floatTimers) { for (let i = 0; i < this._floatTimers.length; i++) clearInterval(this._floatTimers[i]); this._floatTimers = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
