import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time, Battery, Step, Calorie, HeartRate, Screen } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _heart = null;

// Dual scene runtime: Normal and AOD are both exported into this one watchface.
// Zepp OS controls visibility through the documented widget show_level property.
WatchFace({
  build() {
    const self = this;

    // Normal scene widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "futuristicheskaya_panel_upravleniya_istrebitelya_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 151, w: 300, h: 100, text_size: 48, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 372, w: 200, h: 50, text_size: 33, color: 0x76efda, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_2_text_002 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 398, w: 200, h: 50, text_size: 30, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_3_text_003 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 136, w: 200, h: 50, text_size: 26, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_4_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 343, y: 142, w: 100, h: 36, text_size: 28, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_5_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 54, y: 342, w: 100, h: 30, text_size: 28, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_6_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 17, y: 246, w: 100, h: 36, text_size: 28, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 325, y: 345, w: 100, h: 32, text_size: 32, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.PAI_DAILY, unit_type: 0 });
          const normal_w_8_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 371, y: 244, w: 90, h: 40, text_size: 28, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 38, y: 146, w: 100, h: 40, text_size: 33, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 180, y: 238, w: 120, h: 32, text_size: 26, color: 0x32736d, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.ALARM_CLOCK, unit_type: 1 });
          createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 247, w: 200, h: 50, text_size: 10, color: 0x37736f, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "следующий будильник" });
          const normal_w_12_text_005_wd = ["premium_text_005_d0.png","premium_text_005_d1.png","premium_text_005_d2.png","premium_text_005_d3.png","premium_text_005_d4.png","premium_text_005_d5.png","premium_text_005_d6.png"];
          const normal_w_12_text_005 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 139, y: 199, w: 202, h: 202, src: normal_w_12_text_005_wd[new Date().getDay()] });
          normal_w_12_text_005.setAlpha(255);
          const normal_w_13_arc_001_a = [-70, -53, -37, -20, -4, 13, 29, 46, 62, 79, 95, 112, 128, 145, 161, 178, 194, 211, 227, 244], normal_w_13_arc_001_b = [-63, -47, -30, -14, 3, 19, 36, 52, 69, 85, 102, 118, 135, 151, 168, 184, 201, 217, 234, 250], normal_w_13_arc_001_c = [0xff0000, 0xf20d03, 0xe41b07, 0xd7280a, 0xc9360d, 0xbc4311, 0xae5114, 0xa15e18, 0x946b1b, 0x86791e, 0x798622, 0x6b9425, 0x5ea128, 0x51ae2c, 0x43bc2f, 0x36c933, 0x28d736, 0x1be439, 0x0df23d, 0x00ff40];
          const normal_w_13_arc_001_trk = [];
          for (let normal_w_13_arc_001_ti = 0; normal_w_13_arc_001_ti < 20; normal_w_13_arc_001_ti++) {
            normal_w_13_arc_001_trk.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 353, y: 116, w: 78, h: 78, start_angle: normal_w_13_arc_001_a[normal_w_13_arc_001_ti], end_angle: normal_w_13_arc_001_b[normal_w_13_arc_001_ti], color: 0x0f3a42, line_width: 5, corner_flag: 1 }));
          }
          const normal_w_13_arc_001_segs = [], normal_w_13_arc_001_vis = [];
          for (let normal_w_13_arc_001_i = 0; normal_w_13_arc_001_i < 20; normal_w_13_arc_001_i++) {
            normal_w_13_arc_001_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 353, y: 116, w: 78, h: 78, start_angle: normal_w_13_arc_001_a[normal_w_13_arc_001_i], end_angle: normal_w_13_arc_001_a[normal_w_13_arc_001_i], color: normal_w_13_arc_001_c[normal_w_13_arc_001_i], line_width: 5, corner_flag: 1 }));
            normal_w_13_arc_001_segs[normal_w_13_arc_001_i].setProperty(prop.VISIBLE, false);   // пустой сегмент со скруглением нарисовал бы точку
            normal_w_13_arc_001_vis[normal_w_13_arc_001_i] = false;
          }
          // Дуга normal_w_13_arc_001: значение из источника BATTERY, углы на часах -70°…250° (0° = 3 часа)
          let normal_w_13_arc_001_target = 0, normal_w_13_arc_001_phase = 0, normal_w_13_arc_001_timer = null, normal_w_13_arc_001_err = false;
          const normal_w_13_arc_001_last = [];
          function normal_w_13_arc_001_draw(r, f, g) {
            try {
              const cur = -70 + (320) * r;
              const lw = 5;
              for (let normal_w_13_arc_001_k = 0; normal_w_13_arc_001_k < 20; normal_w_13_arc_001_k++) {
                const a = normal_w_13_arc_001_a[normal_w_13_arc_001_k], b = normal_w_13_arc_001_b[normal_w_13_arc_001_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));
                const col = normal_w_13_arc_001_c[normal_w_13_arc_001_k];
                const key = end + ':' + col + ':' + lw;
                if (normal_w_13_arc_001_last[normal_w_13_arc_001_k] === key) continue;
                normal_w_13_arc_001_last[normal_w_13_arc_001_k] = key;
                if (end === a) { if (normal_w_13_arc_001_vis[normal_w_13_arc_001_k]) { normal_w_13_arc_001_vis[normal_w_13_arc_001_k] = false; normal_w_13_arc_001_segs[normal_w_13_arc_001_k].setProperty(prop.VISIBLE, false); } continue; }
                normal_w_13_arc_001_segs[normal_w_13_arc_001_k].setProperty(prop.MORE, { x: 353, y: 116, w: 78, h: 78, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!normal_w_13_arc_001_vis[normal_w_13_arc_001_k]) { normal_w_13_arc_001_vis[normal_w_13_arc_001_k] = true; normal_w_13_arc_001_segs[normal_w_13_arc_001_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_13_arc_001_err) { normal_w_13_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_13_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_13_arc_001_target = v;
            if (normal_w_13_arc_001_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_13_arc_001_phase === 0) { normal_w_13_arc_001_phase = 1; normal_w_13_arc_001_run(); return; }
            normal_w_13_arc_001_draw(v, 1, 1);
          }
          function normal_w_13_arc_001_run() {
            let n = 0;
            normal_w_13_arc_001_draw(0, 0, 0);
            normal_w_13_arc_001_timer = setInterval(() => {
              n++;
              if (n <= 5) return;
              const k = Math.min(1, (n - 5) / 30);
              const e = ((k) < 0.5 ? 4 * (k) * (k) * (k) : 1 - Math.pow(-2 * (k) + 2, 3) / 2);
              normal_w_13_arc_001_draw((k < 0.5 ? ((2 * k) < 0.5 ? 4 * (2 * k) * (2 * k) * (2 * k) : 1 - Math.pow(-2 * (2 * k) + 2, 3) / 2) : 1 - (1 - normal_w_13_arc_001_target) * ((2 * k - 1) < 0.5 ? 4 * (2 * k - 1) * (2 * k - 1) * (2 * k - 1) : 1 - Math.pow(-2 * (2 * k - 1) + 2, 3) / 2)), 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_13_arc_001_timer); normal_w_13_arc_001_timer = null; normal_w_13_arc_001_phase = 2;
                normal_w_13_arc_001_draw(normal_w_13_arc_001_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_13_arc_001_replay() {
            if (normal_w_13_arc_001_phase !== 2) return;
            normal_w_13_arc_001_phase = 1;
            normal_w_13_arc_001_run();
          }
          const normal_w_14_arc_002_a = [-70, -53, -37, -20, -4, 13, 29, 46, 62, 79, 95, 112, 128, 145, 161, 178, 194, 211, 227, 244], normal_w_14_arc_002_b = [-63, -47, -30, -14, 3, 19, 36, 52, 69, 85, 102, 118, 135, 151, 168, 184, 201, 217, 234, 250], normal_w_14_arc_002_c = [0x00ff40, 0x0df23d, 0x1be439, 0x28d736, 0x36c933, 0x43bc2f, 0x51ae2c, 0x5ea128, 0x6b9425, 0x798622, 0x86791e, 0x946b1b, 0xa15e18, 0xae5114, 0xbc4311, 0xc9360d, 0xd7280a, 0xe41b07, 0xf20d03, 0xff0000];
          const normal_w_14_arc_002_trk = [];
          for (let normal_w_14_arc_002_ti = 0; normal_w_14_arc_002_ti < 20; normal_w_14_arc_002_ti++) {
            normal_w_14_arc_002_trk.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 28, y: 217, w: 78, h: 78, start_angle: normal_w_14_arc_002_a[normal_w_14_arc_002_ti], end_angle: normal_w_14_arc_002_b[normal_w_14_arc_002_ti], color: 0x0f3a42, line_width: 5, corner_flag: 1 }));
          }
          const normal_w_14_arc_002_segs = [], normal_w_14_arc_002_vis = [];
          for (let normal_w_14_arc_002_i = 0; normal_w_14_arc_002_i < 20; normal_w_14_arc_002_i++) {
            normal_w_14_arc_002_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 28, y: 217, w: 78, h: 78, start_angle: normal_w_14_arc_002_a[normal_w_14_arc_002_i], end_angle: normal_w_14_arc_002_a[normal_w_14_arc_002_i], color: normal_w_14_arc_002_c[normal_w_14_arc_002_i], line_width: 5, corner_flag: 1 }));
            normal_w_14_arc_002_segs[normal_w_14_arc_002_i].setProperty(prop.VISIBLE, false);   // пустой сегмент со скруглением нарисовал бы точку
            normal_w_14_arc_002_vis[normal_w_14_arc_002_i] = false;
          }
          // Дуга normal_w_14_arc_002: значение из источника HEART, углы на часах -70°…250° (0° = 3 часа)
          let normal_w_14_arc_002_target = 0, normal_w_14_arc_002_phase = 0, normal_w_14_arc_002_timer = null, normal_w_14_arc_002_err = false;
          const normal_w_14_arc_002_last = [];
          function normal_w_14_arc_002_draw(r, f, g) {
            try {
              const cur = -70 + (320) * r;
              const lw = 5;
              for (let normal_w_14_arc_002_k = 0; normal_w_14_arc_002_k < 20; normal_w_14_arc_002_k++) {
                const a = normal_w_14_arc_002_a[normal_w_14_arc_002_k], b = normal_w_14_arc_002_b[normal_w_14_arc_002_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));
                const col = normal_w_14_arc_002_c[normal_w_14_arc_002_k];
                const key = end + ':' + col + ':' + lw;
                if (normal_w_14_arc_002_last[normal_w_14_arc_002_k] === key) continue;
                normal_w_14_arc_002_last[normal_w_14_arc_002_k] = key;
                if (end === a) { if (normal_w_14_arc_002_vis[normal_w_14_arc_002_k]) { normal_w_14_arc_002_vis[normal_w_14_arc_002_k] = false; normal_w_14_arc_002_segs[normal_w_14_arc_002_k].setProperty(prop.VISIBLE, false); } continue; }
                normal_w_14_arc_002_segs[normal_w_14_arc_002_k].setProperty(prop.MORE, { x: 28, y: 217, w: 78, h: 78, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!normal_w_14_arc_002_vis[normal_w_14_arc_002_k]) { normal_w_14_arc_002_vis[normal_w_14_arc_002_k] = true; normal_w_14_arc_002_segs[normal_w_14_arc_002_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_14_arc_002_err) { normal_w_14_arc_002_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_14_arc_002_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_14_arc_002_target = v;
            if (normal_w_14_arc_002_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_14_arc_002_phase === 0) { normal_w_14_arc_002_phase = 1; normal_w_14_arc_002_run(); return; }
            normal_w_14_arc_002_draw(v, 1, 1);
          }
          function normal_w_14_arc_002_run() {
            let n = 0;
            normal_w_14_arc_002_draw(0, 0, 0);
            normal_w_14_arc_002_timer = setInterval(() => {
              n++;
              if (n <= 5) return;
              const k = Math.min(1, (n - 5) / 30);
              const e = ((k) < 0.5 ? 4 * (k) * (k) * (k) : 1 - Math.pow(-2 * (k) + 2, 3) / 2);
              normal_w_14_arc_002_draw((k < 0.5 ? ((2 * k) < 0.5 ? 4 * (2 * k) * (2 * k) * (2 * k) : 1 - Math.pow(-2 * (2 * k) + 2, 3) / 2) : 1 - (1 - normal_w_14_arc_002_target) * ((2 * k - 1) < 0.5 ? 4 * (2 * k - 1) * (2 * k - 1) * (2 * k - 1) : 1 - Math.pow(-2 * (2 * k - 1) + 2, 3) / 2)), 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_14_arc_002_timer); normal_w_14_arc_002_timer = null; normal_w_14_arc_002_phase = 2;
                normal_w_14_arc_002_draw(normal_w_14_arc_002_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_14_arc_002_replay() {
            if (normal_w_14_arc_002_phase !== 2) return;
            normal_w_14_arc_002_phase = 1;
            normal_w_14_arc_002_run();
          }
          const normal_w_15_arc_003_a = [-70, -56, -43, -29, -15, -2, 12, 26, 39, 53, 67, 80, 94, 108, 121, 135, 149, 162, 176, 190, 203, 217, 231, 244], normal_w_15_arc_003_b = [-64, -51, -37, -23, -10, 4, 18, 31, 45, 59, 72, 86, 100, 113, 127, 141, 154, 168, 182, 195, 209, 223, 236, 250], normal_w_15_arc_003_c = [0xff0000, 0xf40b03, 0xe91606, 0xde2108, 0xd32c0b, 0xc8370e, 0xbc4311, 0xb14e13, 0xa65916, 0x9b6419, 0x906f1c, 0x857a1f, 0x7a8521, 0x6f9024, 0x649b27, 0x59a62a, 0x4eb12d, 0x43bc2f, 0x37c832, 0x2cd335, 0x21de38, 0x16e93a, 0x0bf43d, 0x00ff40];
          const normal_w_15_arc_003_trk = [];
          for (let normal_w_15_arc_003_ti = 0; normal_w_15_arc_003_ti < 24; normal_w_15_arc_003_ti++) {
            normal_w_15_arc_003_trk.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 376, y: 218, w: 78, h: 78, start_angle: normal_w_15_arc_003_a[normal_w_15_arc_003_ti], end_angle: normal_w_15_arc_003_b[normal_w_15_arc_003_ti], color: 0x0f3a42, line_width: 5, corner_flag: 1 }));
          }
          const normal_w_15_arc_003_segs = [], normal_w_15_arc_003_vis = [];
          for (let normal_w_15_arc_003_i = 0; normal_w_15_arc_003_i < 24; normal_w_15_arc_003_i++) {
            normal_w_15_arc_003_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 376, y: 218, w: 78, h: 78, start_angle: normal_w_15_arc_003_a[normal_w_15_arc_003_i], end_angle: normal_w_15_arc_003_a[normal_w_15_arc_003_i], color: normal_w_15_arc_003_c[normal_w_15_arc_003_i], line_width: 5, corner_flag: 1 }));
            normal_w_15_arc_003_segs[normal_w_15_arc_003_i].setProperty(prop.VISIBLE, false);   // пустой сегмент со скруглением нарисовал бы точку
            normal_w_15_arc_003_vis[normal_w_15_arc_003_i] = false;
          }
          // Дуга normal_w_15_arc_003: значение из источника CALORIE, углы на часах -70°…250° (0° = 3 часа)
          let normal_w_15_arc_003_target = 0, normal_w_15_arc_003_phase = 0, normal_w_15_arc_003_timer = null, normal_w_15_arc_003_err = false;
          const normal_w_15_arc_003_last = [];
          function normal_w_15_arc_003_draw(r, f, g) {
            try {
              const cur = -70 + (320) * r;
              const lw = 5;
              for (let normal_w_15_arc_003_k = 0; normal_w_15_arc_003_k < 24; normal_w_15_arc_003_k++) {
                const a = normal_w_15_arc_003_a[normal_w_15_arc_003_k], b = normal_w_15_arc_003_b[normal_w_15_arc_003_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));
                const col = normal_w_15_arc_003_c[normal_w_15_arc_003_k];
                const key = end + ':' + col + ':' + lw;
                if (normal_w_15_arc_003_last[normal_w_15_arc_003_k] === key) continue;
                normal_w_15_arc_003_last[normal_w_15_arc_003_k] = key;
                if (end === a) { if (normal_w_15_arc_003_vis[normal_w_15_arc_003_k]) { normal_w_15_arc_003_vis[normal_w_15_arc_003_k] = false; normal_w_15_arc_003_segs[normal_w_15_arc_003_k].setProperty(prop.VISIBLE, false); } continue; }
                normal_w_15_arc_003_segs[normal_w_15_arc_003_k].setProperty(prop.MORE, { x: 376, y: 218, w: 78, h: 78, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!normal_w_15_arc_003_vis[normal_w_15_arc_003_k]) { normal_w_15_arc_003_vis[normal_w_15_arc_003_k] = true; normal_w_15_arc_003_segs[normal_w_15_arc_003_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_15_arc_003_err) { normal_w_15_arc_003_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_15_arc_003_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_15_arc_003_target = v;
            if (normal_w_15_arc_003_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_15_arc_003_phase === 0) { normal_w_15_arc_003_phase = 1; normal_w_15_arc_003_run(); return; }
            normal_w_15_arc_003_draw(v, 1, 1);
          }
          function normal_w_15_arc_003_run() {
            let n = 0;
            normal_w_15_arc_003_draw(0, 0, 0);
            normal_w_15_arc_003_timer = setInterval(() => {
              n++;
              if (n <= 5) return;
              const k = Math.min(1, (n - 5) / 30);
              const e = ((k) < 0.5 ? 4 * (k) * (k) * (k) : 1 - Math.pow(-2 * (k) + 2, 3) / 2);
              normal_w_15_arc_003_draw((k < 0.5 ? ((2 * k) < 0.5 ? 4 * (2 * k) * (2 * k) * (2 * k) : 1 - Math.pow(-2 * (2 * k) + 2, 3) / 2) : 1 - (1 - normal_w_15_arc_003_target) * ((2 * k - 1) < 0.5 ? 4 * (2 * k - 1) * (2 * k - 1) * (2 * k - 1) : 1 - Math.pow(-2 * (2 * k - 1) + 2, 3) / 2)), 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_15_arc_003_timer); normal_w_15_arc_003_timer = null; normal_w_15_arc_003_phase = 2;
                normal_w_15_arc_003_draw(normal_w_15_arc_003_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_15_arc_003_replay() {
            if (normal_w_15_arc_003_phase !== 2) return;
            normal_w_15_arc_003_phase = 1;
            normal_w_15_arc_003_run();
          }
          const normal_w_16_arc_004_a = [-70, -56, -43, -29, -15, -2, 12, 25, 39, 53, 66, 80, 94, 107, 121, 134, 148, 162, 175, 189, 203, 216, 230, 243], normal_w_16_arc_004_b = [-63, -50, -36, -22, -9, 5, 18, 32, 46, 59, 73, 87, 100, 114, 127, 141, 155, 168, 182, 196, 209, 223, 236, 250], normal_w_16_arc_004_c = [0xf70202, 0xec0c02, 0xe21702, 0xd72102, 0xcd2b02, 0xc23602, 0xb84001, 0xad4a01, 0xa25501, 0x985f01, 0x8d6901, 0x837401, 0x787e01, 0x6e8901, 0x639301, 0x599d01, 0x4ea801, 0x43b201, 0x39bc00, 0x2ec700, 0x24d100, 0x19db00, 0x0fe600, 0x04f000];
          const normal_w_16_arc_004_trk = [];
          for (let normal_w_16_arc_004_ti = 0; normal_w_16_arc_004_ti < 24; normal_w_16_arc_004_ti++) {
            normal_w_16_arc_004_trk.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 60, y: 309, w: 90, h: 90, start_angle: normal_w_16_arc_004_a[normal_w_16_arc_004_ti], end_angle: normal_w_16_arc_004_b[normal_w_16_arc_004_ti], color: 0x0f3a42, line_width: 5, corner_flag: 1 }));
          }
          const normal_w_16_arc_004_segs = [], normal_w_16_arc_004_vis = [];
          for (let normal_w_16_arc_004_i = 0; normal_w_16_arc_004_i < 24; normal_w_16_arc_004_i++) {
            normal_w_16_arc_004_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 60, y: 309, w: 90, h: 90, start_angle: normal_w_16_arc_004_a[normal_w_16_arc_004_i], end_angle: normal_w_16_arc_004_a[normal_w_16_arc_004_i], color: normal_w_16_arc_004_c[normal_w_16_arc_004_i], line_width: 5, corner_flag: 1 }));
            normal_w_16_arc_004_segs[normal_w_16_arc_004_i].setProperty(prop.VISIBLE, false);   // пустой сегмент со скруглением нарисовал бы точку
            normal_w_16_arc_004_vis[normal_w_16_arc_004_i] = false;
          }
          // Дуга normal_w_16_arc_004: значение из источника STEP, углы на часах -70°…250° (0° = 3 часа)
          let normal_w_16_arc_004_target = 0, normal_w_16_arc_004_phase = 0, normal_w_16_arc_004_timer = null, normal_w_16_arc_004_err = false;
          const normal_w_16_arc_004_last = [];
          function normal_w_16_arc_004_draw(r, f, g) {
            try {
              const cur = -70 + (320) * r;
              const lw = 5;
              for (let normal_w_16_arc_004_k = 0; normal_w_16_arc_004_k < 24; normal_w_16_arc_004_k++) {
                const a = normal_w_16_arc_004_a[normal_w_16_arc_004_k], b = normal_w_16_arc_004_b[normal_w_16_arc_004_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));
                const col = normal_w_16_arc_004_c[normal_w_16_arc_004_k];
                const key = end + ':' + col + ':' + lw;
                if (normal_w_16_arc_004_last[normal_w_16_arc_004_k] === key) continue;
                normal_w_16_arc_004_last[normal_w_16_arc_004_k] = key;
                if (end === a) { if (normal_w_16_arc_004_vis[normal_w_16_arc_004_k]) { normal_w_16_arc_004_vis[normal_w_16_arc_004_k] = false; normal_w_16_arc_004_segs[normal_w_16_arc_004_k].setProperty(prop.VISIBLE, false); } continue; }
                normal_w_16_arc_004_segs[normal_w_16_arc_004_k].setProperty(prop.MORE, { x: 60, y: 309, w: 90, h: 90, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!normal_w_16_arc_004_vis[normal_w_16_arc_004_k]) { normal_w_16_arc_004_vis[normal_w_16_arc_004_k] = true; normal_w_16_arc_004_segs[normal_w_16_arc_004_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_16_arc_004_err) { normal_w_16_arc_004_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_16_arc_004_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_16_arc_004_target = v;
            if (normal_w_16_arc_004_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_16_arc_004_phase === 0) { normal_w_16_arc_004_phase = 1; normal_w_16_arc_004_run(); return; }
            normal_w_16_arc_004_draw(v, 1, 1);
          }
          function normal_w_16_arc_004_run() {
            let n = 0;
            normal_w_16_arc_004_draw(0, 0, 0);
            normal_w_16_arc_004_timer = setInterval(() => {
              n++;
              if (n <= 5) return;
              const k = Math.min(1, (n - 5) / 30);
              const e = ((k) < 0.5 ? 4 * (k) * (k) * (k) : 1 - Math.pow(-2 * (k) + 2, 3) / 2);
              normal_w_16_arc_004_draw((k < 0.5 ? ((2 * k) < 0.5 ? 4 * (2 * k) * (2 * k) * (2 * k) : 1 - Math.pow(-2 * (2 * k) + 2, 3) / 2) : 1 - (1 - normal_w_16_arc_004_target) * ((2 * k - 1) < 0.5 ? 4 * (2 * k - 1) * (2 * k - 1) * (2 * k - 1) : 1 - Math.pow(-2 * (2 * k - 1) + 2, 3) / 2)), 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_16_arc_004_timer); normal_w_16_arc_004_timer = null; normal_w_16_arc_004_phase = 2;
                normal_w_16_arc_004_draw(normal_w_16_arc_004_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_16_arc_004_replay() {
            if (normal_w_16_arc_004_phase !== 2) return;
            normal_w_16_arc_004_phase = 1;
            normal_w_16_arc_004_run();
          }
          const normal_w_17_arc_005_track = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 146, y: 130, w: 188, h: 188, start_angle: -90, end_angle: 270, color: 0x436865, line_width: 3, corner_flag: 1 });
          const normal_w_17_arc_005 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 146, y: 130, w: 188, h: 188, start_angle: -90, end_angle: -90, color: 0x7fd695, line_width: 3, corner_flag: 1 });
          // Дуга normal_w_17_arc_005: значение из источника SECOND, углы на часах -90°…270° (0° = 3 часа)
          let normal_w_17_arc_005_target = 0, normal_w_17_arc_005_phase = 0, normal_w_17_arc_005_timer = null, normal_w_17_arc_005_err = false;
          function normal_w_17_arc_005_draw(r, f, g) {
            try {
              normal_w_17_arc_005.setProperty(prop.MORE, { x: 146, y: 130, w: 188, h: 188, start_angle: -90, end_angle: Math.round(-90 + (360) * r), color: 0x7fd695, line_width: 3 });
            } catch (e) { if (!normal_w_17_arc_005_err) { normal_w_17_arc_005_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_17_arc_005_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_17_arc_005_target = v;
            if (normal_w_17_arc_005_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_17_arc_005_phase === 0) { normal_w_17_arc_005_phase = 1; normal_w_17_arc_005_run(); return; }
            normal_w_17_arc_005_draw(v, 1, 1);
          }
          function normal_w_17_arc_005_run() {
            let n = 0;
            normal_w_17_arc_005_draw(0, 0, 0);
            normal_w_17_arc_005_timer = setInterval(() => {
              n++;
              if (n <= 5) return;
              const k = Math.min(1, (n - 5) / 30);
              const e = ((k) < 0.5 ? 4 * (k) * (k) * (k) : 1 - Math.pow(-2 * (k) + 2, 3) / 2);
              normal_w_17_arc_005_draw(e * normal_w_17_arc_005_target, 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_17_arc_005_timer); normal_w_17_arc_005_timer = null; normal_w_17_arc_005_phase = 2;
                normal_w_17_arc_005_draw(normal_w_17_arc_005_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_17_arc_005_replay() {
            if (normal_w_17_arc_005_phase !== 2) return;
            normal_w_17_arc_005_phase = 1;
            normal_w_17_arc_005_run();
          }
      
          // Повтор анимации дуг при возврате на циферблат / пробуждении экрана
          try {
            createWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { console.log('watchface resume'); } catch (e) {}
                try { normal_w_13_arc_001_replay(); } catch (e) {}
                try { normal_w_14_arc_002_replay(); } catch (e) {}
                try { normal_w_15_arc_003_replay(); } catch (e) {}
                try { normal_w_16_arc_004_replay(); } catch (e) {}
                try { normal_w_17_arc_005_replay(); } catch (e) {}
              },
              pause_call: function () {},
            });
          } catch (e) {}
      
          // Повтор анимации дуг при поднятии руки (Screen.onChange + страховка по паузе таймера)
          try {
            const _scr = new Screen();
            let _scrPrev = 1;
            try { _scrPrev = _scr.getStatus(); } catch (e) {}
            const _raise = function (why) {
              try { console.log('arc replay: ' + why); } catch (e) {}
              try { normal_w_13_arc_001_replay(); } catch (e) {}
              try { normal_w_14_arc_002_replay(); } catch (e) {}
              try { normal_w_15_arc_003_replay(); } catch (e) {}
              try { normal_w_16_arc_004_replay(); } catch (e) {}
              try { normal_w_17_arc_005_replay(); } catch (e) {}
            };
            self._screen = _scr;
            self._screenCb = function (st) {
              try {
                const cur = (typeof st === 'number') ? st : _scr.getStatus();
                try { console.log('screen status: ' + cur); } catch (e) {}
                const was = _scrPrev; _scrPrev = cur;
                if (cur === 1 && was !== 1) _raise('screen on');
              } catch (e) {}
            };
            _scr.onChange(self._screenCb);
            let _hbLast = Date.now();
            self._raiseTimer = setInterval(function () {
              try {
                const t = Date.now();
                if (t - _hbLast > 3000) _raise('timer gap ' + (t - _hbLast) + ' ms');
                _hbLast = t;
              } catch (e) {}
            }, 1000);
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _heart = new HeartRate(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_0_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            normal_w_1_text_001.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            normal_w_2_text_002.setProperty(prop.MORE, { text: formatMonth(now, "MMM", "RU") });
            normal_w_3_text_003.setProperty(prop.MORE, { text: formatUnit(now.getSeconds(), true) });
            normal_w_12_text_005.setProperty(prop.MORE, { src: normal_w_12_text_005_wd[now.getDay()] });
            normal_w_17_arc_005_set(now.getSeconds() / 60);
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_4_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_4_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_5_steps_001.setProperty(prop.MORE, { text: "" + txt + " " });
            } catch (e) { normal_w_5_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heart ? _heart.getCurrent() : null;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_6_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_6_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_8_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_8_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_13_arc_001_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { normal_w_13_arc_001_set(0); }
            try {
              const v = _heart ? _heart.getCurrent() : null;
              normal_w_14_arc_002_set(typeof v === 'number' ? (v - 0) / 200 : 0);
            } catch (e) { normal_w_14_arc_002_set(0); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              normal_w_15_arc_003_set(typeof v === 'number' ? (v - 0) / 500 : 0);
            } catch (e) { normal_w_15_arc_003_set(0); }
            try {
              const v = _step ? _step.getCurrent() : null;
              normal_w_16_arc_004_set(typeof v === 'number' ? (v - 0) / 10000 : 0);
            } catch (e) { normal_w_16_arc_004_set(0); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 90, y: 151, w: 300, h: 100, text_size: 48, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const aod_w_1_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 140, y: 372, w: 200, h: 50, text_size: 33, color: 0x76efda, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const aod_w_2_text_002 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 140, y: 398, w: 200, h: 50, text_size: 30, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const aod_w_3_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 343, y: 142, w: 100, h: 36, text_size: 28, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const aod_w_4_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 54, y: 342, w: 100, h: 30, text_size: 28, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const aod_w_5_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 17, y: 246, w: 100, h: 36, text_size: 28, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_AOD,
          x: 325, y: 345, w: 100, h: 32, text_size: 32, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.PAI_DAILY, unit_type: 0 });
          const aod_w_7_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 371, y: 244, w: 90, h: 40, text_size: 28, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_AOD,
          x: 38, y: 146, w: 100, h: 40, text_size: 33, color: 0x7bfae4, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_AOD,
          x: 180, y: 238, w: 120, h: 32, text_size: 26, color: 0x32736d, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.ALARM_CLOCK, unit_type: 1 });
          createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 140, y: 247, w: 200, h: 50, text_size: 10, color: 0x37736f, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "следующий будильник" });
          const aod_w_11_text_005_wd = ["premium_text_005_d0.png","premium_text_005_d1.png","premium_text_005_d2.png","premium_text_005_d3.png","premium_text_005_d4.png","premium_text_005_d5.png","premium_text_005_d6.png"];
          const aod_w_11_text_005 = createWidget(widget.IMG, { show_level: show_level.ONLY_AOD,
          x: 139, y: 199, w: 202, h: 202, src: aod_w_11_text_005_wd[new Date().getDay()] });
          aod_w_11_text_005.setAlpha(255);
          const aod_w_12_arc_001_a = [-70, -53, -37, -20, -4, 13, 29, 46, 62, 79, 95, 112, 128, 145, 161, 178, 194, 211, 227, 244], aod_w_12_arc_001_b = [-63, -47, -30, -14, 3, 19, 36, 52, 69, 85, 102, 118, 135, 151, 168, 184, 201, 217, 234, 250], aod_w_12_arc_001_c = [0xff0000, 0xf20d03, 0xe41b07, 0xd7280a, 0xc9360d, 0xbc4311, 0xae5114, 0xa15e18, 0x946b1b, 0x86791e, 0x798622, 0x6b9425, 0x5ea128, 0x51ae2c, 0x43bc2f, 0x36c933, 0x28d736, 0x1be439, 0x0df23d, 0x00ff40];
          const aod_w_12_arc_001_trk = [];
          for (let aod_w_12_arc_001_ti = 0; aod_w_12_arc_001_ti < 20; aod_w_12_arc_001_ti++) {
            aod_w_12_arc_001_trk.push(createWidget(widget.ARC, { show_level: show_level.ONLY_AOD,
          x: 353, y: 116, w: 78, h: 78, start_angle: aod_w_12_arc_001_a[aod_w_12_arc_001_ti], end_angle: aod_w_12_arc_001_b[aod_w_12_arc_001_ti], color: 0x0f3a42, line_width: 5, corner_flag: 1 }));
          }
          const aod_w_12_arc_001_segs = [], aod_w_12_arc_001_vis = [];
          for (let aod_w_12_arc_001_i = 0; aod_w_12_arc_001_i < 20; aod_w_12_arc_001_i++) {
            aod_w_12_arc_001_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_AOD,
          x: 353, y: 116, w: 78, h: 78, start_angle: aod_w_12_arc_001_a[aod_w_12_arc_001_i], end_angle: aod_w_12_arc_001_a[aod_w_12_arc_001_i], color: aod_w_12_arc_001_c[aod_w_12_arc_001_i], line_width: 5, corner_flag: 1 }));
            aod_w_12_arc_001_segs[aod_w_12_arc_001_i].setProperty(prop.VISIBLE, false);   // пустой сегмент со скруглением нарисовал бы точку
            aod_w_12_arc_001_vis[aod_w_12_arc_001_i] = false;
          }
          // Дуга aod_w_12_arc_001: значение из источника BATTERY, углы на часах -70°…250° (0° = 3 часа)
          let aod_w_12_arc_001_target = 0, aod_w_12_arc_001_phase = 2, aod_w_12_arc_001_timer = null, aod_w_12_arc_001_err = false;
          const aod_w_12_arc_001_last = [];
          function aod_w_12_arc_001_draw(r, f, g) {
            try {
              const cur = -70 + (320) * r;
              const lw = 5;
              for (let aod_w_12_arc_001_k = 0; aod_w_12_arc_001_k < 20; aod_w_12_arc_001_k++) {
                const a = aod_w_12_arc_001_a[aod_w_12_arc_001_k], b = aod_w_12_arc_001_b[aod_w_12_arc_001_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));
                const col = aod_w_12_arc_001_c[aod_w_12_arc_001_k];
                const key = end + ':' + col + ':' + lw;
                if (aod_w_12_arc_001_last[aod_w_12_arc_001_k] === key) continue;
                aod_w_12_arc_001_last[aod_w_12_arc_001_k] = key;
                if (end === a) { if (aod_w_12_arc_001_vis[aod_w_12_arc_001_k]) { aod_w_12_arc_001_vis[aod_w_12_arc_001_k] = false; aod_w_12_arc_001_segs[aod_w_12_arc_001_k].setProperty(prop.VISIBLE, false); } continue; }
                aod_w_12_arc_001_segs[aod_w_12_arc_001_k].setProperty(prop.MORE, { x: 353, y: 116, w: 78, h: 78, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!aod_w_12_arc_001_vis[aod_w_12_arc_001_k]) { aod_w_12_arc_001_vis[aod_w_12_arc_001_k] = true; aod_w_12_arc_001_segs[aod_w_12_arc_001_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!aod_w_12_arc_001_err) { aod_w_12_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function aod_w_12_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            aod_w_12_arc_001_target = v;
            aod_w_12_arc_001_draw(v, 1, 1);
          }
          const aod_w_13_arc_002_a = [-70, -53, -37, -20, -4, 13, 29, 46, 62, 79, 95, 112, 128, 145, 161, 178, 194, 211, 227, 244], aod_w_13_arc_002_b = [-63, -47, -30, -14, 3, 19, 36, 52, 69, 85, 102, 118, 135, 151, 168, 184, 201, 217, 234, 250], aod_w_13_arc_002_c = [0x00ff40, 0x0df23d, 0x1be439, 0x28d736, 0x36c933, 0x43bc2f, 0x51ae2c, 0x5ea128, 0x6b9425, 0x798622, 0x86791e, 0x946b1b, 0xa15e18, 0xae5114, 0xbc4311, 0xc9360d, 0xd7280a, 0xe41b07, 0xf20d03, 0xff0000];
          const aod_w_13_arc_002_trk = [];
          for (let aod_w_13_arc_002_ti = 0; aod_w_13_arc_002_ti < 20; aod_w_13_arc_002_ti++) {
            aod_w_13_arc_002_trk.push(createWidget(widget.ARC, { show_level: show_level.ONLY_AOD,
          x: 28, y: 217, w: 78, h: 78, start_angle: aod_w_13_arc_002_a[aod_w_13_arc_002_ti], end_angle: aod_w_13_arc_002_b[aod_w_13_arc_002_ti], color: 0x0f3a42, line_width: 5, corner_flag: 1 }));
          }
          const aod_w_13_arc_002_segs = [], aod_w_13_arc_002_vis = [];
          for (let aod_w_13_arc_002_i = 0; aod_w_13_arc_002_i < 20; aod_w_13_arc_002_i++) {
            aod_w_13_arc_002_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_AOD,
          x: 28, y: 217, w: 78, h: 78, start_angle: aod_w_13_arc_002_a[aod_w_13_arc_002_i], end_angle: aod_w_13_arc_002_a[aod_w_13_arc_002_i], color: aod_w_13_arc_002_c[aod_w_13_arc_002_i], line_width: 5, corner_flag: 1 }));
            aod_w_13_arc_002_segs[aod_w_13_arc_002_i].setProperty(prop.VISIBLE, false);   // пустой сегмент со скруглением нарисовал бы точку
            aod_w_13_arc_002_vis[aod_w_13_arc_002_i] = false;
          }
          // Дуга aod_w_13_arc_002: значение из источника HEART, углы на часах -70°…250° (0° = 3 часа)
          let aod_w_13_arc_002_target = 0, aod_w_13_arc_002_phase = 2, aod_w_13_arc_002_timer = null, aod_w_13_arc_002_err = false;
          const aod_w_13_arc_002_last = [];
          function aod_w_13_arc_002_draw(r, f, g) {
            try {
              const cur = -70 + (320) * r;
              const lw = 5;
              for (let aod_w_13_arc_002_k = 0; aod_w_13_arc_002_k < 20; aod_w_13_arc_002_k++) {
                const a = aod_w_13_arc_002_a[aod_w_13_arc_002_k], b = aod_w_13_arc_002_b[aod_w_13_arc_002_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));
                const col = aod_w_13_arc_002_c[aod_w_13_arc_002_k];
                const key = end + ':' + col + ':' + lw;
                if (aod_w_13_arc_002_last[aod_w_13_arc_002_k] === key) continue;
                aod_w_13_arc_002_last[aod_w_13_arc_002_k] = key;
                if (end === a) { if (aod_w_13_arc_002_vis[aod_w_13_arc_002_k]) { aod_w_13_arc_002_vis[aod_w_13_arc_002_k] = false; aod_w_13_arc_002_segs[aod_w_13_arc_002_k].setProperty(prop.VISIBLE, false); } continue; }
                aod_w_13_arc_002_segs[aod_w_13_arc_002_k].setProperty(prop.MORE, { x: 28, y: 217, w: 78, h: 78, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!aod_w_13_arc_002_vis[aod_w_13_arc_002_k]) { aod_w_13_arc_002_vis[aod_w_13_arc_002_k] = true; aod_w_13_arc_002_segs[aod_w_13_arc_002_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!aod_w_13_arc_002_err) { aod_w_13_arc_002_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function aod_w_13_arc_002_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            aod_w_13_arc_002_target = v;
            aod_w_13_arc_002_draw(v, 1, 1);
          }
          const aod_w_14_arc_003_a = [-70, -56, -43, -29, -15, -2, 12, 26, 39, 53, 67, 80, 94, 108, 121, 135, 149, 162, 176, 190, 203, 217, 231, 244], aod_w_14_arc_003_b = [-64, -51, -37, -23, -10, 4, 18, 31, 45, 59, 72, 86, 100, 113, 127, 141, 154, 168, 182, 195, 209, 223, 236, 250], aod_w_14_arc_003_c = [0xff0000, 0xf40b03, 0xe91606, 0xde2108, 0xd32c0b, 0xc8370e, 0xbc4311, 0xb14e13, 0xa65916, 0x9b6419, 0x906f1c, 0x857a1f, 0x7a8521, 0x6f9024, 0x649b27, 0x59a62a, 0x4eb12d, 0x43bc2f, 0x37c832, 0x2cd335, 0x21de38, 0x16e93a, 0x0bf43d, 0x00ff40];
          const aod_w_14_arc_003_trk = [];
          for (let aod_w_14_arc_003_ti = 0; aod_w_14_arc_003_ti < 24; aod_w_14_arc_003_ti++) {
            aod_w_14_arc_003_trk.push(createWidget(widget.ARC, { show_level: show_level.ONLY_AOD,
          x: 376, y: 218, w: 78, h: 78, start_angle: aod_w_14_arc_003_a[aod_w_14_arc_003_ti], end_angle: aod_w_14_arc_003_b[aod_w_14_arc_003_ti], color: 0x0f3a42, line_width: 5, corner_flag: 1 }));
          }
          const aod_w_14_arc_003_segs = [], aod_w_14_arc_003_vis = [];
          for (let aod_w_14_arc_003_i = 0; aod_w_14_arc_003_i < 24; aod_w_14_arc_003_i++) {
            aod_w_14_arc_003_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_AOD,
          x: 376, y: 218, w: 78, h: 78, start_angle: aod_w_14_arc_003_a[aod_w_14_arc_003_i], end_angle: aod_w_14_arc_003_a[aod_w_14_arc_003_i], color: aod_w_14_arc_003_c[aod_w_14_arc_003_i], line_width: 5, corner_flag: 1 }));
            aod_w_14_arc_003_segs[aod_w_14_arc_003_i].setProperty(prop.VISIBLE, false);   // пустой сегмент со скруглением нарисовал бы точку
            aod_w_14_arc_003_vis[aod_w_14_arc_003_i] = false;
          }
          // Дуга aod_w_14_arc_003: значение из источника CALORIE, углы на часах -70°…250° (0° = 3 часа)
          let aod_w_14_arc_003_target = 0, aod_w_14_arc_003_phase = 2, aod_w_14_arc_003_timer = null, aod_w_14_arc_003_err = false;
          const aod_w_14_arc_003_last = [];
          function aod_w_14_arc_003_draw(r, f, g) {
            try {
              const cur = -70 + (320) * r;
              const lw = 5;
              for (let aod_w_14_arc_003_k = 0; aod_w_14_arc_003_k < 24; aod_w_14_arc_003_k++) {
                const a = aod_w_14_arc_003_a[aod_w_14_arc_003_k], b = aod_w_14_arc_003_b[aod_w_14_arc_003_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));
                const col = aod_w_14_arc_003_c[aod_w_14_arc_003_k];
                const key = end + ':' + col + ':' + lw;
                if (aod_w_14_arc_003_last[aod_w_14_arc_003_k] === key) continue;
                aod_w_14_arc_003_last[aod_w_14_arc_003_k] = key;
                if (end === a) { if (aod_w_14_arc_003_vis[aod_w_14_arc_003_k]) { aod_w_14_arc_003_vis[aod_w_14_arc_003_k] = false; aod_w_14_arc_003_segs[aod_w_14_arc_003_k].setProperty(prop.VISIBLE, false); } continue; }
                aod_w_14_arc_003_segs[aod_w_14_arc_003_k].setProperty(prop.MORE, { x: 376, y: 218, w: 78, h: 78, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!aod_w_14_arc_003_vis[aod_w_14_arc_003_k]) { aod_w_14_arc_003_vis[aod_w_14_arc_003_k] = true; aod_w_14_arc_003_segs[aod_w_14_arc_003_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!aod_w_14_arc_003_err) { aod_w_14_arc_003_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function aod_w_14_arc_003_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            aod_w_14_arc_003_target = v;
            aod_w_14_arc_003_draw(v, 1, 1);
          }
          const aod_w_15_arc_004_a = [-70, -56, -43, -29, -15, -2, 12, 25, 39, 53, 66, 80, 94, 107, 121, 134, 148, 162, 175, 189, 203, 216, 230, 243], aod_w_15_arc_004_b = [-63, -50, -36, -22, -9, 5, 18, 32, 46, 59, 73, 87, 100, 114, 127, 141, 155, 168, 182, 196, 209, 223, 236, 250], aod_w_15_arc_004_c = [0xf70202, 0xec0c02, 0xe21702, 0xd72102, 0xcd2b02, 0xc23602, 0xb84001, 0xad4a01, 0xa25501, 0x985f01, 0x8d6901, 0x837401, 0x787e01, 0x6e8901, 0x639301, 0x599d01, 0x4ea801, 0x43b201, 0x39bc00, 0x2ec700, 0x24d100, 0x19db00, 0x0fe600, 0x04f000];
          const aod_w_15_arc_004_trk = [];
          for (let aod_w_15_arc_004_ti = 0; aod_w_15_arc_004_ti < 24; aod_w_15_arc_004_ti++) {
            aod_w_15_arc_004_trk.push(createWidget(widget.ARC, { show_level: show_level.ONLY_AOD,
          x: 60, y: 309, w: 90, h: 90, start_angle: aod_w_15_arc_004_a[aod_w_15_arc_004_ti], end_angle: aod_w_15_arc_004_b[aod_w_15_arc_004_ti], color: 0x0f3a42, line_width: 5, corner_flag: 1 }));
          }
          const aod_w_15_arc_004_segs = [], aod_w_15_arc_004_vis = [];
          for (let aod_w_15_arc_004_i = 0; aod_w_15_arc_004_i < 24; aod_w_15_arc_004_i++) {
            aod_w_15_arc_004_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_AOD,
          x: 60, y: 309, w: 90, h: 90, start_angle: aod_w_15_arc_004_a[aod_w_15_arc_004_i], end_angle: aod_w_15_arc_004_a[aod_w_15_arc_004_i], color: aod_w_15_arc_004_c[aod_w_15_arc_004_i], line_width: 5, corner_flag: 1 }));
            aod_w_15_arc_004_segs[aod_w_15_arc_004_i].setProperty(prop.VISIBLE, false);   // пустой сегмент со скруглением нарисовал бы точку
            aod_w_15_arc_004_vis[aod_w_15_arc_004_i] = false;
          }
          // Дуга aod_w_15_arc_004: значение из источника STEP, углы на часах -70°…250° (0° = 3 часа)
          let aod_w_15_arc_004_target = 0, aod_w_15_arc_004_phase = 2, aod_w_15_arc_004_timer = null, aod_w_15_arc_004_err = false;
          const aod_w_15_arc_004_last = [];
          function aod_w_15_arc_004_draw(r, f, g) {
            try {
              const cur = -70 + (320) * r;
              const lw = 5;
              for (let aod_w_15_arc_004_k = 0; aod_w_15_arc_004_k < 24; aod_w_15_arc_004_k++) {
                const a = aod_w_15_arc_004_a[aod_w_15_arc_004_k], b = aod_w_15_arc_004_b[aod_w_15_arc_004_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));
                const col = aod_w_15_arc_004_c[aod_w_15_arc_004_k];
                const key = end + ':' + col + ':' + lw;
                if (aod_w_15_arc_004_last[aod_w_15_arc_004_k] === key) continue;
                aod_w_15_arc_004_last[aod_w_15_arc_004_k] = key;
                if (end === a) { if (aod_w_15_arc_004_vis[aod_w_15_arc_004_k]) { aod_w_15_arc_004_vis[aod_w_15_arc_004_k] = false; aod_w_15_arc_004_segs[aod_w_15_arc_004_k].setProperty(prop.VISIBLE, false); } continue; }
                aod_w_15_arc_004_segs[aod_w_15_arc_004_k].setProperty(prop.MORE, { x: 60, y: 309, w: 90, h: 90, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!aod_w_15_arc_004_vis[aod_w_15_arc_004_k]) { aod_w_15_arc_004_vis[aod_w_15_arc_004_k] = true; aod_w_15_arc_004_segs[aod_w_15_arc_004_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!aod_w_15_arc_004_err) { aod_w_15_arc_004_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function aod_w_15_arc_004_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            aod_w_15_arc_004_target = v;
            aod_w_15_arc_004_draw(v, 1, 1);
          }
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _heart = new HeartRate(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            aod_w_1_text_001.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            aod_w_2_text_002.setProperty(prop.MORE, { text: formatMonth(now, "MMM", "RU") });
            aod_w_11_text_005.setProperty(prop.MORE, { src: aod_w_11_text_005_wd[now.getDay()] });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
          function _tickSensorsAod() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              aod_w_3_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { aod_w_3_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              aod_w_4_steps_001.setProperty(prop.MORE, { text: "" + txt + " " });
            } catch (e) { aod_w_4_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heart ? _heart.getCurrent() : null;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              aod_w_5_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { aod_w_5_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              aod_w_7_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { aod_w_7_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              aod_w_12_arc_001_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { aod_w_12_arc_001_set(0); }
            try {
              const v = _heart ? _heart.getCurrent() : null;
              aod_w_13_arc_002_set(typeof v === 'number' ? (v - 0) / 200 : 0);
            } catch (e) { aod_w_13_arc_002_set(0); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              aod_w_14_arc_003_set(typeof v === 'number' ? (v - 0) / 500 : 0);
            } catch (e) { aod_w_14_arc_003_set(0); }
            try {
              const v = _step ? _step.getCurrent() : null;
              aod_w_15_arc_004_set(typeof v === 'number' ? (v - 0) / 10000 : 0);
            } catch (e) { aod_w_15_arc_004_set(0); }
          }
          _tickSensorsAod();
          self._sensorTimerAod = setInterval(_tickSensorsAod, 5000);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
