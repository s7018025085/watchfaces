import { createWidget, widget, align, text_style, prop, show_level, data_type, anim_status } from '@zos/ui'
import { Time } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// ---- Анимация текста (AmazFace): общий рантайм --------------------------------
var __TA = { list: [], all: [], timer: 0, paused: false };
var __taFx = {};
function __taClamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function __taEase(name, t) {
  t = __taClamp(t, 0, 1);
  if (name === 'in') return t * t * t;
  if (name === 'out') { var u = 1 - t; return 1 - u * u * u; }
  if (name === 'inout') return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  return t;
}
function __taMix(c1, c2, t) {
  var r = Math.round(((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
  var g = Math.round(((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
  var b = Math.round((c1 & 255) * (1 - t) + (c2 & 255) * t);
  return (r << 16) | (g << 8) | b;
}
function __taChars(s) {
  var out = [], i = 0, n, c;
  s = String(s == null ? '' : s);
  n = s.length;
  while (i < n) {
    c = s.charCodeAt(i);
    if (c >= 0xD800 && c <= 0xDBFF && i + 1 < n) { out.push(s.substr(i, 2)); i += 2; }
    else { out.push(s.charAt(i)); i += 1; }
  }
  return out;
}
function __taParseNum(s) {
  var m = /-?\d[\d,]*(?:\.\d+)?/.exec(String(s == null ? '' : s));
  if (!m) return null;
  var tok = m[0], clean = tok.replace(/,/g, ''), dot = clean.indexOf('.');
  return { pre: String(s).slice(0, m.index), post: String(s).slice(m.index + tok.length), val: parseFloat(clean), dec: dot >= 0 ? clean.length - dot - 1 : 0, sep: tok.indexOf(',') >= 0 };
}
function __taFmtNum(n, dec, sep) {
  var s = Math.abs(n).toFixed(dec), parts;
  if (sep) { parts = s.split('.'); parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ','); s = parts.join('.'); }
  return (n < 0 && parseFloat(s.replace(/,/g, '')) !== 0 ? '-' : '') + s;
}
function __taGroups(s) {
  var out = [], re = /\d+/g, m;
  s = String(s == null ? '' : s);
  while ((m = re.exec(s)) !== null) out.push({ i: m.index, s: m[0] });
  return out;
}
function __taPhase(a, el) {
  var c = a.cfg, d = c.delay || 0, dur = Math.max(1, a.durOv || c.dur), n = c.rep || 0, gap = c.pause || 0, t, cyc, rep, q, k;
  if (a.perp) return { k: 0, e: 0, ms: Math.max(0, el), rep: 0, done: false, hold: false };
  if (el < d) return { k: 0, e: __taEase(c.ease, 0), ms: 0, rep: 0, done: false, hold: true };
  t = el - d; cyc = dur + gap;
  if (t >= n * cyc + dur) return { k: 1, e: 1, ms: dur, rep: n, done: true, hold: false };
  rep = Math.floor(t / cyc); q = t - rep * cyc; k = q >= dur ? 1 : q / dur;
  return { k: k, e: __taEase(c.ease, k), ms: q >= dur ? dur : q, rep: rep, done: false, hold: false };
}
function __taFinal(a) {
  var s = { text: a.text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: true }, fx = __taFx[a.cfg.fx];
  if (fx.final) fx.final(a, s);
  return s;
}
function __taSample(a, el) {
  var ph = __taPhase(a, el), s = __taFinal(a), fx = __taFx[a.cfg.fx], o, key;
  if (ph.done) return { s: s, done: true, ph: ph };
  o = fx.frame(a, ph.k, ph);
  for (key in o) { if (Object.prototype.hasOwnProperty.call(o, key)) s[key] = o[key]; }
  return { s: s, done: false, ph: ph };
}
function __taApply(a, s) {
  var o = {}, any = false, L = a.last, cut, tx = s.text, rest;
  if (a.cellLayout) {
    __taApplyCells(a, s);
    a.last = { text: tx, text2: null, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis };
    return;
  }
  if (a.w2) {
    cut = tx.indexOf(a.cfg.sep);
    rest = cut >= 0 ? tx.slice(cut + a.cfg.sep.length) : '';
    if (cut >= 0) tx = tx.slice(0, cut);
    if (rest !== L.text2) { try { a.w2.setProperty(prop.MORE, { text: rest }); } catch (e1) {} L.text2 = rest; }
  }
  if (tx !== L.text) { o.text = tx; any = true; }
  if (s.color !== L.color) { o.color = s.color; any = true; }
  if (s.x !== L.x) { o.x = s.x; any = true; }
  if (s.y !== L.y) { o.y = s.y; any = true; }
  if (s.size !== L.size) { o.text_size = s.size; any = true; }
  if (a.c && s.vis !== L.vis) { try { a.c.setProperty(prop.VISIBLE, s.vis); } catch (e2) {} }
  a.last = { text: tx, text2: L.text2, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis };
  if (any && a.w) { try { a.w.setProperty(prop.MORE, o); } catch (e3) {} }
}
function __taShow(a) { __taApply(a, __taFinal(a)); }
// Условия повторного запуска эффектов при изменении исходного текста.
// Для «Проявления» и «Пульсации размера» посимвольный режим дополнительно
// ограничивает сами стили изменившимися разрядами; остальные эффекты фильтруют запуск целиком.
function __taChangeAllowed(a, oldText, newText) {
  var mode = a.cfg.track || 'all', oldD, newD, i, off;
  if (mode === 'all') return true;
  if (mode === 'off') return false;
  oldD = String(oldText == null ? '' : oldText).replace(/[^0-9]/g, '');
  newD = String(newText == null ? '' : newText).replace(/[^0-9]/g, '');
  if (mode === 'changed') return oldD !== newD;
  if (mode === 'seconds' && !a.cfg.trackSec) return false;
  if (mode === 'units') off = 1;
  else if (mode === 'tens') off = 2;
  else if (mode === 'seconds') {
    for (i = 1; i <= 2; i++) {
      if (oldD.charAt(oldD.length - i) !== newD.charAt(newD.length - i)) return true;
    }
    return false;
  } else return true;
  if (oldD.length < off || newD.length < off) return false;
  return oldD.charAt(oldD.length - off) !== newD.charAt(newD.length - off);
}
// Определяет только цифры, которым разрешено анимироваться в посимвольных режимах.
function __taCharTargets(a, why) {
  var cur = __taChars(a.text), old = __taChars(a.prevText || ''), mode = a.cfg.track || 'all';
  var digits = [], target = {}, i, idx, off;
  for (i = 0; i < cur.length; i++) if (cur[i] >= '0' && cur[i] <= '9') digits.push(i);
  if (why === 'open') {
    if (mode === 'seconds' && a.cfg.trackSec) {
      off = Math.max(0, digits.length - 2);
      for (i = off; i < digits.length; i++) target[digits[i]] = true;
    } else if (mode === 'tens' || mode === 'units') {
      off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
      if (off >= 0) target[digits[off]] = true;
    } else if (mode === 'changed') {
      for (i = 0; i < digits.length; i++) target[digits[i]] = true;
    }
    return target;
  }
  if (why !== 'update' && why !== 'wake') return target;
  if (mode === 'seconds') {
    if (!a.cfg.trackSec) return target;
    off = Math.max(0, digits.length - 2);
    for (i = off; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else if (mode === 'tens' || mode === 'units') {
    off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
    if (off >= 0) { idx = digits[off]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else {
    for (i = 0; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  }
  return target;
}
function __taApplyCells(a, s) {
  var l = a.cellLayout, ws = l.widgets, chars = __taChars(s.text), n = ws.length;
  var count = Math.min(chars.length, n), gap = Number(l.gap || 0), total = 0, start, x, cellX, i, ch, col, size, o, prev, w, cw, scale, renderW, widths = [];
  // La anchura de composición siempre usa la métrica base para que una pulsación
  // no empuje las cifras vecinas. Solo se ensancha la celda animada, simétricamente.
  for (i = 0; i < count; i++) {
    ch = chars[i]; cw = Math.max(1, Number((l.charWidths && l.charWidths[ch]) || l.defaultWidth || 1));
    widths[i] = cw; total += cw;
  }
  if (count > 1) total += gap * (count - 1);
  if (l.align === 'LEFT') start = Number(l.x || 0);
  else if (l.align === 'RIGHT') start = Number(l.x || 0) + Number(l.w || 0) - total;
  else start = Number(l.x || 0) + Number(l.w || 0) / 2 - total / 2;
  x = start;
  if (!a.cellLast) a.cellLast = [];
  for (i = 0; i < n; i++) {
    ch = i < count ? chars[i] : '';
    cw = i < count ? widths[i] : Math.max(1, Number(l.defaultWidth || 1));
    col = s.charColors && s.charColors[i] != null ? s.charColors[i] : s.color;
    size = s.charSizes && s.charSizes[i] != null ? s.charSizes[i] : s.size;
    scale = a.base.size > 0 ? Math.max(1, Number(size || a.base.size) / a.base.size) : 1;
    renderW = Math.max(cw, Math.ceil(cw * scale));
    cellX = x - (renderW - cw) / 2;
    prev = a.cellLast[i] || { text: null, color: null, size: null, x: null, w: null };
    o = {};
    if (ch !== prev.text) o.text = ch;
    if (col !== prev.color) o.color = col;
    if (size !== prev.size) o.text_size = size;
    if (Math.round(cellX) !== prev.x) o.x = Math.round(cellX);
    if (renderW !== prev.w) o.w = renderW;
    w = ws[i];
    if (Object.keys(o).length && w) { try { w.setProperty(prop.MORE, o); } catch (e) {} }
    a.cellLast[i] = { text: ch, color: col, size: size, x: Math.round(cellX), w: renderW };
    x += cw + gap;
  }
}

function __taEnsure() {
  var ms = 1000, i;
  if (__TA.timer || !__TA.list.length) return;
  for (i = 0; i < __TA.list.length; i++) { if (__TA.list[i].step < ms) ms = __TA.list[i].step; }
  __TA.timer = setInterval(__taStep, Math.max(30, ms));
}
function __taDrop(a) {
  var i = __TA.list.indexOf(a);
  if (i >= 0) __TA.list.splice(i, 1);
  if (!__TA.list.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taStep() {
  var now = Date.now(), keep = [], i, a, r, fx;
  for (i = 0; i < __TA.list.length; i++) {
    a = __TA.list[i];
    r = __taSample(a, now - a.t0);
    fx = __taFx[a.cfg.fx];
    if (r.done) { a.on = false; if (fx.done) fx.done(a); __taShow(a); }
    else { __taApply(a, r.s); keep.push(a); }
  }
  __TA.list = keep;
  if (!keep.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taBegin(a, why) {
  var fx = __taFx[a.cfg.fx];
  a.durOv = 0;
  if (fx.init) fx.init(a, why);
  a.t0 = Date.now(); a.on = true; a.why = why;
}
function __taPlay(a, why) {
  var r;
  if (__TA.paused) return;
  if (a.on && a.cfg.retrig === 'ignore') return;
  __taBegin(a, why);
  r = __taSample(a, 0);
  __taApply(a, r.s);
  if (__TA.list.indexOf(a) < 0) __TA.list.push(a);
  __taEnsure();
}
function __taStop(a) { a.on = false; __taDrop(a); __taShow(a); }
function __taSetText(a, text) {
  var c = a.cfg, fx = __taFx[c.fx], old = a.text, changed;
  text = text == null ? '' : String(text);
  changed = text !== old;
  a.prevText = old;
  a.text = text;
  if (fx.live) { fx.live(a, old, text, changed); return; }
  if (!a.opened) {
    if (fx.can && !fx.can(a)) { __taShow(a); return; }
    a.opened = true;
    if (c.open) __taPlay(a, 'open'); else __taShow(a);
    return;
  }
  if (!changed) { if (!a.on) __taShow(a); return; }
  // Применяется одинаково ко всем эффектам с обработчиком изменения (в том числе
  // count/flash/flip, у которых специальная обработка обновления значения).
  // При проигнорированном изменении сразу показываем новое значение без старого кадра.
  if (!__taChangeAllowed(a, old, text)) { if (a.on) __taStop(a); else __taShow(a); return; }
  if (fx.onChange) { fx.onChange(a, old, text); return; }
  if (c.change && (!fx.can || fx.can(a))) { __taPlay(a, 'update'); return; }
  if (!a.on) __taShow(a);
}
function __taCreate(w, cfg, base, w2, cw, cellLayout) {
  var fx = __taFx[cfg.fx];
  var a = { w: w, w2: w2 || null, c: cw || null, cellLayout: cellLayout || null, cellLast: [], charMode: !!cfg.charMode || !!cellLayout, charTargets: null, cfg: cfg, base: base, text: '', prevText: '', t0: 0, on: false, opened: false, why: '', durOv: 0, perp: !!(fx.perp && cfg.iv < 1000), blink: 0, cnt: null, curV: null, fl: null, step: 50, last: { text: null, text2: null, color: base.fin, x: base.x, y: base.y, size: base.size, vis: true } };
  a.step = fx.step ? fx.step(cfg) : 50;
  __TA.all.push(a);
  return a;
}
function __taPause() {
  var i, a;
  __TA.paused = true;
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = [];
  for (i = 0; i < __TA.all.length; i++) { a = __TA.all[i]; a.on = false; __taShow(a); }
}
function __taResume() {
  var now = Date.now(), i, a, fx;
  __TA.paused = false;
  for (i = 0; i < __TA.all.length; i++) {
    a = __TA.all[i]; fx = __taFx[a.cfg.fx];
    if (!a.opened) continue;
    if (fx.resume) { fx.resume(a); continue; }
    if (a.cfg.wake && now - a.t0 > 800) __taPlay(a, 'wake');
  }
}
function __taDestroy() {
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = []; __TA.all = []; __TA.paused = false;
}

__taFx.reveal = {
  step: function () { return 50; },
  init: function (a, why) { if (a.charMode) a.charTargets = __taCharTargets(a, why); },
  frame: function (a, k, ph) {
    var colors, ch, i;
    if (a.charMode) {
      colors = []; ch = __taChars(a.text);
      for (i = 0; i < ch.length; i++) colors[i] = a.charTargets && a.charTargets[i] ? __taMix(a.cfg.c1, a.base.fin, ph.e) : null;
      return { charColors: colors };
    }
    return { color: __taMix(a.cfg.c1, a.base.fin, ph.e) };
  }
};


// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;

// Dual scene runtime: Normal and AOD are both exported into this one watchface.
// Zepp OS controls visibility through the documented widget show_level property.
WatchFace({
  build() {
    const self = this;

    // Normal scene widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "pikselnyy_hud_battletoads_s_chasami_i_datchikami_2.png" });
          __bgImage_normal_.setAlpha(255);
          const __bgAnim_normal_ = createWidget(widget.IMG_ANIM, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, anim_path: "bganim", anim_prefix: "f", anim_ext: "png", anim_fps: 15, anim_size: 36, repeat_count: 0, anim_status: anim_status.START, display_on_restart: false });
          const normal_w_0_fill_rect_001 = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 120, y: 40, w: 240, h: 70, radius: 6, color: 0x000126 });
          normal_w_0_fill_rect_001.setAlpha(255);
          const normal_w_1_text_001_ch0 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 42, w: 28, h: 70, text_size: 50, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_001_ch1 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 42, w: 28, h: 70, text_size: 50, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_001_ch2 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 42, w: 28, h: 70, text_size: 50, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_001_ch3 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 42, w: 28, h: 70, text_size: 50, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_001_ch4 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 42, w: 28, h: 70, text_size: 50, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_001_ch5 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 42, w: 28, h: 70, text_size: 50, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_001_ch6 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 42, w: 28, h: 70, text_size: 50, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_001_ch7 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 42, w: 28, h: 70, text_size: 50, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_001_a = __taCreate(null, { fx: "reveal", dur: 800, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "restart", open: false, wake: false, change: true, track: "changed", trackSec: true, charMode: true, c1: 0x000000 }, { x: 130, y: 42, color: 0xffffff, fin: 0xffffff, size: 50 }, null, null, { widgets: [normal_w_1_text_001_ch0, normal_w_1_text_001_ch1, normal_w_1_text_001_ch2, normal_w_1_text_001_ch3, normal_w_1_text_001_ch4, normal_w_1_text_001_ch5, normal_w_1_text_001_ch6, normal_w_1_text_001_ch7], charWidths: {"0":28,"1":28,"2":28,"3":28,"4":28,"5":28,"6":28,"7":28,"8":28,"9":28,"-":17,"+":29,",":14,".":14,"%":44," ":14,":":14,"/":14}, defaultWidth: 28, x: 130, w: 220, align: "CENTER_H", gap: 0 });
          const normal_w_1_text_001 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_1_text_001_a, o.text); } else { for (let i = 0; i < 8; i++) { [normal_w_1_text_001_ch0, normal_w_1_text_001_ch1, normal_w_1_text_001_ch2, normal_w_1_text_001_ch3, normal_w_1_text_001_ch4, normal_w_1_text_001_ch5, normal_w_1_text_001_ch6, normal_w_1_text_001_ch7][i].setProperty(k, o); } } } };
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            createWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
                try { __bgAnim_normal_.setProperty(prop.ANIM_STATUS, anim_status.START); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} try { __bgAnim_normal_.setProperty(prop.ANIM_STATUS, anim_status.STOP); } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_1_text_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", true) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __taDestroy(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
