import { Vibrator, VIBRATOR_SCENE_SHORT_LIGHT, VIBRATOR_SCENE_SHORT_MIDDLE, VIBRATOR_SCENE_SHORT_STRONG } from '@zos/sensor'
import { set } from '@zos/alarm'

function parse(param) {
  const out = {};
  String(param || '').split('&').forEach(function (pair) {
    const i = pair.indexOf('=');
    if (i > 0) out[pair.slice(0, i)] = Number(pair.slice(i + 1));
  });
  return out;
}

function quiet(enabled, start, end, hour) {
  if (!enabled || start === end) return false;
  if (start < end) return hour >= start && hour < end;
  return hour >= start || hour < end;
}

function run(param) {
  const p = parse(param);
  // Час, к которому относится сигнал (будильник мог сработать чуть раньше/позже).
  const target = new Date(Date.now() + 90 * 1000);
  target.setMinutes(0, 0, 0);
  const hour = target.getHours();
  const strength = p.s === 0 || p.s === 2 ? p.s : 1;
  const silent = quiet(p.nq === 1, p.ns, p.ne, hour) || quiet(p.pq === 1, p.ps, p.pe, hour);
  // Следующий будильник взводим всегда, даже если этот час «тихий».
  try {
    const next = new Date(target.getTime());
    next.setHours(next.getHours() + 1);
    set({ url: 'app-service/hourly', time: Math.floor(next.getTime() / 1000), param: param, store: true });
  } catch (e) {}
  if (silent) return;
  try {
    const vibrator = new Vibrator();
    vibrator.stop();
    vibrator.setMode([VIBRATOR_SCENE_SHORT_LIGHT, VIBRATOR_SCENE_SHORT_MIDDLE, VIBRATOR_SCENE_SHORT_STRONG][strength]);
    vibrator.start();
  } catch (e) {}
}

AppService({
  onInit(param) {
    try { run(param); } catch (e) {}
  },
  onDestroy() {},
})
