import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { launchApp, SYSTEM_APP_CALENDAR, SYSTEM_APP_HR, SYSTEM_APP_STATUS, SYSTEM_APP_WEATHER } from '@zos/router'
import { Time, Battery, Step, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _heart = null;

// Dual scene runtime: Normal and AOD are both exported into this one watchface.
// Zepp OS controls visibility through the documented widget show_level property.
WatchFace({
  build() {
    const self = this;

    // Normal scene widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "gemini_generated_image_xld1afxld1afxld1.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 157, y: 71, w: 220, h: 100, text_size: 66, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_002 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 170, y: 146, w: 200, h: 50, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_2_text_003 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 92, y: 333, w: 80, h: 50, text_size: 24, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_3_text_004 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 164, y: 334, w: 80, h: 50, text_size: 24, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_4_text_005 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 238, y: 334, w: 80, h: 50, text_size: 24, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 321, w: 80, h: 50, text_size: 24, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_tap_0_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 170, y: 146, w: 200, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          normal_tap_0_tap_001.setAlpha(0);
          const normal_tap_1_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 92, y: 333, w: 80, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_HR, native: true }); } catch (e) {} } });
          normal_tap_1_tap_001.setAlpha(0);
          const normal_tap_2_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 164, y: 334, w: 80, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STATUS, native: true }); } catch (e) {} } });
          normal_tap_2_tap_001.setAlpha(0);
          const normal_tap_3_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 321, w: 80, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_3_tap_001.setAlpha(0);
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _heart = new HeartRate(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_0_text_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            normal_w_1_text_002.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _heart ? _heart.getCurrent() : null;
              const txt = (typeof v === 'number' && v >= 38) ? String(v) : '--';
              normal_w_2_text_003.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_2_text_003.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_3_text_004.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_text_004.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_4_text_005.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "" : '--') });
            } catch (e) { normal_w_4_text_005.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 157, y: 71, w: 220, h: 100, text_size: 66, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const aod_w_1_text_002 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 170, y: 146, w: 200, h: 50, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_text_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            aod_w_1_text_002.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
