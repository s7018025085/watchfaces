import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { HeartRate, Screen } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 60, y: 190, w: 120, h: 70, text_size: 56, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: (data_type.BIO_CHARGE !== undefined ? data_type.BIO_CHARGE : (data_type.BIOCHARGE !== undefined ? data_type.BIOCHARGE : (data_type.HYBRID_CHARGE !== undefined ? data_type.HYBRID_CHARGE : (data_type.HYBRIDCHARGE !== undefined ? data_type.HYBRIDCHARGE : data_type.READINESS)))), unit_type: 0 });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 280, y: 190, w: 120, h: 70, text_size: 56, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.BIO_CHARGE, unit_type: 0 });
          // Полоса normal_w_2_line_001: горизонтальная (заполнение слева направо), значение из источника HEART; собрана из FILL_RECT
          function normal_w_2_line_001_rect(a, b, t, s, dx, dy) {
            const n = b - a + 2 * s, th = t + 2 * s;
            return { x: 140 + a - s + dx, y: 155 - Math.floor(t / 2) - s + dy, w: n, h: th, radius: Math.floor(Math.min(n, th) / 2) };
          }
          // Контур/тень: строка слоя = [расширение с каждой стороны, dx, dy, цвет, прозрачность 0–255]
          const normal_w_2_line_001_dl = [[6, 0, 3, 0xe60000, 77], [2, 0, 3, 0xe60000, 77], [2, 0, 0, 0xf5f5f5, 255], [0, 0, 0, 0x000000, 255]];
          const normal_w_2_line_001_dec = [], normal_w_2_line_001_dvis = [];
          for (let normal_w_2_line_001_di = 0; normal_w_2_line_001_di < 4; normal_w_2_line_001_di++) {
            const d = normal_w_2_line_001_dl[normal_w_2_line_001_di];
            const o = normal_w_2_line_001_rect(0, 210, 11, d[0], d[1], d[2]);
            o.color = d[3];
            normal_w_2_line_001_dec.push(createWidget(widget.FILL_RECT, o));
            normal_w_2_line_001_dvis[normal_w_2_line_001_di] = true;
            try { if (d[4] < 255) normal_w_2_line_001_dec[normal_w_2_line_001_di].setAlpha(d[4]); } catch (e) {}
          }
          const normal_w_2_line_001_a = [0, 71, 142], normal_w_2_line_001_b = [68, 139, 210], normal_w_2_line_001_c = [0x33ff66, 0x998033, 0xff0000];
          const normal_w_2_line_001_segs = [], normal_w_2_line_001_vis = [];
          for (let normal_w_2_line_001_i = 0; normal_w_2_line_001_i < 3; normal_w_2_line_001_i++) {
            const o = normal_w_2_line_001_rect(normal_w_2_line_001_a[normal_w_2_line_001_i], normal_w_2_line_001_b[normal_w_2_line_001_i], 11, 0, 0, 0);
            o.color = normal_w_2_line_001_c[normal_w_2_line_001_i];
            normal_w_2_line_001_segs.push(createWidget(widget.FILL_RECT, o));
            normal_w_2_line_001_vis[normal_w_2_line_001_i] = false;
            if (!normal_w_2_line_001_vis[normal_w_2_line_001_i]) normal_w_2_line_001_segs[normal_w_2_line_001_i].setProperty(prop.VISIBLE, false);
          }
          let normal_w_2_line_001_target = 0, normal_w_2_line_001_phase = 0, normal_w_2_line_001_timer = null, normal_w_2_line_001_err = false;
          const normal_w_2_line_001_last = [];   // последнее состояние сегмента: setProperty — только у изменившихся
          function normal_w_2_line_001_draw(r, f, g) {
            try {
              const cur = 0 + (210) * r;
              const lw = 11;
              for (let normal_w_2_line_001_k = 0; normal_w_2_line_001_k < 3; normal_w_2_line_001_k++) {
                const a = normal_w_2_line_001_a[normal_w_2_line_001_k], b = normal_w_2_line_001_b[normal_w_2_line_001_k];
                const edge = Math.round(Math.max(a, Math.min(b, cur)));   // граница заполнения внутри сегмента
                const col = normal_w_2_line_001_c[normal_w_2_line_001_k];
                const key = edge + ':' + col + ':' + lw;
                if (normal_w_2_line_001_last[normal_w_2_line_001_k] === key) continue;
                normal_w_2_line_001_last[normal_w_2_line_001_k] = key;
                if (edge === a) { if (normal_w_2_line_001_vis[normal_w_2_line_001_k]) { normal_w_2_line_001_vis[normal_w_2_line_001_k] = false; normal_w_2_line_001_segs[normal_w_2_line_001_k].setProperty(prop.VISIBLE, false); } continue; }
                const o = normal_w_2_line_001_rect(a, edge, lw, 0, 0, 0);
                o.color = col;
                normal_w_2_line_001_segs[normal_w_2_line_001_k].setProperty(prop.MORE, o);
                if (!normal_w_2_line_001_vis[normal_w_2_line_001_k]) { normal_w_2_line_001_vis[normal_w_2_line_001_k] = true; normal_w_2_line_001_segs[normal_w_2_line_001_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_2_line_001_err) { normal_w_2_line_001_err = true; try { console.log('LINE draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_2_line_001_set(val) {
            val = (typeof val === 'number' && isFinite(val)) ? Math.max(0, Math.min(1, val)) : 0;
            normal_w_2_line_001_target = val;
            if (normal_w_2_line_001_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_2_line_001_phase === 0) { normal_w_2_line_001_phase = 1; normal_w_2_line_001_run(); return; }
            normal_w_2_line_001_draw(val, 1, 1);
          }
          function normal_w_2_line_001_run() {
            let n = 0;
            normal_w_2_line_001_draw(0, 0, 0);
            normal_w_2_line_001_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = (1 - Math.pow(1 - (k), 3));
              normal_w_2_line_001_draw(e * normal_w_2_line_001_target, 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_2_line_001_timer); normal_w_2_line_001_timer = null; normal_w_2_line_001_phase = 2;
                normal_w_2_line_001_draw(normal_w_2_line_001_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_2_line_001_replay() {
            if (normal_w_2_line_001_phase !== 2) return;
            normal_w_2_line_001_phase = 1;
            normal_w_2_line_001_run();
          }
      
          // Повтор анимации дуг при возврате на циферблат / пробуждении экрана
          try {
            createWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { console.log('watchface resume'); } catch (e) {}
                try { normal_w_2_line_001_replay(); } catch (e) {}
              },
              pause_call: function () {},
            });
          } catch (e) {}
      
          // Повтор анимации дуг при поднятии руки (Screen.onChange + страховка по паузе таймера)
          try {
            const _scr = new Screen();
            let _scrPrev = 1;
            try { _scrPrev = _scr.getStatus(); } catch (e) {}
            const _raise = function (why) {
              try { console.log('arc replay: ' + why); } catch (e) {}
              try { normal_w_2_line_001_replay(); } catch (e) {}
            };
            self._screen = _scr;
            self._screenCb = function (st) {
              try {
                const cur = (typeof st === 'number') ? st : _scr.getStatus();
                try { console.log('screen status: ' + cur); } catch (e) {}
                const was = _scrPrev; _scrPrev = cur;
                if (cur === 1 && was !== 1) _raise('screen on');
              } catch (e) {}
            };
            _scr.onChange(self._screenCb);
            let _hbLast = Date.now();
            self._raiseTimer = setInterval(function () {
              try {
                const t = Date.now();
                if (t - _hbLast > 3000) _raise('timer gap ' + (t - _hbLast) + ' ms');
                _hbLast = t;
              } catch (e) {}
            }, 1000);
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickSensorsNormal() {
            try {
              const v = _heartVal;
              normal_w_2_line_001_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { normal_w_2_line_001_set(0); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
