import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { launchApp, SYSTEM_APP_ALARM, SYSTEM_APP_CALENDAR, SYSTEM_APP_HR, SYSTEM_APP_PHONE, SYSTEM_APP_SPORT, SYSTEM_APP_STATUS } from '@zos/router'
import { Time, Battery, Step, Calorie, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// ---- Анимация текста (AmazFace): общий рантайм --------------------------------
var __TA = { list: [], all: [], timer: 0, paused: false };
var __taFx = {};
function __taClamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function __taEase(name, t) {
  t = __taClamp(t, 0, 1);
  if (name === 'in') return t * t * t;
  if (name === 'out') { var u = 1 - t; return 1 - u * u * u; }
  if (name === 'inout') return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  return t;
}
function __taMix(c1, c2, t) {
  var r = Math.round(((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
  var g = Math.round(((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
  var b = Math.round((c1 & 255) * (1 - t) + (c2 & 255) * t);
  return (r << 16) | (g << 8) | b;
}
function __taChars(s) {
  var out = [], i = 0, n, c;
  s = String(s == null ? '' : s);
  n = s.length;
  while (i < n) {
    c = s.charCodeAt(i);
    if (c >= 0xD800 && c <= 0xDBFF && i + 1 < n) { out.push(s.substr(i, 2)); i += 2; }
    else { out.push(s.charAt(i)); i += 1; }
  }
  return out;
}
function __taParseNum(s) {
  var m = /-?\d[\d,]*(?:\.\d+)?/.exec(String(s == null ? '' : s));
  if (!m) return null;
  var tok = m[0], clean = tok.replace(/,/g, ''), dot = clean.indexOf('.');
  return { pre: String(s).slice(0, m.index), post: String(s).slice(m.index + tok.length), val: parseFloat(clean), dec: dot >= 0 ? clean.length - dot - 1 : 0, sep: tok.indexOf(',') >= 0 };
}
function __taFmtNum(n, dec, sep) {
  var s = Math.abs(n).toFixed(dec), parts;
  if (sep) { parts = s.split('.'); parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ','); s = parts.join('.'); }
  return (n < 0 && parseFloat(s.replace(/,/g, '')) !== 0 ? '-' : '') + s;
}
function __taGroups(s) {
  var out = [], re = /\d+/g, m;
  s = String(s == null ? '' : s);
  while ((m = re.exec(s)) !== null) out.push({ i: m.index, s: m[0] });
  return out;
}
function __taPhase(a, el) {
  var c = a.cfg, d = c.delay || 0, dur = Math.max(1, a.durOv || c.dur), n = c.rep || 0, gap = c.pause || 0, t, cyc, rep, q, k;
  if (a.perp) return { k: 0, e: 0, ms: Math.max(0, el), rep: 0, done: false, hold: false };
  if (el < d) return { k: 0, e: __taEase(c.ease, 0), ms: 0, rep: 0, done: false, hold: true };
  t = el - d; cyc = dur + gap;
  if (t >= n * cyc + dur) return { k: 1, e: 1, ms: dur, rep: n, done: true, hold: false };
  rep = Math.floor(t / cyc); q = t - rep * cyc; k = q >= dur ? 1 : q / dur;
  return { k: k, e: __taEase(c.ease, k), ms: q >= dur ? dur : q, rep: rep, done: false, hold: false };
}
function __taFinal(a) {
  var s = { text: a.text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: true, alpha: 255 }, fx = __taFx[a.cfg.fx];
  if (fx.final) fx.final(a, s);
  return s;
}
function __taSample(a, el) {
  var ph = __taPhase(a, el), s = __taFinal(a), fx = __taFx[a.cfg.fx], o, key;
  if (ph.done) return { s: s, done: true, ph: ph };
  o = fx.frame(a, ph.k, ph);
  for (key in o) { if (Object.prototype.hasOwnProperty.call(o, key)) s[key] = o[key]; }
  return { s: s, done: false, ph: ph };
}
function __taAlpha(target, v) {
  var wd = target;
  if (!wd) return;
  try { wd.setAlpha(v); } catch (e) {}
}
function __taApply(a, s) {
  var o = {}, any = false, L = a.last, cut, tx = s.text, rest;
  if (a.cellLayout) {
    __taApplyCells(a, s);
    a.last = { text: tx, text2: null, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
    return;
  }
  if (a.w2) {
    cut = tx.indexOf(a.cfg.sep);
    rest = cut >= 0 ? tx.slice(cut + a.cfg.sep.length) : '';
    if (cut >= 0) tx = tx.slice(0, cut);
    if (rest !== L.text2) { try { a.w2.setProperty(prop.MORE, { text: rest }); } catch (e1) {} L.text2 = rest; }
  }
  if (tx !== L.text) { o.text = tx; any = true; }
  if (s.color !== L.color) { o.color = s.color; any = true; }
  if (s.x !== L.x) { o.x = s.x; any = true; }
  if (s.y !== L.y) { o.y = s.y; any = true; }
  if (s.size !== L.size) { o.text_size = s.size; any = true; }
  if (a.c && s.vis !== L.vis) { try { a.c.setProperty(prop.VISIBLE, s.vis); } catch (e2) {} }
  if (s.alpha !== L.alpha && s.alpha !== undefined) {
    __taAlpha(a.w, s.alpha); __taAlpha(a.w2, s.alpha); __taAlpha(a.c, s.alpha);
  }
  a.last = { text: tx, text2: L.text2, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
  if (any && a.w) { try { a.w.setProperty(prop.MORE, o); } catch (e3) {} }
}
function __taShow(a) { __taApply(a, __taFinal(a)); }
// Условия повторного запуска эффектов при изменении исходного текста.
// Для «Проявления» и «Пульсации размера» посимвольный режим дополнительно
// ограничивает сами стили изменившимися разрядами; остальные эффекты фильтруют запуск целиком.
function __taChangeAllowed(a, oldText, newText) {
  var mode = a.cfg.track || 'all', oldD, newD, i, off;
  if (mode === 'all') return true;
  if (mode === 'off') return false;
  oldD = String(oldText == null ? '' : oldText).replace(/[^0-9]/g, '');
  newD = String(newText == null ? '' : newText).replace(/[^0-9]/g, '');
  if (mode === 'changed') return oldD !== newD;
  if (mode === 'seconds' && !a.cfg.trackSec) return false;
  if (mode === 'units') off = 1;
  else if (mode === 'tens') off = 2;
  else if (mode === 'seconds') {
    for (i = 1; i <= 2; i++) {
      if (oldD.charAt(oldD.length - i) !== newD.charAt(newD.length - i)) return true;
    }
    return false;
  } else return true;
  if (oldD.length < off || newD.length < off) return false;
  return oldD.charAt(oldD.length - off) !== newD.charAt(newD.length - off);
}
// Определяет только цифры, которым разрешено анимироваться в посимвольных режимах.
function __taCharTargets(a, why) {
  var cur = __taChars(a.text), old = __taChars(a.prevText || ''), mode = a.cfg.track || 'all';
  var digits = [], target = {}, i, idx, off;
  for (i = 0; i < cur.length; i++) if (cur[i] >= '0' && cur[i] <= '9') digits.push(i);
  if (why === 'open') {
    if (mode === 'seconds' && a.cfg.trackSec) {
      off = Math.max(0, digits.length - 2);
      for (i = off; i < digits.length; i++) target[digits[i]] = true;
    } else if (mode === 'tens' || mode === 'units') {
      off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
      if (off >= 0) target[digits[off]] = true;
    } else if (mode === 'changed') {
      for (i = 0; i < digits.length; i++) target[digits[i]] = true;
    }
    return target;
  }
  if (why !== 'update' && why !== 'wake') return target;
  if (mode === 'seconds') {
    if (!a.cfg.trackSec) return target;
    off = Math.max(0, digits.length - 2);
    for (i = off; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else if (mode === 'tens' || mode === 'units') {
    off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
    if (off >= 0) { idx = digits[off]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else {
    for (i = 0; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  }
  return target;
}
function __taApplyCells(a, s) {
  var l = a.cellLayout, ws = l.widgets, chars = __taChars(s.text), n = ws.length;
  var count = Math.min(chars.length, n), gap = Number(l.gap || 0), total = 0, start, x, cellX, i, ch, col, size, o, prev, w, cw, scale, renderW, al, widths = [];
  // La anchura de composición siempre usa la métrica base para que una pulsación
  // no empuje las cifras vecinas. Solo se ensancha la celda animada, simétricamente.
  for (i = 0; i < count; i++) {
    ch = chars[i]; cw = Math.max(1, Number((l.charWidths && l.charWidths[ch]) || l.defaultWidth || 1));
    widths[i] = cw; total += cw;
  }
  if (count > 1) total += gap * (count - 1);
  if (l.align === 'LEFT') start = Number(l.x || 0);
  else if (l.align === 'RIGHT') start = Number(l.x || 0) + Number(l.w || 0) - total;
  else start = Number(l.x || 0) + Number(l.w || 0) / 2 - total / 2;
  x = start;
  if (!a.cellLast) a.cellLast = [];
  for (i = 0; i < n; i++) {
    ch = i < count ? chars[i] : '';
    cw = i < count ? widths[i] : Math.max(1, Number(l.defaultWidth || 1));
    col = s.charColors && s.charColors[i] != null ? s.charColors[i] : s.color;
    size = s.charSizes && s.charSizes[i] != null ? s.charSizes[i] : s.size;
    scale = a.base.size > 0 ? Math.max(1, Number(size || a.base.size) / a.base.size) : 1;
    renderW = Math.max(cw, Math.ceil(cw * scale));
    cellX = x - (renderW - cw) / 2;
    prev = a.cellLast[i] || { text: null, color: null, size: null, x: null, w: null, alpha: 255 };
    al = s.charAlphas && s.charAlphas[i] != null ? s.charAlphas[i] : (s.alpha == null ? 255 : s.alpha);
    o = {};
    if (ch !== prev.text) o.text = ch;
    if (col !== prev.color) o.color = col;
    if (size !== prev.size) o.text_size = size;
    if (Math.round(cellX) !== prev.x) o.x = Math.round(cellX);
    if (renderW !== prev.w) o.w = renderW;
    w = ws[i];
    if (Object.keys(o).length && w) { try { w.setProperty(prop.MORE, o); } catch (e) {} }
    if (al !== prev.alpha) __taAlpha(w, al);
    a.cellLast[i] = { text: ch, color: col, size: size, x: Math.round(cellX), w: renderW, alpha: al };
    x += cw + gap;
  }
}

function __taEnsure() {
  var ms = 1000, i;
  if (__TA.timer || !__TA.list.length) return;
  for (i = 0; i < __TA.list.length; i++) { if (__TA.list[i].step < ms) ms = __TA.list[i].step; }
  __TA.timer = setInterval(__taStep, Math.max(30, ms));
}
function __taDrop(a) {
  var i = __TA.list.indexOf(a);
  if (i >= 0) __TA.list.splice(i, 1);
  if (!__TA.list.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taStep() {
  var now = Date.now(), keep = [], i, a, r, fx;
  for (i = 0; i < __TA.list.length; i++) {
    a = __TA.list[i];
    r = __taSample(a, now - a.t0);
    fx = __taFx[a.cfg.fx];
    if (r.done) { a.on = false; if (fx.done) fx.done(a); __taShow(a); }
    else { __taApply(a, r.s); keep.push(a); }
  }
  __TA.list = keep;
  if (!keep.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taBegin(a, why) {
  var fx = __taFx[a.cfg.fx];
  a.durOv = 0;
  if (fx.init) fx.init(a, why);
  a.t0 = Date.now(); a.on = true; a.why = why;
}
function __taPlay(a, why) {
  var r;
  if (__TA.paused) return;
  if (a.on && a.cfg.retrig === 'ignore') return;
  __taBegin(a, why);
  r = __taSample(a, 0);
  __taApply(a, r.s);
  if (__TA.list.indexOf(a) < 0) __TA.list.push(a);
  __taEnsure();
}
function __taStop(a) { a.on = false; __taDrop(a); __taShow(a); }
function __taSetText(a, text) {
  var c = a.cfg, fx = __taFx[c.fx], old = a.text, changed;
  text = text == null ? '' : String(text);
  changed = text !== old;
  a.prevText = old;
  a.text = text;
  if (fx.live) { fx.live(a, old, text, changed); return; }
  if (!a.opened) {
    if (fx.can && !fx.can(a)) { __taShow(a); return; }
    a.opened = true;
    if (c.open) __taPlay(a, 'open'); else __taShow(a);
    return;
  }
  if (!changed) { if (!a.on) __taShow(a); return; }
  // Применяется одинаково ко всем эффектам с обработчиком изменения (в том числе
  // count/flash/flip, у которых специальная обработка обновления значения).
  // При проигнорированном изменении сразу показываем новое значение без старого кадра.
  if (!__taChangeAllowed(a, old, text)) { if (a.on) __taStop(a); else __taShow(a); return; }
  if (fx.onChange) { fx.onChange(a, old, text); return; }
  if (c.change && (!fx.can || fx.can(a))) { __taPlay(a, 'update'); return; }
  if (!a.on) __taShow(a);
}
function __taCreate(w, cfg, base, w2, cw, cellLayout) {
  var fx = __taFx[cfg.fx];
  var a = { w: w, w2: w2 || null, c: cw || null, cellLayout: cellLayout || null, cellLast: [], charMode: !!cfg.charMode || !!cellLayout, charTargets: null, cfg: cfg, base: base, text: '', prevText: '', t0: 0, on: false, opened: false, why: '', durOv: 0, perp: !!(fx.perp && cfg.iv < 1000), blink: 0, cnt: null, curV: null, fl: null, step: 50, last: { text: null, text2: null, color: base.fin, x: base.x, y: base.y, size: base.size, vis: true, alpha: 255 } };
  a.step = fx.step ? fx.step(cfg) : 50;
  __TA.all.push(a);
  return a;
}
function __taPause() {
  var i, a;
  __TA.paused = true;
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = [];
  for (i = 0; i < __TA.all.length; i++) { a = __TA.all[i]; a.on = false; __taShow(a); }
}
function __taResume() {
  var now = Date.now(), i, a, fx;
  __TA.paused = false;
  for (i = 0; i < __TA.all.length; i++) {
    a = __TA.all[i]; fx = __taFx[a.cfg.fx];
    if (!a.opened) continue;
    if (fx.resume) { fx.resume(a); continue; }
    if (a.cfg.wake && now - a.t0 > 800) __taPlay(a, 'wake');
  }
}
function __taDestroy() {
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = []; __TA.all = []; __TA.paused = false;
}

__taFx.colon = {
  perp: true,
  step: function (c) { return c.iv; },
  live: function (a, old, text, changed) {
    var c = a.cfg, vis;
    a.opened = true;
    if (__TA.paused) { __taShow(a); return; }
    if (c.iv >= 1000) {
      a.blink = a.blink + 1;
      vis = (((a.blink - 1) % 2) === 0) === (c.cstart === 'visible');
      __taApply(a, { text: text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: vis });
    } else if (!a.on) {
      __taPlay(a, 'open');
    } else {
      __taApply(a, { text: text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: a.last.vis });
    }
  },
  resume: function (a) { if (a.cfg.iv < 1000) __taPlay(a, 'open'); },
  frame: function (a, k, ph) {
    var c = a.cfg, on = (Math.floor(ph.ms / c.iv) % 2) === 0;
    return { vis: on === (c.cstart === 'visible') };
  }
};


// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Dual scene runtime: Normal and AOD are both exported into this one watchface.
// Zepp OS controls visibility through the documented widget show_level property.
WatchFace({
  build() {
    const self = this;

    // Normal scene widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "matovyy_fitnes_tsiferblat_s_otdelnymi_strelkami_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 54, y: 293, w: 110, h: 50, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_1_arc_001 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 44, y: 254, w: 130, h: 130, start_angle: -270, end_angle: -270, color: 0xfd4a00, line_width: 8, corner_flag: 1 });
          // Дуга normal_w_1_arc_001: значение из источника CALORIE, углы на часах -270°…0° (0° = 3 часа)
          let normal_w_1_arc_001_target = 0, normal_w_1_arc_001_phase = 2, normal_w_1_arc_001_timer = null, normal_w_1_arc_001_err = false;
          function normal_w_1_arc_001_draw(r, f, g) {
            try {
              normal_w_1_arc_001.setProperty(prop.MORE, { x: 44, y: 254, w: 130, h: 130, start_angle: -270, end_angle: Math.round(-270 + (270) * r), color: 0xfd4a00, line_width: 8 });
            } catch (e) { if (!normal_w_1_arc_001_err) { normal_w_1_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_1_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_1_arc_001_target = v;
            normal_w_1_arc_001_draw(v, 1, 1);
          }
          const normal_w_2_arc_002 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 173, y: 319, w: 135, h: 135, start_angle: -270, end_angle: -270, color: 0x0c85fd, line_width: 8, corner_flag: 1 });
          // Дуга normal_w_2_arc_002: значение из источника CALORIE, углы на часах -270°…0° (0° = 3 часа)
          let normal_w_2_arc_002_target = 0, normal_w_2_arc_002_phase = 2, normal_w_2_arc_002_timer = null, normal_w_2_arc_002_err = false;
          function normal_w_2_arc_002_draw(r, f, g) {
            try {
              normal_w_2_arc_002.setProperty(prop.MORE, { x: 173, y: 319, w: 135, h: 135, start_angle: -270, end_angle: Math.round(-270 + (270) * r), color: 0x0c85fd, line_width: 8 });
            } catch (e) { if (!normal_w_2_arc_002_err) { normal_w_2_arc_002_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_2_arc_002_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_2_arc_002_target = v;
            normal_w_2_arc_002_draw(v, 1, 1);
          }
          const normal_w_3_text_002 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 185, y: 361, w: 110, h: 50, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_4_text_003 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 272, y: 104, w: 110, h: 50, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_5_arc_003 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 258, y: 59, w: 143, h: 143, start_angle: -270, end_angle: -270, color: 0x15fa1a, line_width: 8, corner_flag: 1 });
          // Дуга normal_w_5_arc_003: значение из источника CALORIE, углы на часах -270°…0° (0° = 3 часа)
          let normal_w_5_arc_003_target = 0, normal_w_5_arc_003_phase = 2, normal_w_5_arc_003_timer = null, normal_w_5_arc_003_err = false;
          function normal_w_5_arc_003_draw(r, f, g) {
            try {
              normal_w_5_arc_003.setProperty(prop.MORE, { x: 258, y: 59, w: 143, h: 143, start_angle: -270, end_angle: Math.round(-270 + (270) * r), color: 0x15fa1a, line_width: 8 });
            } catch (e) { if (!normal_w_5_arc_003_err) { normal_w_5_arc_003_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_5_arc_003_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_5_arc_003_target = v;
            normal_w_5_arc_003_draw(v, 1, 1);
          }
          const normal_w_6_arc_004 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 61, y: 62, w: 350, h: 350, start_angle: -180, end_angle: -180, color: 0xf80328, line_width: 8, corner_flag: 1 });
          // Дуга normal_w_6_arc_004: значение из источника HEART, углы на часах -180°…-90° (0° = 3 часа)
          let normal_w_6_arc_004_target = 0, normal_w_6_arc_004_phase = 2, normal_w_6_arc_004_timer = null, normal_w_6_arc_004_err = false;
          function normal_w_6_arc_004_draw(r, f, g) {
            try {
              normal_w_6_arc_004.setProperty(prop.MORE, { x: 61, y: 62, w: 350, h: 350, start_angle: -180, end_angle: Math.round(-180 + (90) * r), color: 0xf80328, line_width: 8 });
            } catch (e) { if (!normal_w_6_arc_004_err) { normal_w_6_arc_004_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_6_arc_004_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_6_arc_004_target = v;
            normal_w_6_arc_004_draw(v, 1, 1);
          }
          const normal_w_7_text_004 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 95, y: 201, w: 110, h: 50, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_8_text_005_w = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 304, y: 199, w: 61, h: 70, text_size: 46, color: 0xffffff, align_h: align.RIGHT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_8_text_005_m = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 383, y: 199, w: 61, h: 70, text_size: 46, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_8_text_005_c = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 365, y: 199, w: 17, h: 70, text_size: 46, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: ":" });
          const normal_w_8_text_005_a = __taCreate(normal_w_8_text_005_w, { fx: "colon", dur: 1000, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "restart", open: false, wake: false, change: false, track: "changed", trackSec: false, charMode: false, iv: 1000, cstart: "visible", sep: ":" }, { x: 304, y: 199, color: 0xffffff, fin: 0xffffff, size: 46 }, normal_w_8_text_005_m, normal_w_8_text_005_c);
          const normal_w_8_text_005 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_8_text_005_a, o.text); } else { normal_w_8_text_005_w.setProperty(k, o); } } };
          const normal_w_9_text_006 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 320, y: 242, w: 110, h: 50, text_size: 26, color: 0xfd4a00, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 352, y: 307, w: 100, h: 32, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.SUN_SET, unit_type: 1 });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 38, hour_posY: 170, hour_path: "neonovyy_tsiferblat_i_strelki_chasov_hour_hand.png" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 42, minute_posY: 205, minute_path: "neonovyy_tsiferblat_i_strelki_chasov_minute_hand.png" });
          // Секундная стрелка: плавный ход не подтверждён официальной документацией
          // (⚠ unverified) — отдельный IMG сохраняет порядок слоя.
          const normal_w_second_smooth_216 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "neonovyy_tsiferblat_i_strelki_chasov_second_hand.png", pos_x: 201, pos_y: 15, center_x: 240, center_y: 240 });
          const normal_tap_0_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 44, y: 254, w: 130, h: 130, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_SPORT, native: true }); } catch (e) {} } });
          normal_tap_0_tap_001.setAlpha(0);
          const normal_tap_1_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 173, y: 319, w: 135, h: 135, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STATUS, native: true }); } catch (e) {} } });
          normal_tap_1_tap_001.setAlpha(0);
          const normal_tap_2_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 315, y: 341, w: 140, h: 110, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_normal_(!__flashOn_normal_); } catch (e) {} } });
          normal_tap_2_tap_001.setAlpha(0);
          const normal_tap_3_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 272, y: 4, w: 50, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_PHONE, native: true }); } catch (e) {} } });
          normal_tap_3_tap_001.setAlpha(0);
          const normal_tap_4_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 95, y: 121, w: 110, h: 130, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_HR, native: true }); } catch (e) {} } });
          normal_tap_4_tap_001.setAlpha(0);
          const normal_tap_5_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 304, y: 199, w: 130, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_ALARM, native: true }); } catch (e) {} } });
          normal_tap_5_tap_001.setAlpha(0);
          const normal_tap_6_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 320, y: 252, w: 110, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          normal_tap_6_tap_001.setAlpha(0);
          let __flashOn_normal_ = false;
          const __flash_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0xffffff });
          const __flashBtn_normal_ = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_normal_(false); } catch (e) {} } });
          __flashBtn_normal_.setAlpha(0);
          function __flashSet_normal_(on) {
            try {
              __flashOn_normal_ = !!on;
              __flash_normal_.setProperty(prop.VISIBLE, __flashOn_normal_);
              __flashBtn_normal_.setProperty(prop.VISIBLE, __flashOn_normal_);
            } catch (e) {}
          }
          __flashSet_normal_(false);
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            createWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_8_text_005.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            normal_w_9_text_006.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_0_text_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_0_text_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              normal_w_1_arc_001_set(typeof v === 'number' ? (v - 0) / 500 : 0);
            } catch (e) { normal_w_1_arc_001_set(0); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              normal_w_2_arc_002_set(typeof v === 'number' ? (v - 0) / 500 : 0);
            } catch (e) { normal_w_2_arc_002_set(0); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_3_text_002.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_text_002.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_4_text_003.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_4_text_003.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              normal_w_5_arc_003_set(typeof v === 'number' ? (v - 0) / 500 : 0);
            } catch (e) { normal_w_5_arc_003_set(0); }
            try {
              const v = _heartVal;
              normal_w_6_arc_004_set(typeof v === 'number' ? (v - 0) / 240 : 0);
            } catch (e) { normal_w_6_arc_004_set(0); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_7_text_004.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_7_text_004.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
          self._smoothTimerNormal = setInterval(() => {
            try {
              const now = _time ? new Date(_time.getTime()) : new Date();
              let deg = (now.getSeconds() + now.getMilliseconds() / 1000) * 6;
              normal_w_second_smooth_216.setProperty(prop.MORE, { angle: deg });
            } catch (e) {
              if (self._smoothTimerNormal) { clearInterval(self._smoothTimerNormal); self._smoothTimerNormal = null; }
            }
          }, 33);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_text_005 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 320, y: 207, w: 110, h: 50, text_size: 46, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const aod_w_1_text_006 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 320, y: 242, w: 110, h: 50, text_size: 26, color: 0xfd4a00, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_text_005.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            aod_w_1_text_006.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __taDestroy(); } catch (e) {}
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
