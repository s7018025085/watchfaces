import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { LocalStorage } from '@zos/storage'
import { setInterval, clearInterval } from '@zos/timer'

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __afBgL_normal_ = ["mrachnye_postery_mobland_v_setke_edited.png", "mrachnye_postery_mobland_v_setke_edited_3.png", "mrachnye_postery_mobland_v_setke_edited_2.png", "mrachnye_postery_mobland_v_setke_edited_4.png", "mrachnye_postery_mobland_v_setke_edited_5.png", "mrachnye_postery_mobland_v_setke_edited_6.png", "mrachnye_postery_mobland_v_setke_edited_7.png", "mrachnye_postery_mobland_v_setke_edited_8.png"];
          let __afBgI_normal_ = 0;
          try { const __s = new LocalStorage().getItem("afbg_normal_"); const __n = parseInt(__s, 10); if (__n >= 0 && __n < __afBgL_normal_.length) __afBgI_normal_ = __n; } catch (e) {}
          const __afBgA_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: __afBgL_normal_[__afBgI_normal_] });
          __afBgA_normal_.setAlpha(255);
          const __afBgB_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: __afBgL_normal_[__afBgI_normal_] });
          __afBgB_normal_.setAlpha(0);
          let __afBgT_normal_ = null;
          function __afBgGo_normal_(d) {
            const n = __afBgL_normal_.length; if (n < 2) return;
            const prev = __afBgI_normal_; let j = prev + (d < 0 ? -1 : 1);
            if (j >= n) j = 0; if (j < 0) j = n - 1;
            if (j === prev) return;
            __afBgI_normal_ = j;
            try { new LocalStorage().setItem("afbg_normal_", String(j)); } catch (e) {}
            if (__afBgT_normal_) { clearInterval(__afBgT_normal_); __afBgT_normal_ = null; try { __afBgA_normal_.setProperty(prop.SRC, __afBgL_normal_[prev]); __afBgB_normal_.setAlpha(0); } catch (e) {} }
            try { __afBgB_normal_.setProperty(prop.SRC, __afBgL_normal_[j]); __afBgB_normal_.setAlpha(0); } catch (e) { try { __afBgA_normal_.setProperty(prop.SRC, __afBgL_normal_[j]); } catch (e2) {} return; }
            let k = 0;
            __afBgT_normal_ = setInterval(() => { k++; try { __afBgB_normal_.setAlpha(Math.round(255 * k / 10)); if (k >= 10) { clearInterval(__afBgT_normal_); __afBgT_normal_ = null; __afBgA_normal_.setProperty(prop.SRC, __afBgL_normal_[j]); __afBgB_normal_.setAlpha(0); } } catch (e) { clearInterval(__afBgT_normal_); __afBgT_normal_ = null; } }, 30);
          }
          const __afBgTap_normal_ = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, normal_src: "", press_src: "", click_func: () => { try { __afBgGo_normal_(1); } catch (e) {} } });
          __afBgTap_normal_.setAlpha(0);
          (self._afBgCleanup = self._afBgCleanup || []).push(() => { try { if (__afBgT_normal_) { clearInterval(__afBgT_normal_); __afBgT_normal_ = null; } } catch (e) {} });
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
