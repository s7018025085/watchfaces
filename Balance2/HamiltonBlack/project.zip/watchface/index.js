import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time, Battery, Step } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;

// Dual scene runtime: Normal and AOD are both exported into this one watchface.
// Zepp OS controls visibility through the documented widget show_level property.
WatchFace({
  build() {
    const self = this;

    // Normal scene widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "fon_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_text_003 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 310, w: 200, h: 50, text_size: 36, color: 0xeff09d, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_001_wd = ["premium_text_001_d0.png","premium_text_001_d1.png","premium_text_001_d2.png","premium_text_001_d3.png","premium_text_001_d4.png","premium_text_001_d5.png","premium_text_001_d6.png"];
          const normal_w_1_text_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 94, y: -81, w: 294, h: 294, src: normal_w_1_text_001_wd[new Date().getDay()] });
          normal_w_1_text_001.setAlpha(255);
          const normal_w_2_date_day_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 200, y: 364, w: 80, h: 40, text_size: 22, color: 0x141a18, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_3_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 301, y: 229, w: 100, h: 36, text_size: 28, color: 0x141a18, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 188, y: 126, w: 120, h: 40, text_size: 30, color: 0xeff09d, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_w_5_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 58, y: 228, w: 150, h: 36, text_size: 24, color: 0x1c221f, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 35, hour_posY: 150, hour_path: "hand.png" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 53, minute_posY: 197, minute_path: "min_minute_hand.png" });
          // Секундная стрелка: плавный ход не подтверждён официальной документацией
          // (⚠ unverified) — отдельный IMG сохраняет порядок слоя.
          const normal_w_second_smooth_203 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "img_1915_second_hand_second_hand.png", pos_x: 214, pos_y: -11, center_x: 240, center_y: 240 });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_0_text_003.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            normal_w_1_text_001.setProperty(prop.MORE, { src: normal_w_1_text_001_wd[now.getDay()] });
            normal_w_2_date_day_001.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_3_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_3_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_5_steps_001.setProperty(prop.MORE, { text: "" + txt + " " });
            } catch (e) { normal_w_5_steps_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
          self._smoothTimerNormal = setInterval(() => {
            try {
              const now = _time ? new Date(_time.getTime()) : new Date();
              let deg = (now.getSeconds() + now.getMilliseconds() / 1000) * 6;
              normal_w_second_smooth_203.setProperty(prop.MORE, { angle: deg });
            } catch (e) {
              if (self._smoothTimerNormal) { clearInterval(self._smoothTimerNormal); self._smoothTimerNormal = null; }
            }
          }, 50);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_text_003 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 140, y: 310, w: 200, h: 50, text_size: 36, color: 0xeff09d, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const aod_w_1_text_001_wd = ["premium_text_001_d0_2.png","premium_text_001_d1_2.png","premium_text_001_d2_2.png","premium_text_001_d3_2.png","premium_text_001_d4_2.png","premium_text_001_d5_2.png","premium_text_001_d6_2.png"];
          const aod_w_1_text_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_AOD,
          x: 94, y: -81, w: 294, h: 294, src: aod_w_1_text_001_wd[new Date().getDay()] });
          aod_w_1_text_001.setAlpha(255);
          const aod_w_2_date_day_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 200, y: 364, w: 80, h: 40, text_size: 22, color: 0xe1e294, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const aod_w_3_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 301, y: 229, w: 100, h: 36, text_size: 28, color: 0xeff09d, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const aod_w_4_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: 58, y: 227, w: 150, h: 36, text_size: 24, color: 0xeff09d, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_text_003.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            aod_w_1_text_001.setProperty(prop.MORE, { src: aod_w_1_text_001_wd[now.getDay()] });
            aod_w_2_date_day_001.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
          function _tickSensorsAod() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              aod_w_3_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { aod_w_3_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              aod_w_4_steps_001.setProperty(prop.MORE, { text: "" + txt + " " });
            } catch (e) { aod_w_4_steps_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsAod();
          self._sensorTimerAod = setInterval(_tickSensorsAod, 5000);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
