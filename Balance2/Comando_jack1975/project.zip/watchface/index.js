import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { setBrightness, getBrightness, setAutoBrightness, getAutoBrightness } from '@zos/display'
import { launchApp, SYSTEM_APP_CALENDAR } from '@zos/router'
import { Time, Battery, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval, setTimeout, clearTimeout } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// ---- Анимация текста (AmazFace): общий рантайм --------------------------------
var __TA = { list: [], all: [], timer: 0, paused: false };
var __taFx = {};
function __taClamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function __taEase(name, t) {
  t = __taClamp(t, 0, 1);
  if (name === 'in') return t * t * t;
  if (name === 'out') { var u = 1 - t; return 1 - u * u * u; }
  if (name === 'inout') return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  return t;
}
function __taMix(c1, c2, t) {
  var r = Math.round(((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
  var g = Math.round(((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
  var b = Math.round((c1 & 255) * (1 - t) + (c2 & 255) * t);
  return (r << 16) | (g << 8) | b;
}
function __taChars(s) {
  var out = [], i = 0, n, c;
  s = String(s == null ? '' : s);
  n = s.length;
  while (i < n) {
    c = s.charCodeAt(i);
    if (c >= 0xD800 && c <= 0xDBFF && i + 1 < n) { out.push(s.substr(i, 2)); i += 2; }
    else { out.push(s.charAt(i)); i += 1; }
  }
  return out;
}
function __taParseNum(s) {
  var m = /-?\d[\d,]*(?:\.\d+)?/.exec(String(s == null ? '' : s));
  if (!m) return null;
  var tok = m[0], clean = tok.replace(/,/g, ''), dot = clean.indexOf('.');
  return { pre: String(s).slice(0, m.index), post: String(s).slice(m.index + tok.length), val: parseFloat(clean), dec: dot >= 0 ? clean.length - dot - 1 : 0, sep: tok.indexOf(',') >= 0 };
}
function __taFmtNum(n, dec, sep) {
  var s = Math.abs(n).toFixed(dec), parts;
  if (sep) { parts = s.split('.'); parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ','); s = parts.join('.'); }
  return (n < 0 && parseFloat(s.replace(/,/g, '')) !== 0 ? '-' : '') + s;
}
function __taGroups(s) {
  var out = [], re = /\d+/g, m;
  s = String(s == null ? '' : s);
  while ((m = re.exec(s)) !== null) out.push({ i: m.index, s: m[0] });
  return out;
}
function __taPhase(a, el) {
  var c = a.cfg, d = c.delay || 0, dur = Math.max(1, a.durOv || c.dur), n = c.rep || 0, gap = c.pause || 0, t, cyc, rep, q, k;
  if (a.perp) return { k: 0, e: 0, ms: Math.max(0, el), rep: 0, done: false, hold: false };
  if (el < d) return { k: 0, e: __taEase(c.ease, 0), ms: 0, rep: 0, done: false, hold: true };
  t = el - d; cyc = dur + gap;
  if (t >= n * cyc + dur) return { k: 1, e: 1, ms: dur, rep: n, done: true, hold: false };
  rep = Math.floor(t / cyc); q = t - rep * cyc; k = q >= dur ? 1 : q / dur;
  return { k: k, e: __taEase(c.ease, k), ms: q >= dur ? dur : q, rep: rep, done: false, hold: false };
}
function __taFinal(a) {
  var s = { text: a.text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: true, alpha: 255 }, fx = __taFx[a.cfg.fx];
  if (fx.final) fx.final(a, s);
  return s;
}
function __taSample(a, el) {
  var ph = __taPhase(a, el), s = __taFinal(a), fx = __taFx[a.cfg.fx], o, key;
  if (ph.done) return { s: s, done: true, ph: ph };
  o = fx.frame(a, ph.k, ph);
  for (key in o) { if (Object.prototype.hasOwnProperty.call(o, key)) s[key] = o[key]; }
  return { s: s, done: false, ph: ph };
}
function __taAlpha(target, v) {
  var wd = target;
  if (!wd) return;
  try { wd.setAlpha(v); } catch (e) {}
}
function __taApply(a, s) {
  var o = {}, any = false, L = a.last, cut, tx = s.text, rest;
  if (a.cellLayout) {
    __taApplyCells(a, s);
    a.last = { text: tx, text2: null, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
    return;
  }
  if (a.w2) {
    cut = tx.indexOf(a.cfg.sep);
    rest = cut >= 0 ? tx.slice(cut + a.cfg.sep.length) : '';
    if (cut >= 0) tx = tx.slice(0, cut);
    if (rest !== L.text2) { try { a.w2.setProperty(prop.MORE, { text: rest }); } catch (e1) {} L.text2 = rest; }
  }
  if (tx !== L.text) { o.text = tx; any = true; }
  if (s.color !== L.color) { o.color = s.color; any = true; }
  if (s.x !== L.x) { o.x = s.x; any = true; }
  if (s.y !== L.y) { o.y = s.y; any = true; }
  if (s.size !== L.size) { o.text_size = s.size; any = true; }
  if (a.c && s.vis !== L.vis) { try { a.c.setProperty(prop.VISIBLE, s.vis); } catch (e2) {} }
  if (s.alpha !== L.alpha && s.alpha !== undefined) {
    __taAlpha(a.w, s.alpha); __taAlpha(a.w2, s.alpha); __taAlpha(a.c, s.alpha);
  }
  a.last = { text: tx, text2: L.text2, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
  if (any && a.w) { try { a.w.setProperty(prop.MORE, o); } catch (e3) {} }
}
function __taShow(a) { __taApply(a, __taFinal(a)); }
// Условия повторного запуска эффектов при изменении исходного текста.
// Для «Проявления» и «Пульсации размера» посимвольный режим дополнительно
// ограничивает сами стили изменившимися разрядами; остальные эффекты фильтруют запуск целиком.
function __taChangeAllowed(a, oldText, newText) {
  var mode = a.cfg.track || 'all', oldD, newD, i, off;
  if (mode === 'all') return true;
  if (mode === 'off') return false;
  oldD = String(oldText == null ? '' : oldText).replace(/[^0-9]/g, '');
  newD = String(newText == null ? '' : newText).replace(/[^0-9]/g, '');
  if (mode === 'changed') return oldD !== newD;
  if (mode === 'seconds' && !a.cfg.trackSec) return false;
  if (mode === 'units') off = 1;
  else if (mode === 'tens') off = 2;
  else if (mode === 'seconds') {
    for (i = 1; i <= 2; i++) {
      if (oldD.charAt(oldD.length - i) !== newD.charAt(newD.length - i)) return true;
    }
    return false;
  } else return true;
  if (oldD.length < off || newD.length < off) return false;
  return oldD.charAt(oldD.length - off) !== newD.charAt(newD.length - off);
}
// Определяет только цифры, которым разрешено анимироваться в посимвольных режимах.
function __taCharTargets(a, why) {
  var cur = __taChars(a.text), old = __taChars(a.prevText || ''), mode = a.cfg.track || 'all';
  var digits = [], target = {}, i, idx, off;
  for (i = 0; i < cur.length; i++) if (cur[i] >= '0' && cur[i] <= '9') digits.push(i);
  if (why === 'open') {
    if (mode === 'seconds' && a.cfg.trackSec) {
      off = Math.max(0, digits.length - 2);
      for (i = off; i < digits.length; i++) target[digits[i]] = true;
    } else if (mode === 'tens' || mode === 'units') {
      off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
      if (off >= 0) target[digits[off]] = true;
    } else if (mode === 'changed') {
      for (i = 0; i < digits.length; i++) target[digits[i]] = true;
    }
    return target;
  }
  if (why !== 'update' && why !== 'wake') return target;
  if (mode === 'seconds') {
    if (!a.cfg.trackSec) return target;
    off = Math.max(0, digits.length - 2);
    for (i = off; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else if (mode === 'tens' || mode === 'units') {
    off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
    if (off >= 0) { idx = digits[off]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else {
    for (i = 0; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  }
  return target;
}
function __taApplyCells(a, s) {
  var l = a.cellLayout, ws = l.widgets, chars = __taChars(s.text), n = ws.length;
  var count = Math.min(chars.length, n), gap = Number(l.gap || 0), total = 0, start, x, cellX, i, ch, col, size, o, prev, w, cw, scale, renderW, al, widths = [];
  // La anchura de composición siempre usa la métrica base para que una pulsación
  // no empuje las cifras vecinas. Solo se ensancha la celda animada, simétricamente.
  for (i = 0; i < count; i++) {
    ch = chars[i]; cw = Math.max(1, Number((l.charWidths && l.charWidths[ch]) || l.defaultWidth || 1));
    widths[i] = cw; total += cw;
  }
  if (count > 1) total += gap * (count - 1);
  if (l.align === 'LEFT') start = Number(l.x || 0);
  else if (l.align === 'RIGHT') start = Number(l.x || 0) + Number(l.w || 0) - total;
  else start = Number(l.x || 0) + Number(l.w || 0) / 2 - total / 2;
  x = start;
  if (!a.cellLast) a.cellLast = [];
  for (i = 0; i < n; i++) {
    ch = i < count ? chars[i] : '';
    cw = i < count ? widths[i] : Math.max(1, Number(l.defaultWidth || 1));
    col = s.charColors && s.charColors[i] != null ? s.charColors[i] : s.color;
    size = s.charSizes && s.charSizes[i] != null ? s.charSizes[i] : s.size;
    scale = a.base.size > 0 ? Math.max(1, Number(size || a.base.size) / a.base.size) : 1;
    renderW = Math.max(cw, Math.ceil(cw * scale));
    cellX = x - (renderW - cw) / 2;
    prev = a.cellLast[i] || { text: null, color: null, size: null, x: null, w: null, alpha: 255 };
    al = s.charAlphas && s.charAlphas[i] != null ? s.charAlphas[i] : (s.alpha == null ? 255 : s.alpha);
    o = {};
    if (ch !== prev.text) o.text = ch;
    if (col !== prev.color) o.color = col;
    if (size !== prev.size) o.text_size = size;
    if (Math.round(cellX) !== prev.x) o.x = Math.round(cellX);
    if (renderW !== prev.w) o.w = renderW;
    w = ws[i];
    if (Object.keys(o).length && w) { try { w.setProperty(prop.MORE, o); } catch (e) {} }
    if (al !== prev.alpha) __taAlpha(w, al);
    a.cellLast[i] = { text: ch, color: col, size: size, x: Math.round(cellX), w: renderW, alpha: al };
    x += cw + gap;
  }
}

function __taEnsure() {
  var ms = 1000, i;
  if (__TA.timer || !__TA.list.length) return;
  for (i = 0; i < __TA.list.length; i++) { if (__TA.list[i].step < ms) ms = __TA.list[i].step; }
  __TA.timer = setInterval(__taStep, Math.max(30, ms));
}
function __taDrop(a) {
  var i = __TA.list.indexOf(a);
  if (i >= 0) __TA.list.splice(i, 1);
  if (!__TA.list.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taStep() {
  var now = Date.now(), keep = [], i, a, r, fx;
  for (i = 0; i < __TA.list.length; i++) {
    a = __TA.list[i];
    r = __taSample(a, now - a.t0);
    fx = __taFx[a.cfg.fx];
    if (r.done) { a.on = false; if (fx.done) fx.done(a); __taShow(a); }
    else { __taApply(a, r.s); keep.push(a); }
  }
  __TA.list = keep;
  if (!keep.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taBegin(a, why) {
  var fx = __taFx[a.cfg.fx];
  a.durOv = 0;
  if (fx.init) fx.init(a, why);
  a.t0 = Date.now(); a.on = true; a.why = why;
}
function __taPlay(a, why) {
  var r;
  if (__TA.paused) return;
  if (a.on && a.cfg.retrig === 'ignore') return;
  __taBegin(a, why);
  r = __taSample(a, 0);
  __taApply(a, r.s);
  if (__TA.list.indexOf(a) < 0) __TA.list.push(a);
  __taEnsure();
}
function __taStop(a) { a.on = false; __taDrop(a); __taShow(a); }
function __taSetText(a, text) {
  var c = a.cfg, fx = __taFx[c.fx], old = a.text, changed;
  text = text == null ? '' : String(text);
  changed = text !== old;
  a.prevText = old;
  a.text = text;
  if (fx.live) { fx.live(a, old, text, changed); return; }
  if (!a.opened) {
    if (fx.can && !fx.can(a)) { __taShow(a); return; }
    a.opened = true;
    if (c.open) __taPlay(a, 'open'); else __taShow(a);
    return;
  }
  if (!changed) { if (!a.on) __taShow(a); return; }
  // Применяется одинаково ко всем эффектам с обработчиком изменения (в том числе
  // count/flash/flip, у которых специальная обработка обновления значения).
  // При проигнорированном изменении сразу показываем новое значение без старого кадра.
  if (!__taChangeAllowed(a, old, text)) { if (a.on) __taStop(a); else __taShow(a); return; }
  if (fx.onChange) { fx.onChange(a, old, text); return; }
  if (c.change && (!fx.can || fx.can(a))) { __taPlay(a, 'update'); return; }
  if (!a.on) __taShow(a);
}
function __taCreate(w, cfg, base, w2, cw, cellLayout) {
  var fx = __taFx[cfg.fx];
  var a = { w: w, w2: w2 || null, c: cw || null, cellLayout: cellLayout || null, cellLast: [], charMode: !!cfg.charMode || !!cellLayout, charTargets: null, cfg: cfg, base: base, text: '', prevText: '', t0: 0, on: false, opened: false, why: '', durOv: 0, perp: !!(fx.perp && cfg.iv < 1000), blink: 0, cnt: null, curV: null, fl: null, step: 50, last: { text: null, text2: null, color: base.fin, x: base.x, y: base.y, size: base.size, vis: true, alpha: 255 } };
  a.step = fx.step ? fx.step(cfg) : 50;
  __TA.all.push(a);
  return a;
}
function __taPause() {
  var i, a;
  __TA.paused = true;
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = [];
  for (i = 0; i < __TA.all.length; i++) { a = __TA.all[i]; a.on = false; __taShow(a); }
}
function __taResume() {
  var now = Date.now(), i, a, fx;
  __TA.paused = false;
  for (i = 0; i < __TA.all.length; i++) {
    a = __TA.all[i]; fx = __taFx[a.cfg.fx];
    if (!a.opened) continue;
    if (fx.resume) { fx.resume(a); continue; }
    if (a.cfg.wake && now - a.t0 > 800) __taPlay(a, 'wake');
  }
}
function __taDestroy() {
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = []; __TA.all = []; __TA.paused = false;
}

__taFx.count = {
  step: function () { return 50; },
  can: function (a) { return !!__taParseNum(a.text); },
  init: function (a, why) {
    var c = a.cfg, p = __taParseNum(a.text), from = c.from;
    if (!p) { a.cnt = null; return; }
    if (why === 'update' && a.curV !== null) from = a.curV;
    a.cnt = { p: p, from: from, to: c.fixed ? c.to : p.val };
  },
  frame: function (a, k, ph) {
    var n = a.cnt, v;
    if (!n) return {};
    v = n.from + (n.to - n.from) * ph.e;
    a.curV = v;
    return { text: n.p.pre + __taFmtNum(v, a.cfg.dec >= 0 ? a.cfg.dec : n.p.dec, n.p.sep) + n.p.post };
  },
  final: function (a, s) {
    var p = __taParseNum(a.text);
    if (a.cfg.fixed && p) s.text = p.pre + __taFmtNum(a.cfg.to, a.cfg.dec >= 0 ? a.cfg.dec : p.dec, p.sep) + p.post;
  },
  done: function (a) {
    var p = __taParseNum(a.text);
    a.curV = a.cfg.fixed ? a.cfg.to : (p ? p.val : null);
  },
  onChange: function (a, old, text) {
    var c = a.cfg;
    if (!__taParseNum(text) || c.upd === 'jump') { __taStop(a); return; }
    __taPlay(a, c.upd === 'restart' ? 'restart' : 'update');
  }
};


const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}
import { readFileSync, writeFileSync } from '@zos/fs'

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    const __afEd = [];
    let __afEdCur = null;
    const __afEdParts = {};
    const __afEdTaps = {};
    function __afEdSetVis(part, v) {
      try {
        if (part.vis) part.vis(v);
        else if (typeof __afSetProfileVisible === 'function') __afSetProfileVisible(part.w, v);
        else part.w.setProperty(prop.VISIBLE, v);
      } catch (e) {}
    }
    function __afEdReg(w, t, o, vis) {
      if (!__afEdCur) return;
      const list = __afEdParts[__afEdCur] || (__afEdParts[__afEdCur] = []);
      for (let i = 0; i < list.length; i++) { if (list[i].w === w) { if (vis) list[i].vis = vis; return; } }
      const so = {};
      const ks = ['x', 'y', 'w', 'h', 'center_x', 'center_y', 'color', 'alpha'];
      for (let q = 0; q < ks.length; q++) { if (o && typeof o[ks[q]] === 'number') so[ks[q]] = o[ks[q]]; }
      const part = { w: w, t: t, o: so, vis: vis || null, a0: typeof so.alpha === 'number' ? so.alpha : 255, ov: -1, sa: null };
      try {
        const sa = w.setAlpha;
        if (typeof sa === 'function') {
          part.sa = function (a) { return sa.call(w, a); };
          w.setAlpha = function (a) { part.a0 = a; return sa.call(w, part.ov >= 0 ? Math.round(255 * part.ov / 100) : a); };
        }
      } catch (e) {}
      list.push(part);
    }
    function __afEdTap(id, w, x, y, bw, bh) { (__afEdTaps[id] = __afEdTaps[id] || []).push({ w: w, x: x, y: y, bw: bw, bh: bh }); }

    const __afProfileWidgets = { day: [], night: [] };
    const __afProfileWidgetState = new Map();
    let __afActiveProfile = '';
    function __afCreateProfileWidget(profile, id, options) {
      const w = createWidget(id, options);
      try { __afEdReg(w, id, options); } catch (e) {}
      const record = { widget: w, profile: profile, visible: true };
      __afProfileWidgetState.set(w, record);
      __afProfileWidgets[profile].push(record);
      try { w.setProperty(prop.VISIBLE, profile === __afActiveProfile); } catch (e) {}
      return w;
    }
    function __afCreateDayWidget(id, options) { return __afCreateProfileWidget('day', id, options); }
    function __afCreateNightWidget(id, options) { return __afCreateProfileWidget('night', id, options); }
    function __afSetProfileVisible(w, visible) {
      const record = __afProfileWidgetState.get(w);
      if (!record) { try { w.setProperty(prop.VISIBLE, !!visible); } catch (e) {} return; }
      record.visible = !!visible;
      try { w.setProperty(prop.VISIBLE, record.visible && record.profile === __afActiveProfile); } catch (e) {}
    }
    function __afProfileApply(profile) {
      profile = profile === 'night' ? 'night' : 'day';
      if (profile === __afActiveProfile) return;
      try { const offs = self._flashOffs || []; for (let i = 0; i < offs.length; i++) { try { offs[i](); } catch (e) {} } } catch (e) {}
      __afActiveProfile = profile;
      ['day', 'night'].forEach(function (key) {
        const list = __afProfileWidgets[key] || [];
        for (let i = 0; i < list.length; i++) {
          const record = list[i];
          try { record.widget.setProperty(prop.VISIBLE, record.visible && key === profile); } catch (e) {}
        }
      });
    }
    let __afProfileTime = null;
    try { __afProfileTime = new Time(); } catch (e) {}
    function __afProfileRefresh() {
      const mode = __afProfilePrefs.profileMode || 'day';
      let target = mode === 'night' ? 'night' : 'day';
      if (mode === 'auto') {
        const now = __afProfileTime ? new Date(__afProfileTime.getTime()) : new Date();
        const hour = now.getHours();
        const start = Number(__afProfilePrefs.profileStart);
        const end = Number(__afProfilePrefs.profileEnd);
        const night = start !== end && (start < end ? hour >= start && hour < end : hour >= start || hour < end);
        target = night ? 'night' : 'day';
      }
      __afProfileApply(target);
      try { if (typeof __afPanelRefresh === 'function') __afPanelRefresh(); } catch (e) {}
    }
// ---- Плавающий AOD: настройки с часов (файл hmFS), единый таймер для всех плавающих текстов ----
    const __afFloatPath = "amazface_float_5356320_1794848505029.json";
    const __afFloatDef = {"iv":1,"st":6,"mg":0};
    const __afFloatCur = { on: true, iv: 1, st: 6, mg: 0 };
    const __afFloatItems = [];
    let __afFloatSeen = '';
    let __afFloatSaveOk = true;
    // Файл читается/пишется через @zos/fs (readFileSync/writeFileSync, каталог /data циферблата).
    function __afFloatRaw() {
      try {
        const t = readFileSync({ path: __afFloatPath, options: { encoding: 'utf8' } });
        return (typeof t === 'string' && t.length <= 512) ? t : '';
      } catch (e) { return ''; }
    }
    function __afFloatParse(raw) {
      try {
        const data = JSON.parse(raw);
        if (!data || typeof data !== 'object') return false;
        if (typeof data.on === 'boolean') __afFloatCur.on = data.on;
        if ([1, 5, 10, 30, 60].indexOf(data.iv) >= 0) __afFloatCur.iv = data.iv;
        if (typeof data.st === 'number' && data.st >= 1 && data.st <= 60) __afFloatCur.st = Math.round(data.st);
        if (typeof data.mg === 'number' && data.mg >= 0 && data.mg <= 120) __afFloatCur.mg = Math.round(data.mg);
        return true;
      } catch (e) { return false; }
    }
    function __afFloatLoad() {
      const raw = __afFloatRaw();
      if (raw) { __afFloatSeen = raw; __afFloatParse(raw); }
    }
    function __afFloatSave() {
      try {
        const raw = JSON.stringify({ on: __afFloatCur.on, iv: __afFloatCur.iv, st: __afFloatCur.st, mg: __afFloatCur.mg });
        writeFileSync({ path: __afFloatPath, data: raw, options: { encoding: 'utf8' } });
        __afFloatSeen = raw;
        __afFloatSaveOk = (__afFloatRaw() === raw);
      } catch (e) { __afFloatSaveOk = false; }
    }
    // AOD может работать в другом запуске кода, чем панель настроек, поэтому на каждом тике
    // сверяем файл: изменились настройки — применяем (выкл. → тексты на место, частота → новый таймер).
    function __afFloatSync() {
      const raw = __afFloatRaw();
      if (!raw || raw === __afFloatSeen) return false;
      __afFloatSeen = raw;
      const wasOn = __afFloatCur.on, wasIv = __afFloatCur.iv;
      if (!__afFloatParse(raw)) return false;
      if (wasOn !== __afFloatCur.on || wasIv !== __afFloatCur.iv) {
        if (!__afFloatCur.on) { for (let i = 0; i < __afFloatItems.length; i++) { try { __afFloatItems[i].reset(); } catch (e) {} } }
        __afFloatRestart();
        return true;
      }
      return false;
    }
    function __afFloatRestart() {
      try { if (self._floatTimers) { for (let i = 0; i < self._floatTimers.length; i++) clearInterval(self._floatTimers[i]); } } catch (e) {}
      self._floatTimers = [];
      if (!__afFloatCur.on) return;
      self._floatTimers.push(setInterval(function () {
        if (__afFloatSync()) return;
        for (let i = 0; i < __afFloatItems.length; i++) { try { __afFloatItems[i].step(); } catch (e) {} }
      }, __afFloatCur.iv * 1000));
    }
    function __afFloatRegister(step, reset) {
      __afFloatItems.push({ step: step, reset: reset });
      __afFloatRestart();
    }
    // Вызывается панелью после любого изменения: выключили — тексты возвращаются на место.
    function __afFloatApply() {
      if (!__afFloatCur.on) { for (let i = 0; i < __afFloatItems.length; i++) { try { __afFloatItems[i].reset(); } catch (e) {} } }
      __afFloatRestart();
      __afFloatSave();
    }
    __afFloatLoad();
    // Day profile widgets — isolated lexical scope
    {
          const __afGrpAl_normal_ = new Map(); const __afGrpP_normal_ = { "group_8a4e13bad1804a4fa3a18156a7a664f5": 0 }; const __afGrpTm_normal_ = {};
          function __afGrpApply_normal_(g) { const l = __afGrpW_normal_[g] || []; const p = __afGrpP_normal_[g]; for (let i = 0; i < l.length; i++) { const a = __afGrpAl_normal_.has(l[i]) ? __afGrpAl_normal_.get(l[i]) : 255; try { l[i].setAlpha(Math.round(a * p)); } catch (e) {} } }
          function __afGrpSA_normal_(g, w, a) { __afGrpAl_normal_.set(w, a); const p = __afGrpP_normal_[g]; try { w.setAlpha(p === undefined || p >= 1 ? a : Math.round(a * p)); } catch (e) {} }
          function __afGrpFade_normal_(g, off, ms) { const l = __afGrpW_normal_[g] || []; if (__afGrpTm_normal_[g]) { clearInterval(__afGrpTm_normal_[g]); __afGrpTm_normal_[g] = null; } __afGrpOff_normal_[g] = !!off; if (__afGrpP_normal_[g] === undefined) __afGrpP_normal_[g] = off ? 1 : 0; if (!off) { __afGrpApply_normal_(g); for (let i = 0; i < l.length; i++) { const d = __afGrpDes_normal_.has(l[i]) ? __afGrpDes_normal_.get(l[i]) : true; try { __afSetProfileVisible(l[i], d); } catch (e) {} } } const N = 10; __afGrpTm_normal_[g] = setInterval(function () { let p = __afGrpP_normal_[g] + (off ? -1 : 1) / N; if (p < 0) p = 0; if (p > 1) p = 1; __afGrpP_normal_[g] = p; __afGrpApply_normal_(g); if (p === (off ? 0 : 1)) { clearInterval(__afGrpTm_normal_[g]); __afGrpTm_normal_[g] = null; if (off) { for (let i = 0; i < l.length; i++) { try { __afSetProfileVisible(l[i], false); } catch (e) {} } } } }, Math.max(16, Math.round(ms / N))); }
          const __afGrpW_normal_ = {}; const __afGrpDes_normal_ = new Map(); const __afGrpOff_normal_ = { "group_8a4e13bad1804a4fa3a18156a7a664f5": true };
          function __afGrpCreate_normal_(g, id, o) { const w = __afCreateDayWidget(id, o); (__afGrpW_normal_[g] = __afGrpW_normal_[g] || []).push(w); if (o && typeof o.alpha === 'number') __afGrpAl_normal_.set(w, o.alpha); if (__afGrpP_normal_[g] === 0) { try { w.setAlpha(0); } catch (e) {} } if (__afGrpOff_normal_[g]) { try { __afSetProfileVisible(w, false); } catch (e) {} } try { if (typeof __afEdReg === 'function') __afEdReg(w, id, o, function (v) { __afGrpVis_normal_(g, w, v); }); } catch (e) {} return w; }
          function __afGrpVis_normal_(g, w, v) { __afGrpDes_normal_.set(w, !!v); try { __afSetProfileVisible(w, !!v && !__afGrpOff_normal_[g]); } catch (e) {} }
          function __afGrpSet_normal_(g, off) { if (__afGrpTm_normal_[g]) { clearInterval(__afGrpTm_normal_[g]); __afGrpTm_normal_[g] = null; } if (__afGrpP_normal_[g] !== undefined) { __afGrpP_normal_[g] = off ? 0 : 1; if (!off) __afGrpApply_normal_(g); } __afGrpOff_normal_[g] = !!off; const l = __afGrpW_normal_[g] || []; for (let i = 0; i < l.length; i++) { const d = __afGrpDes_normal_.has(l[i]) ? __afGrpDes_normal_.get(l[i]) : true; try { __afSetProfileVisible(l[i], d && !off); } catch (e) {} } }
          const __bgColor_normal_ = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "photo_2026_11_16_22_02_00_bg.png" });
          __bgImage_normal_.setAlpha(255);
          __afEdCur = "text_005"; const normal_w_0_text_005 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 411, y: 218, w: 60, h: 50, text_size: 36, color: 0xf6e493, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "text_005", n: "Текст", d: "DAY", h: normal_w_0_text_005, x: 411, y: 218, w: 60, ht: 50, s: 36, c: 0xf6e493, ah: "CENTER_H" });
          __afEdCur = "text_006"; const normal_w_1_text_006 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 308, y: 219, w: 94, h: 50, text_size: 36, color: 0xf6e493, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "text_006", n: "Текст", d: "WEEKDAY", h: normal_w_1_text_006, x: 308, y: 219, w: 94, ht: 50, s: 36, c: 0xf6e493, ah: "CENTER_H" });
          __afEdCur = "text_001"; const normal_w_2_text_001 = __afGrpCreate_normal_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT, { x: 90, y: 170, w: 136, h: 50, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "text_001", n: "Текст", d: "HEART", h: normal_w_2_text_001, x: 90, y: 170, w: 136, ht: 50, s: 36, c: 0xabd059, ah: "LEFT" });
          const normal_w_3_text_008_w = __afGrpCreate_normal_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT, { x: 90, y: 215, w: 153, h: 50, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_3_text_008_a = __taCreate(normal_w_3_text_008_w, { fx: "count", dur: 1200, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "restart", open: true, wake: false, change: false, track: "changed", trackSec: false, charMode: false, from: 0, to: 1000, fixed: false, dec: -1, upd: "continue" }, { x: 90, y: 215, color: 0xabd059, fin: 0xabd059, size: 36 });
          const normal_w_3_text_008 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_3_text_008_a, o.text); } else { normal_w_3_text_008_w.setProperty(k, o); } } };
          __afEdCur = "weather_icon_001"; __afEd.push({ id: "weather_icon_001", n: "Значок погод", d: "Значок погоды", g: 1, x: 90, y: 253, w: 64, ht: 64 }); const normal_w_4_weather_icon_001 = __afGrpCreate_normal_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.IMG_LEVEL, { x: 90, y: 253, w: 64, h: 64, image_array: ["weather/64x64/0_cloudy.png", "weather/64x64/1_showers.png", "weather/64x64/2_snow_showers.png", "weather/64x64/3_sunny.png", "weather/64x64/4_overcast.png", "weather/64x64/5_light_rain.png", "weather/64x64/6_light_snow.png", "weather/64x64/7_moderate_rain.png", "weather/64x64/8_moderate_snow.png", "weather/64x64/9_heavy_snow.png", "weather/64x64/10_heavy_rain.png", "weather/64x64/11_sandstorm.png", "weather/64x64/12_rain_snow.png", "weather/64x64/13_fog.png", "weather/64x64/14_hazy.png", "weather/64x64/15_thunderstorm.png", "weather/64x64/16_snowstorm.png", "weather/64x64/17_floating_dust.png", "weather/64x64/18_very_heavy_rainstorm.png", "weather/64x64/19_rain_hail.png", "weather/64x64/20_thunderstorm_hail.png", "weather/64x64/21_heavy_rainstorm.png", "weather/64x64/22_dust.png", "weather/64x64/23_heavy_sandstorm.png", "weather/64x64/24_rainstorm.png", "weather/64x64/25_unknown.png", "weather/64x64/26_cloudy_night.png", "weather/64x64/27_showers_night.png", "weather/64x64/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 3, alpha: 255 });
          __afEdCur = "text_009"; const normal_w_5_text_009 = __afGrpCreate_normal_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT_FONT, { x: 151, y: 269, w: 80, h: 40, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          __afEd.push({ id: "text_009", n: "Текст", d: "WEATHER_TEMP", h: normal_w_5_text_009, x: 151, y: 269, w: 80, ht: 40, s: 36, c: 0xabd059, ah: "LEFT" });
          __afCreateDayWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 31, hour_posY: 172, hour_path: "strelki_hour_hand.png" });
          __afCreateDayWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 35, minute_posY: 254, minute_path: "strelki_minute_hand.png" });
          // Секундная стрелка: плавный ход не подтверждён официальной документацией
          // (⚠ unverified) — отдельный IMG сохраняет порядок слоя.
          const normal_w_second_smooth_180 = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "strelki_second_hand.png", pos_x: 203, pos_y: -23, center_x: 240, center_y: 240 });
          __afEdCur = null;
          const normal_tap_0_tap_zone_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 200, y: 280, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afGrpFade_normal_("group_8a4e13bad1804a4fa3a18156a7a664f5", !__afGrpOff_normal_["group_8a4e13bad1804a4fa3a18156a7a664f5"], 300); } catch (e) {} } });
          normal_tap_0_tap_zone_001.setAlpha(0);
          const normal_tap_1_tap_zone_002 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 300, y: 370, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_normal_(!__flashOn_normal_); } catch (e) {} } });
          normal_tap_1_tap_zone_002.setAlpha(0);
          const normal_tap_2_tap_zone_003 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 30, y: 310, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afOpenSettings(); } catch (e) {} } });
          normal_tap_2_tap_zone_003.setAlpha(0);
          const normal_tap_3_tap_zone_004 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 303, y: 216, w: 177, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          normal_tap_3_tap_zone_004.setAlpha(0);
          let __flashOn_normal_ = false;
          const __flash_normal_ = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0xffffff });
          const __flashBtn_normal_ = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_normal_(false); } catch (e) {} } });
          __flashBtn_normal_.setAlpha(0);
          let __flashSaved_normal_ = null;
          function __flashBr_normal_(on) {
            try {
              if (on) {
                if (__flashSaved_normal_) return;
                __flashSaved_normal_ = { auto: !!getAutoBrightness(), level: getBrightness() };
                setAutoBrightness({ autoBright: false });
                setBrightness({ brightness: 100 });
              } else if (__flashSaved_normal_) {
                const s = __flashSaved_normal_;
                __flashSaved_normal_ = null;
                if (typeof s.level === 'number') setBrightness({ brightness: s.level });
                setAutoBrightness({ autoBright: s.auto });
              }
            } catch (e) {}
          }
          function __flashSet_normal_(on) {
            try {
              __flashOn_normal_ = !!on;
              __afSetProfileVisible(__flash_normal_, __flashOn_normal_);
              __afSetProfileVisible(__flashBtn_normal_, __flashOn_normal_);
            } catch (e) {}
            try { __flashBr_normal_(__flashOn_normal_); } catch (e) {}
          }
          __flashSet_normal_(false);
          self._flashOffs = self._flashOffs || [];
          self._flashOffs.push(() => __flashSet_normal_(false));
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            __afCreateDayWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} try { const fo = self._flashOffs || []; for (let i = 0; i < fo.length; i++) { try { fo[i](); } catch (e) {} } } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_0_text_005.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            normal_w_1_text_006.setProperty(prop.MORE, { text: formatWeekday(now, "EEE3", "RU") });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_2_text_001.setProperty(prop.MORE, { text: "❤️ " + txt + "" });
            } catch (e) { normal_w_2_text_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_3_text_008.setProperty(prop.MORE, { text: (typeof v === 'number' ? "🔋 " + v + "%" : '--') });
            } catch (e) { normal_w_3_text_008.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
          self._smoothTimerNormal = setInterval(() => {
            try {
              const now = _time ? new Date(_time.getTime()) : new Date();
              let deg = (now.getSeconds() + now.getMilliseconds() / 1000) * 6;
              normal_w_second_smooth_180.setProperty(prop.MORE, { angle: deg });
            } catch (e) {
              if (self._smoothTimerNormal) { clearInterval(self._smoothTimerNormal); self._smoothTimerNormal = null; }
            }
          }, 50);
      
    }

    // Night profile widgets — isolated lexical scope
    {
          const __afGrpAl_night_ = new Map(); const __afGrpP_night_ = { "group_8a4e13bad1804a4fa3a18156a7a664f5": 0 }; const __afGrpTm_night_ = {};
          function __afGrpApply_night_(g) { const l = __afGrpW_night_[g] || []; const p = __afGrpP_night_[g]; for (let i = 0; i < l.length; i++) { const a = __afGrpAl_night_.has(l[i]) ? __afGrpAl_night_.get(l[i]) : 255; try { l[i].setAlpha(Math.round(a * p)); } catch (e) {} } }
          function __afGrpSA_night_(g, w, a) { __afGrpAl_night_.set(w, a); const p = __afGrpP_night_[g]; try { w.setAlpha(p === undefined || p >= 1 ? a : Math.round(a * p)); } catch (e) {} }
          function __afGrpFade_night_(g, off, ms) { const l = __afGrpW_night_[g] || []; if (__afGrpTm_night_[g]) { clearInterval(__afGrpTm_night_[g]); __afGrpTm_night_[g] = null; } __afGrpOff_night_[g] = !!off; if (__afGrpP_night_[g] === undefined) __afGrpP_night_[g] = off ? 1 : 0; if (!off) { __afGrpApply_night_(g); for (let i = 0; i < l.length; i++) { const d = __afGrpDes_night_.has(l[i]) ? __afGrpDes_night_.get(l[i]) : true; try { __afSetProfileVisible(l[i], d); } catch (e) {} } } const N = 10; __afGrpTm_night_[g] = setInterval(function () { let p = __afGrpP_night_[g] + (off ? -1 : 1) / N; if (p < 0) p = 0; if (p > 1) p = 1; __afGrpP_night_[g] = p; __afGrpApply_night_(g); if (p === (off ? 0 : 1)) { clearInterval(__afGrpTm_night_[g]); __afGrpTm_night_[g] = null; if (off) { for (let i = 0; i < l.length; i++) { try { __afSetProfileVisible(l[i], false); } catch (e) {} } } } }, Math.max(16, Math.round(ms / N))); }
          const __afGrpW_night_ = {}; const __afGrpDes_night_ = new Map(); const __afGrpOff_night_ = { "group_8a4e13bad1804a4fa3a18156a7a664f5": true };
          function __afGrpCreate_night_(g, id, o) { const w = __afCreateNightWidget(id, o); (__afGrpW_night_[g] = __afGrpW_night_[g] || []).push(w); if (o && typeof o.alpha === 'number') __afGrpAl_night_.set(w, o.alpha); if (__afGrpP_night_[g] === 0) { try { w.setAlpha(0); } catch (e) {} } if (__afGrpOff_night_[g]) { try { __afSetProfileVisible(w, false); } catch (e) {} } try { if (typeof __afEdReg === 'function') __afEdReg(w, id, o, function (v) { __afGrpVis_night_(g, w, v); }); } catch (e) {} return w; }
          function __afGrpVis_night_(g, w, v) { __afGrpDes_night_.set(w, !!v); try { __afSetProfileVisible(w, !!v && !__afGrpOff_night_[g]); } catch (e) {} }
          function __afGrpSet_night_(g, off) { if (__afGrpTm_night_[g]) { clearInterval(__afGrpTm_night_[g]); __afGrpTm_night_[g] = null; } if (__afGrpP_night_[g] !== undefined) { __afGrpP_night_[g] = off ? 0 : 1; if (!off) __afGrpApply_night_(g); } __afGrpOff_night_[g] = !!off; const l = __afGrpW_night_[g] || []; for (let i = 0; i < l.length; i++) { const d = __afGrpDes_night_.has(l[i]) ? __afGrpDes_night_.get(l[i]) : true; try { __afSetProfileVisible(l[i], d && !off); } catch (e) {} } }
          const __bgColor_night_ = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_night_.setAlpha(255);
          const __bgImage_night_ = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "photo_2026_11_16_22_02_00_bg_kopiya_2.png" });
          __bgImage_night_.setAlpha(255);
          __afEdCur = "night:text_005"; const night_w_0_text_005 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 411, y: 218, w: 60, h: 50, text_size: 36, color: 0xf6e493, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          try { night_w_0_text_005.setAlpha(128); } catch (e) {}
          __afEd.push({ id: "night:text_005", n: "Текст", d: "DAY", h: night_w_0_text_005, x: 411, y: 218, w: 60, ht: 50, s: 36, c: 0xf6e493, ah: "CENTER_H" });
          __afEdCur = "night:text_006"; const night_w_1_text_006 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 308, y: 219, w: 94, h: 50, text_size: 36, color: 0xf6e493, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          try { night_w_1_text_006.setAlpha(128); } catch (e) {}
          __afEd.push({ id: "night:text_006", n: "Текст", d: "WEEKDAY", h: night_w_1_text_006, x: 308, y: 219, w: 94, ht: 50, s: 36, c: 0xf6e493, ah: "CENTER_H" });
          __afEdCur = "night:text_001"; const night_w_2_text_001 = __afGrpCreate_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT, { x: 90, y: 170, w: 136, h: 50, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          try { __afGrpSA_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", night_w_2_text_001, 128); } catch (e) {}
          __afEd.push({ id: "night:text_001", n: "Текст", d: "HEART", h: night_w_2_text_001, x: 90, y: 170, w: 136, ht: 50, s: 36, c: 0xabd059, ah: "LEFT" });
          const night_w_3_text_008_w = __afGrpCreate_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT, { x: 98, y: 215, w: 153, h: 50, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const night_w_3_text_008_a = __taCreate(night_w_3_text_008_w, { fx: "count", dur: 1200, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "restart", open: true, wake: false, change: false, track: "changed", trackSec: false, charMode: false, from: 0, to: 1000, fixed: false, dec: -1, upd: "continue" }, { x: 98, y: 215, color: 0xabd059, fin: 0xabd059, size: 36 });
          const night_w_3_text_008 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(night_w_3_text_008_a, o.text); } else { night_w_3_text_008_w.setProperty(k, o); } } };
          __afEdCur = "night:weather_icon_001"; __afEd.push({ id: "night:weather_icon_001", n: "Значок погод", d: "Значок погоды", g: 1, x: 84, y: 253, w: 64, ht: 64 }); const night_w_4_weather_icon_001 = __afGrpCreate_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.IMG_LEVEL, { x: 84, y: 253, w: 64, h: 64, image_array: ["weather/64x64/0_cloudy.png", "weather/64x64/1_showers.png", "weather/64x64/2_snow_showers.png", "weather/64x64/3_sunny.png", "weather/64x64/4_overcast.png", "weather/64x64/5_light_rain.png", "weather/64x64/6_light_snow.png", "weather/64x64/7_moderate_rain.png", "weather/64x64/8_moderate_snow.png", "weather/64x64/9_heavy_snow.png", "weather/64x64/10_heavy_rain.png", "weather/64x64/11_sandstorm.png", "weather/64x64/12_rain_snow.png", "weather/64x64/13_fog.png", "weather/64x64/14_hazy.png", "weather/64x64/15_thunderstorm.png", "weather/64x64/16_snowstorm.png", "weather/64x64/17_floating_dust.png", "weather/64x64/18_very_heavy_rainstorm.png", "weather/64x64/19_rain_hail.png", "weather/64x64/20_thunderstorm_hail.png", "weather/64x64/21_heavy_rainstorm.png", "weather/64x64/22_dust.png", "weather/64x64/23_heavy_sandstorm.png", "weather/64x64/24_rainstorm.png", "weather/64x64/25_unknown.png", "weather/64x64/26_cloudy_night.png", "weather/64x64/27_showers_night.png", "weather/64x64/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 3, alpha: 128 });
          __afEdCur = "night:text_009"; const night_w_5_text_009 = __afGrpCreate_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT_FONT, { x: 144, y: 269, w: 80, h: 40, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          try { __afGrpSA_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", night_w_5_text_009, 128); } catch (e) {}
          __afEd.push({ id: "night:text_009", n: "Текст", d: "WEATHER_TEMP", h: night_w_5_text_009, x: 144, y: 269, w: 80, ht: 40, s: 36, c: 0xabd059, ah: "LEFT" });
          __afCreateNightWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 31, hour_posY: 172, hour_path: "strelki_hour_hand_a50.png" });
          __afCreateNightWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 35, minute_posY: 254, minute_path: "strelki_minute_hand_a50.png" });
          // Секундная стрелка: плавный ход не подтверждён официальной документацией
          // (⚠ unverified) — отдельный IMG сохраняет порядок слоя.
          const night_w_second_smooth_180 = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "strelki_second_hand.png", pos_x: 203, pos_y: -23, center_x: 240, center_y: 240 });
          night_w_second_smooth_180.setAlpha(128);
          __afEdCur = null;
          const night_tap_0_tap_zone_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 200, y: 280, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afGrpFade_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", !__afGrpOff_night_["group_8a4e13bad1804a4fa3a18156a7a664f5"], 300); } catch (e) {} } });
          night_tap_0_tap_zone_001.setAlpha(0);
          const night_tap_1_tap_zone_002 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 300, y: 370, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_night_(!__flashOn_night_); } catch (e) {} } });
          night_tap_1_tap_zone_002.setAlpha(0);
          const night_tap_2_tap_zone_003 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 30, y: 310, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afOpenSettings(); } catch (e) {} } });
          night_tap_2_tap_zone_003.setAlpha(0);
          const night_tap_3_tap_zone_004 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 303, y: 216, w: 177, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          night_tap_3_tap_zone_004.setAlpha(0);
          let __flashOn_night_ = false;
          const __flash_night_ = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0xffffff });
          const __flashBtn_night_ = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_night_(false); } catch (e) {} } });
          __flashBtn_night_.setAlpha(0);
          let __flashSaved_night_ = null;
          function __flashBr_night_(on) {
            try {
              if (on) {
                if (__flashSaved_night_) return;
                __flashSaved_night_ = { auto: !!getAutoBrightness(), level: getBrightness() };
                setAutoBrightness({ autoBright: false });
                setBrightness({ brightness: 100 });
              } else if (__flashSaved_night_) {
                const s = __flashSaved_night_;
                __flashSaved_night_ = null;
                if (typeof s.level === 'number') setBrightness({ brightness: s.level });
                setAutoBrightness({ autoBright: s.auto });
              }
            } catch (e) {}
          }
          function __flashSet_night_(on) {
            try {
              __flashOn_night_ = !!on;
              __afSetProfileVisible(__flash_night_, __flashOn_night_);
              __afSetProfileVisible(__flashBtn_night_, __flashOn_night_);
            } catch (e) {}
            try { __flashBr_night_(__flashOn_night_); } catch (e) {}
          }
          __flashSet_night_(false);
          self._flashOffs = self._flashOffs || [];
          self._flashOffs.push(() => __flashSet_night_(false));
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            __afCreateNightWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} try { const fo = self._flashOffs || []; for (let i = 0; i < fo.length; i++) { try { fo[i](); } catch (e) {} } } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNight() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            night_w_0_text_005.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            night_w_1_text_006.setProperty(prop.MORE, { text: formatWeekday(now, "EEE3", "RU") });
          }
          _tickNight();
          self._timeTimerNight = setInterval(_tickNight, 1000);
      
          function _tickSensorsNight() {
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              night_w_2_text_001.setProperty(prop.MORE, { text: "❤️ " + txt + "" });
            } catch (e) { night_w_2_text_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              night_w_3_text_008.setProperty(prop.MORE, { text: (typeof v === 'number' ? "🔋 " + v + "%" : '--') });
            } catch (e) { night_w_3_text_008.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNight();
          self._sensorTimerNight = setInterval(_tickSensorsNight, 5000);
      
          self._smoothTimerNight = setInterval(() => {
            try {
              const now = _time ? new Date(_time.getTime()) : new Date();
              let deg = (now.getSeconds() + now.getMilliseconds() / 1000) * 6;
              night_w_second_smooth_180.setProperty(prop.MORE, { angle: deg });
            } catch (e) {
              if (self._smoothTimerNight) { clearInterval(self._smoothTimerNight); self._smoothTimerNight = null; }
            }
          }, 50);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 118, y: 120, w: 244, h: 100, text_size: 84, color: 0xc6ea74, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          // Плавающий текст AOD: шаг 6px, обновление раз в 1 с, настройки из панели на часах (⚠ unverified, см. docs/AOD_FLOAT.md)
          let aod_w_0_text_001_fl_x = 118, aod_w_0_text_001_fl_y = 120, aod_w_0_text_001_fl_dx = 1, aod_w_0_text_001_fl_dy = 1;
          function aod_w_0_text_001_fl_in(px, py) { const r = 240 - __afFloatCur.mg; const xs = [px, px + 244], ys = [py, py + 100]; for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { const dx = xs[i] - 240, dy = ys[j] - 240; if (dx * dx + dy * dy > r * r) return false; } return true; }
          function aod_w_0_text_001_fl_step() {
            try {
              const sx = __afFloatCur.st, sy = Math.max(1, Math.round(__afFloatCur.st * 0.6));
              if (!aod_w_0_text_001_fl_in(aod_w_0_text_001_fl_x, aod_w_0_text_001_fl_y)) {
                // Старт вне допустимой области: возвращаем текст к центру экрана.
                aod_w_0_text_001_fl_x += (240 - (aod_w_0_text_001_fl_x + 244 / 2)) > 0 ? sx : -sx;
                aod_w_0_text_001_fl_y += (240 - (aod_w_0_text_001_fl_y + 100 / 2)) > 0 ? sy : -sy;
              } else {
                let nx = aod_w_0_text_001_fl_x + aod_w_0_text_001_fl_dx * sx;
                if (!aod_w_0_text_001_fl_in(nx, aod_w_0_text_001_fl_y)) { aod_w_0_text_001_fl_dx = -aod_w_0_text_001_fl_dx; nx = aod_w_0_text_001_fl_x + aod_w_0_text_001_fl_dx * sx; if (!aod_w_0_text_001_fl_in(nx, aod_w_0_text_001_fl_y)) nx = aod_w_0_text_001_fl_x; }
                let ny = aod_w_0_text_001_fl_y + aod_w_0_text_001_fl_dy * sy;
                if (!aod_w_0_text_001_fl_in(nx, ny)) { aod_w_0_text_001_fl_dy = -aod_w_0_text_001_fl_dy; ny = aod_w_0_text_001_fl_y + aod_w_0_text_001_fl_dy * sy; if (!aod_w_0_text_001_fl_in(nx, ny)) ny = aod_w_0_text_001_fl_y; }
                aod_w_0_text_001_fl_x = nx; aod_w_0_text_001_fl_y = ny;
              }
              aod_w_0_text_001.setProperty(prop.MORE, { x: Math.round(aod_w_0_text_001_fl_x), y: Math.round(aod_w_0_text_001_fl_y) });
            } catch (e) {}
          }
          function aod_w_0_text_001_fl_reset() { aod_w_0_text_001_fl_x = 118; aod_w_0_text_001_fl_y = 120; aod_w_0_text_001_fl_dx = 1; aod_w_0_text_001_fl_dy = 1; try { aod_w_0_text_001.setProperty(prop.MORE, { x: 118, y: 120 }); } catch (e) {} }
          __afFloatRegister(aod_w_0_text_001_fl_step, aod_w_0_text_001_fl_reset);
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_text_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
// Параметры расписания живут только в памяти текущего запуска циферблата.
    const __afPanelW = 480;
    const __afPanelH = 480;
    const __afProfilePrefs = { profileMode: "auto", profileStart: 22, profileEnd: 7 };

    const __afPanelScale = Math.min(__afPanelW, __afPanelH) / 480;
    const __afPanelPad = Math.max(6, Math.round(10 * __afPanelScale));
    const __afPanelSafePad = Math.max(6, Math.round(12 * __afPanelScale));
    // Шапка ниже и выше прежней: у верха круглого экрана по ширине помещается меньше 40 px.
    const __afPanelHeaderH = Math.min(__afPanelH, Math.max(40, Math.round(68 * __afPanelScale)));
    const __afPanelHeaderTop = Math.round(22 * __afPanelScale);
    const __afPanelBottomPad = Math.max(8, Math.round(12 * __afPanelScale));
    const __afPanelRowH = Math.max(16, Math.min(
      Math.max(18, Math.round(44 * __afPanelScale)),
      Math.floor((__afPanelH - __afPanelHeaderH - __afPanelPad - __afPanelBottomPad) / 10)
    ));
    const __afPanelHeight = Math.min(__afPanelH, __afPanelHeaderH + 10 * __afPanelRowH + __afPanelPad + __afPanelBottomPad);
    const __afPanelTop = __afPanelH - __afPanelHeight;
    const __afPanelRowY = __afPanelTop + __afPanelHeaderH + __afPanelPad;
    const __afPanelFont = Math.max(12, Math.min(Math.round(20 * __afPanelScale), Math.round((__afPanelRowH - 2) * 0.62)));
    const __afPanelStepW = Math.max(24, Math.round(46 * __afPanelScale));
    let __afPanelVisible = false;
    let __afPanelPage = 0;
    function __afPanelCircleInset(y) {
      const halfW = __afPanelW / 2;
      const halfH = __afPanelH / 2;
      const normalized = Math.max(-1, Math.min(1, (y - halfH) / Math.max(1, halfH)));
      return halfW * (1 - Math.sqrt(Math.max(0, 1 - normalized * normalized)));
    }
    function __afPanelRowBox(y, height) {
      const inset = Math.max(__afPanelCircleInset(y), __afPanelCircleInset(y + height));
      const x = Math.ceil(inset + __afPanelSafePad);
      const right = Math.floor(__afPanelW - inset - __afPanelSafePad);
      return { x: x, w: Math.max(1, right - x) };
    }
    function __afPanelSetVisible(w, visible) { w.setProperty(prop.VISIBLE, !!visible); }
    function __afPanelSetText(w, text, x, y, width, height) {
      w.setProperty(prop.MORE, { x: x, y: y, w: width, h: height, text: text });
    }
    function __afPanelSetRowText(w, text, y, height) {
      const box = __afPanelRowBox(y, height);
      __afPanelSetText(w, text, box.x, y, box.w, height);
    }
    function __afPanelButton(x, y, width, height, text, click) {
      const w = createWidget(widget.BUTTON, {
        show_level: show_level.ONLY_NORMAL,
        x: x, y: y, w: width, h: height, text: text,
        color: 0xffffff, text_size: __afPanelFont,
        normal_color: 0x253140, press_color: 0x3a4b60,
        radius: Math.max(4, Math.round(8 * __afPanelScale)),
        click_func: click,
      });
      __afPanelSetVisible(w, false);
      return w;
    }
    function __afPanelHour(value) { return (value < 10 ? '0' : '') + value + ':00'; }
    function __afPanelLargeRowHeight(y) { return Math.min(__afPanelRowH + 10, Math.max(1, __afPanelH - y)); }
    function __afPanelTimeRow(label, key, row, items, large) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = large ? __afPanelLargeRowHeight(y) : __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const desiredStepW = large ? Math.max(54, Math.round(72 * __afPanelScale)) : __afPanelStepW;
      const stepW = Math.min(desiredStepW, Math.max(20, Math.floor((box.w - 8) / 3)));
      const midW = Math.max(1, box.w - 2 * stepW - 4);
      const minus = __afPanelButton(box.x, y, stepW, h, '−', function () {
        __afProfilePrefs[key] = (__afProfilePrefs[key] + 23) % 24;
        __afProfileRefresh(); __afPanelRefresh();
      });
      const value = __afPanelButton(box.x + stepW + 2, y, midW, h, label, function () {});
      const plus = __afPanelButton(box.x + box.w - stepW, y, stepW, h, '+', function () {
        __afProfilePrefs[key] = (__afProfilePrefs[key] + 1) % 24;
        __afProfileRefresh(); __afPanelRefresh();
      });
      items.push(minus, value, plus);
      return { value: value, x: box.x + stepW + 2, y: y, w: midW, h: h };
    }
    function __afPanelRowButton(y, text, click, height) {
      const h = Math.min(height || __afPanelRowH - 2, Math.max(1, __afPanelH - y));
      const box = __afPanelRowBox(y, h);
      return __afPanelButton(box.x, y, box.w, h, text, click);
    }

    // The transparent screen-sized button makes the lower sheet modal while it is open.
    const __afPanelScrim = createWidget(widget.BUTTON, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: 0, w: __afPanelW, h: __afPanelH, text: '',
      normal_src: '', press_src: '', click_func: function () {},
    });
    __afPanelScrim.setAlpha(0);
    __afPanelSetVisible(__afPanelScrim, false);
    const __afPanelBg = createWidget(widget.FILL_RECT, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: __afPanelTop, w: __afPanelW, h: __afPanelHeight, color: 0x111923,
    });
    __afPanelSetVisible(__afPanelBg, false);
    const __afPanelHeaderY = __afPanelTop + __afPanelHeaderTop;
    const __afPanelHeaderInnerH = Math.max(20, __afPanelHeaderH - __afPanelHeaderTop - 2);
    const __afPanelHeaderBox = __afPanelRowBox(__afPanelHeaderY, __afPanelHeaderInnerH);
    // Слева небольшая шестерёнка (просто значок), справа крупная кнопка «Закрыть» с зазором от неё.
    const __afPanelHeaderGap = Math.max(8, Math.round(14 * __afPanelScale));
    const __afPanelGearW = Math.max(24, Math.min(Math.round(40 * __afPanelScale), Math.floor(__afPanelHeaderBox.w / 4)));
    const __afPanelCloseSize = Math.max(30, __afPanelHeaderBox.w - __afPanelGearW - __afPanelHeaderGap);
    const __afPanelTitle = __afPanelButton(__afPanelHeaderBox.x, __afPanelHeaderY, __afPanelGearW, __afPanelHeaderInnerH, '⚙', function () {});
    const __afPanelClose = __afPanelButton(__afPanelHeaderBox.x + __afPanelHeaderBox.w - __afPanelCloseSize, __afPanelHeaderY, __afPanelCloseSize, __afPanelHeaderInnerH, '×  Закрыть', function () {
      __afPanelVisible = false; __afPanelRefresh();
    });
    
    const __afProfileMenu = __afPanelRowButton(__afPanelRowY, 'День и ночь  ›', function () {
      __afPanelPage = 1; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY));
    const __afProfileDetails = [];
    const __afProfileMode = __afPanelRowButton(__afPanelRowY, '', function () {
      const modes = ['auto', 'day', 'night'];
      const i = modes.indexOf(__afProfilePrefs.profileMode);
      __afProfilePrefs.profileMode = modes[(i + 1 + modes.length) % modes.length];
      __afProfileRefresh(); __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY));
    __afProfileDetails.push(__afProfileMode);
    const __afProfileStart = __afPanelTimeRow('Ночной профиль с 22:00', 'profileStart', 2, __afProfileDetails, true);
    const __afProfileEnd = __afPanelTimeRow('Дневной профиль с 07:00', 'profileEnd', 4, __afProfileDetails, true);
    const __afProfileBack = __afPanelRowButton(__afPanelRowY + 9 * __afPanelRowH, '‹ Назад', function () {
      __afPanelPage = 0; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY + 9 * __afPanelRowH));
    __afProfileDetails.push(__afProfileBack);
    function __afPanelRefresh() {
      __afPanelSetVisible(__afPanelScrim, __afPanelVisible);
      __afPanelSetVisible(__afPanelBg, __afPanelVisible);
      __afPanelSetVisible(__afPanelTitle, __afPanelVisible);
      __afPanelSetVisible(__afPanelClose, __afPanelVisible);
      
      __afPanelSetVisible(__afProfileMenu, __afPanelVisible && __afPanelPage === 0);
      __afProfileDetails.forEach(function (w) { __afPanelSetVisible(w, __afPanelVisible && __afPanelPage === 1); });
      __afPanelSetText(__afPanelTitle, '⚙', __afPanelHeaderBox.x, __afPanelHeaderY, __afPanelGearW, __afPanelHeaderInnerH);
      
      __afPanelSetRowText(__afProfileMenu, 'День и ночь  ›', __afPanelRowY, __afPanelLargeRowHeight(__afPanelRowY));
      const profileNames = { auto: 'АВТО', day: 'ДЕНЬ', night: 'НОЧЬ' };
      __afPanelSetRowText(__afProfileMode, 'Режим циферблата: ' + (profileNames[__afProfilePrefs.profileMode] || 'АВТО'), __afPanelRowY, __afPanelLargeRowHeight(__afPanelRowY));
      __afPanelSetText(__afProfileStart.value, 'Ночной профиль с ' + __afPanelHour(__afProfilePrefs.profileStart), __afProfileStart.x, __afProfileStart.y, __afProfileStart.w, __afProfileStart.h);
      __afPanelSetText(__afProfileEnd.value, 'Дневной профиль с ' + __afPanelHour(__afProfilePrefs.profileEnd), __afProfileEnd.x, __afProfileEnd.y, __afProfileEnd.w, __afProfileEnd.h);
      __afPanelSetRowText(__afProfileBack, '‹ Назад', __afPanelRowY + 9 * __afPanelRowH, __afPanelLargeRowHeight(__afPanelRowY + 9 * __afPanelRowH));
      try { __afEdRefresh(); } catch (e) {}
      try { __afFlRefresh(); } catch (e) {}
    }
    function __afOpenSettings() {
      __afPanelVisible = true; __afPanelPage = 0; __afPanelRefresh();
    }
    // ---- Правка компонентов на часах: список -> экран правки выбранного компонента ----
    // Правки применяются сразу (предпросмотр), в файл пишутся только по кнопке «ОК».
    const __afEdPath = "amazface_edits_5356320_1794848505029.json";
    const __afEdSt = {};
    let __afEdSaved = {};
    let __afEdFiles = 1;
    let __afEdDirty = false;
    let __afEdSel = 0;
    let __afEdProfile = '';
    let __afEdPrev = false;
    let __afEdStep = 5;
    let __afEdListPage = 0;
    const __afEdPerPage = 6;
    const __afEdColors = [0xff3b30, 0xffcc00, 0x34c759, 0x0a84ff, 0xbf5af2, 0x000000, 0xffffff, 0x909090];
    const __afEdById = {};
    for (let i = 0; i < __afEd.length; i++) __afEdById[__afEd[i].id] = __afEd[i];
    function __afEdZero() { return { x: 0, y: 0, s: 0, a: -1, c: -1, h: 0 }; }
    function __afEdIsZero(v) { return !v || (!v.x && !v.y && !v.s && v.a < 0 && v.c < 0 && !v.h); }
    function __afEdCopy(v) { return { x: v.x, y: v.y, s: v.s, a: v.a, c: v.c, h: v.h }; }
    function __afEdClone(map) { const r = {}; for (const id in map) r[id] = __afEdCopy(map[id]); return r; }
    // Формат файла: { id: {x,y,s,a,c,h} } — короткие ключи, нули не пишутся.
    // Старый формат «Редактора текста» [dx, dy, dsize, color] читается и переводится в новый.
    function __afEdFromRaw(v) {
      const r = __afEdZero();
      if (Array.isArray(v)) {
        if (v.length !== 4) return null;
        r.x = Math.round(Number(v[0])) || 0; r.y = Math.round(Number(v[1])) || 0; r.s = Math.round(Number(v[2])) || 0;
        r.c = Number(v[3]) >= 0 ? Number(v[3]) : -1;
        return r;
      }
      if (v && typeof v === 'object') {
        r.x = Math.round(Number(v.x)) || 0; r.y = Math.round(Number(v.y)) || 0; r.s = Math.round(Number(v.s)) || 0;
        r.a = Number(v.a) >= 0 ? Math.min(100, Math.round(Number(v.a))) : -1;
        r.c = Number(v.c) >= 0 ? Number(v.c) : -1;
        r.h = v.h ? 1 : 0;
        return r;
      }
      return null;
    }
    function __afEdToRaw(v) {
      const o = {};
      if (v.x) o.x = v.x;
      if (v.y) o.y = v.y;
      if (v.s) o.s = v.s;
      if (v.a >= 0) o.a = v.a;
      if (v.c >= 0) o.c = v.c;
      if (v.h) o.h = 1;
      return o;
    }
    function __afEdCurrentItems() {
      const night = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night';
      return __afEd.filter(function (it) {
        if ((String(it.id).indexOf('night:') === 0) !== night) return false;
        return !it.g || (__afEdParts[it.id] || []).length > 0;
      });
    }
    // ---- Что реально можно менять у компонента (по виджетам, из которых он собран) ----
    function __afEdIsRect(t) { return t === widget.FILL_RECT || t === widget.STROKE_RECT; }
    function __afEdIsColorable(t) { return t === widget.TEXT || __afEdIsRect(t) || t === widget.ARC || t === widget.CIRCLE || t === widget.STROKE_CIRCLE; }
    function __afEdCaps(it) {
      if (it.cp) return it.cp;
      const parts = __afEdParts[it.id] || [];
      if (!it.g) return (it.cp = { pos: true, size: 1, alpha: parts.length > 0, color: true, vis: parts.length > 0 });
      let geo = 0, scalable = true, colored = 0, sameColor = true, col0 = -1;
      for (let i = 0; i < parts.length; i++) {
        const o = parts[i].o || {};
        const hasXY = typeof o.x === 'number' && typeof o.y === 'number';
        const hasC = typeof o.center_x === 'number' && typeof o.center_y === 'number';
        parts[i].geo = hasXY || hasC;
        if (parts[i].geo) {
          geo++;
          if (!(__afEdIsRect(parts[i].t) && hasXY && typeof o.w === 'number' && typeof o.h === 'number')) scalable = false;
        }
        parts[i].col = __afEdIsColorable(parts[i].t) && typeof o.color === 'number';
        if (parts[i].col) { if (colored === 0) col0 = o.color; else if (o.color !== col0) sameColor = false; colored++; }
      }
      return (it.cp = { pos: geo > 0, size: geo > 0 && scalable ? 2 : 0, alpha: parts.length > 0, color: colored > 0 && sameColor, vis: parts.length > 0 });
    }
    function __afEdSetWVis(w, v) {
      try {
        if (typeof __afSetProfileVisible === 'function') __afSetProfileVisible(w, v);
        else w.setProperty(prop.VISIBLE, v);
      } catch (e) {}
    }
    function __afEdGeom(it) {
      const st = __afEdSt[it.id] || __afEdZero();
      if (it.g) {
        const f = __afEdCaps(it).size === 2 ? (100 + st.s) / 100 : 1;
        return { x: it.x + st.x, y: it.y + st.y, w: Math.max(1, Math.round(it.w * f)), h: Math.max(1, Math.round(it.ht * f)), s: 0, c: -1 };
      }
      const ns = Math.max(8, Math.min(200, Math.round(it.s + st.s)));
      const nw = Math.max(1, Math.round(it.w * ns / it.s));
      const nh = Math.max(1, Math.round(it.ht * ns / it.s));
      let nx = it.x + st.x;
      if (it.ah === 'RIGHT') nx -= (nw - it.w);
      else if (it.ah !== 'LEFT') nx -= Math.floor((nw - it.w) / 2);
      const ny = it.y + st.y - Math.floor((nh - it.ht) / 2);
      return { x: nx, y: ny, w: nw, h: nh, s: ns, c: st.c >= 0 ? st.c : it.c };
    }
    function __afEdApply(it) {
      const st = __afEdSt[it.id] || __afEdZero();
      const cp = __afEdCaps(it);
      const parts = __afEdParts[it.id] || [];
      const taps = __afEdTaps[it.id] || [];
      const moved = !!(st.x || st.y || st.s);
      if (!it.g) {
        const g = __afEdGeom(it);
        try { it.h.setProperty(prop.MORE, { x: g.x, y: g.y, w: g.w, h: g.h, text_size: g.s, color: g.c }); } catch (e) {}
      } else if (moved || it.gt) {
        const f = cp.size === 2 ? (100 + st.s) / 100 : 1;
        for (let i = 0; i < parts.length; i++) {
          const o = parts[i].o || {};
          const patch = {};
          if (typeof o.x === 'number' && typeof o.y === 'number') {
            patch.x = Math.round(it.x + (o.x - it.x) * f) + st.x;
            patch.y = Math.round(it.y + (o.y - it.y) * f) + st.y;
            if (cp.size === 2 && typeof o.w === 'number' && typeof o.h === 'number') {
              patch.w = Math.max(1, Math.round(o.w * f)); patch.h = Math.max(1, Math.round(o.h * f));
            }
          } else if (typeof o.center_x === 'number' && typeof o.center_y === 'number') {
            patch.center_x = o.center_x + st.x; patch.center_y = o.center_y + st.y;
          } else continue;
          try { parts[i].w.setProperty(prop.MORE, patch); } catch (e) {}
        }
      }
      if (it.g && (st.c >= 0 || it.ct) && cp.color) {
        for (let i = 0; i < parts.length; i++) {
          if (!parts[i].col) continue;
          try { parts[i].w.setProperty(prop.MORE, { color: st.c >= 0 ? st.c : parts[i].o.color }); } catch (e) {}
        }
      }
      it.ct = st.c >= 0;
      if (moved || it.gt) {
        const f2 = cp.size === 2 ? (100 + st.s) / 100 : 1;
        for (let i = 0; i < taps.length; i++) {
          const t = taps[i];
          const patch = { x: Math.round(it.x + (t.x - it.x) * f2) + st.x, y: Math.round(it.y + (t.y - it.y) * f2) + st.y };
          if (f2 !== 1) { patch.w = Math.max(1, Math.round(t.bw * f2)); patch.h = Math.max(1, Math.round(t.bh * f2)); }
          try { t.w.setProperty(prop.MORE, patch); } catch (e) {}
        }
      }
      it.gt = moved;
      if (st.a >= 0 || it.at) {
        for (let i = 0; i < parts.length; i++) {
          parts[i].ov = st.a;
          try { (parts[i].sa || parts[i].w.setAlpha).call(parts[i].w, st.a >= 0 ? Math.round(255 * st.a / 100) : parts[i].a0); } catch (e) {}
        }
        it.at = st.a >= 0;
      }
      if (st.h || it.vt) {
        for (let i = 0; i < parts.length; i++) { __afEdSetVis(parts[i], !st.h); }
        for (let k = 0; k < taps.length; k++) { __afEdSetWVis(taps[k].w, !st.h); }
        it.vt = !!st.h;
      }
    }
    function __afEdReadFile(path) {
      try {
        const result = hmFS.stat(path);
        if (!result || result[1] !== 0 || !result[0] || result[0].size <= 0 || result[0].size > 8192) return null;
        const file = hmFS.open(path, hmFS.O_RDONLY);
        if (typeof file !== 'number' || file < 0) return null;
        try {
          const bytes = new Uint8Array(result[0].size);
          hmFS.read(file, bytes.buffer, 0, bytes.length);
          const data = JSON.parse(String.fromCharCode.apply(null, bytes));
          return data && typeof data === 'object' ? data : null;
        } finally { hmFS.close(file); }
      } catch (e) { return null; }
    }
    function __afEdWriteFile(path, raw) {
      let file = -1;
      try {
        const bytes = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) & 255;
        file = hmFS.open(path, hmFS.O_RDWR | hmFS.O_CREAT | hmFS.O_TRUNC);
        if (typeof file === 'number' && file >= 0) hmFS.write(file, bytes.buffer, 0, bytes.length);
      } catch (e) {
      } finally {
        try { if (file >= 0) hmFS.close(file); } catch (e) {}
      }
    }
    // Лимит чтения файла — 8 КБ: при большом числе правок они делятся на файлы ..._2.json, ..._3.json.
    function __afEdChunkPath(n) { return n === 1 ? __afEdPath : __afEdPath.replace(/\.json$/, '') + '_' + n + '.json'; }
    function __afEdLoad() {
      let n = 1;
      for (; n <= 8; n++) {
        const data = __afEdReadFile(__afEdChunkPath(n));
        if (!data) break;
        for (const id in data) {
          const it = __afEdById[id];
          if (!it) continue;   // компонента с таким id больше нет — запись игнорируется
          const v = __afEdFromRaw(data[id]);
          if (v && !__afEdIsZero(v)) __afEdSt[id] = v;
        }
      }
      __afEdFiles = Math.max(1, n - 1);
    }
    function __afEdPersist(map) {
      const out = {};
      for (const idm in map) { if (__afEdById[idm] && !__afEdIsZero(map[idm])) out[idm] = __afEdToRaw(map[idm]); }
      const chunks = [{}];
      let size = 2;
      let count = 0;
      for (const ido in out) {
        const piece = JSON.stringify(ido).length + JSON.stringify(out[ido]).length + 2;
        if (size + piece > 7000 && count > 0 && chunks.length < 8) { chunks.push({}); size = 2; count = 0; }
        chunks[chunks.length - 1][ido] = out[ido]; size += piece; count++;
      }
      const total = Math.min(8, Math.max(chunks.length, __afEdFiles));
      for (let n = 1; n <= total; n++) __afEdWriteFile(__afEdChunkPath(n), JSON.stringify(chunks[n - 1] || {}));
      __afEdFiles = chunks.length;
    }
    function __afEdSave() {
      __afEdSaved = __afEdClone(__afEdSt);
      __afEdPersist(__afEdSaved);
      __afEdDirty = false;
    }
    // Откат к последнему сохранённому состоянию (кнопка «Отмена», закрытие панели без «ОК»).
    function __afEdRollback() {
      const ids = {};
      for (const ia in __afEdSt) { ids[ia] = 1; }
      for (const ib in __afEdSaved) { ids[ib] = 1; }
      for (const ic in __afEdSt) { delete __afEdSt[ic]; }
      for (const id in __afEdSaved) { __afEdSt[id] = __afEdCopy(__afEdSaved[id]); }
      for (const ie in ids) { if (__afEdById[ie]) __afEdApply(__afEdById[ie]); }
      __afEdDirty = false;
    }
    function __afEdChanged(it) { return !__afEdIsZero(__afEdSt[it.id]); }
    function __afEdTouch(it) { return __afEdSt[it.id] || (__afEdSt[it.id] = __afEdZero()); }
    function __afEdChange(k, d) {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      const cp = __afEdCaps(it);
      if ((k === 'x' || k === 'y') && !cp.pos) return;
      if (k === 's' && !cp.size) return;
      if (k === 'a' && !cp.alpha) return;
      const st = __afEdTouch(it);
      if (k === 'x' || k === 'y') st[k] += d;
      else if (k === 's') {
        st.s += d;
        if (cp.size === 1) { st.s = Math.max(8 - it.s, Math.min(200 - it.s, st.s)); }
        else { st.s = Math.max(-90, Math.min(200, st.s)); }
      } else if (k === 'a') {
        st.a = Math.max(0, Math.min(100, (st.a < 0 ? 100 : st.a) + d));
      }
      __afEdDirty = true; __afEdApply(it); __afPanelRefresh();
    }
    function __afEdSetColor(c) {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it || !__afEdCaps(it).color) return;
      __afEdTouch(it).c = c;
      __afEdDirty = true; __afEdApply(it); __afPanelRefresh();
    }
    function __afEdToggleVis() {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it || !__afEdCaps(it).vis) return;
      const st = __afEdTouch(it);
      st.h = st.h ? 0 : 1;
      __afEdDirty = true; __afEdApply(it); __afPanelRefresh();
    }
    function __afEdResetOne() {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      delete __afEdSt[it.id];
      __afEdDirty = true; __afEdApply(it); __afPanelRefresh();
    }
    // Сброс всех правок текущей сцены: после подтверждения действует сразу и записывается в файл.
    function __afEdResetAll() {
      const items = __afEdCurrentItems();
      for (let i = 0; i < items.length; i++) {
        delete __afEdSt[items[i].id]; delete __afEdSaved[items[i].id];
        __afEdApply(items[i]);
      }
      __afEdPersist(__afEdSaved);
      __afEdDirty = false;
    }
    __afEdLoad();
    __afEdSaved = __afEdClone(__afEdSt);
    (function () { for (let i = 0; i < __afEd.length; i++) { if (__afEdSt[__afEd[i].id]) __afEdApply(__afEd[i]); } })();

    // Страница 3 — список, страница 4 — правка выбранного, страница 6 — подтверждение сброса.
    const __afEdListAll = [];
    const __afEdEditAll = [];
    const __afEdConfAll = [];
    const __afEdStatic = [];
    function __afEdBtn(list, x, y, w, h, text, click) {
      const b = __afPanelButton(x, y, w, h, text, click);
      list.push(b);
      if (text) __afEdStatic.push({ w: b, t: text, x: x, y: y, bw: w, h: h });
      return b;
    }
    function __afEdTitle(list, row, color) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const w = createWidget(widget.TEXT, {
        show_level: show_level.ONLY_NORMAL,
        x: box.x, y: y, w: box.w, h: h, text: '',
        color: color, text_size: __afPanelFont,
        align_h: align.CENTER_H, align_v: align.CENTER_V,
      });
      __afPanelSetVisible(w, false);
      list.push(w);
      return { w: w, x: box.x, y: y, bw: box.w, h: h };
    }
    function __afEdFull(list, row, text, click) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const b = __afEdBtn(list, box.x, y, box.w, h, text, click);
      return { w: b, x: box.x, y: y, bw: box.w, h: h };
    }
    // Общая ширина для нескольких строк: на круглом экране у каждой строки своя, а колонки должны быть ровными.
    function __afEdSharedBox(rows) {
      let left = 0, right = __afPanelW;
      rows.forEach(function (row) {
        const b = __afPanelRowBox(__afPanelRowY + row * __afPanelRowH, __afPanelRowH - 2);
        left = Math.max(left, b.x); right = Math.min(right, b.x + b.w);
      });
      return { x: left, w: Math.max(1, right - left) };
    }
    function __afEdHalves(list, row, textA, clickA, textB, clickB, shared) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const box = shared || __afPanelRowBox(y, h);
      const half = Math.floor((box.w - 4) / 2);
      const a = __afEdBtn(list, box.x, y, half, h, textA, clickA);
      const b = __afEdBtn(list, box.x + box.w - half, y, half, h, textB, clickB);
      return { a: a, b: b, ax: box.x, bx: box.x + box.w - half, y: y, bw: half, h: h };
    }
    function __afEdPages() { return Math.max(1, Math.ceil(__afEdCurrentItems().length / __afEdPerPage)); }
    function __afEdOk(page) {
      __afEdSave(); __afEdPrev = false; __afPanelPage = page; __afPanelRefresh();
    }
    function __afEdCancel(page) {
      __afEdRollback(); __afEdPrev = false; __afPanelPage = page; __afPanelRefresh();
    }

    const __afEdMenu = __afPanelRowButton(__afPanelRowY + 2 * __afPanelRowH, 'Правка компонентов  ›', function () {
      __afEdSel = 0; __afEdListPage = 0; __afEdPrev = false; __afPanelPage = 3; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY + 2 * __afPanelRowH));

    // Список.
    const __afEdListTitle = __afEdTitle(__afEdListAll, 0, 0xffd60a);
    const __afEdItems = [];
    (function () {
      for (let slot = 0; slot < __afEdPerPage; slot++) {
        (function (sl) {
          const y = __afPanelRowY + (1 + sl) * __afPanelRowH;
          const h = __afPanelRowH - 2;
          const box = __afPanelRowBox(y, h);
          const b = __afEdBtn(__afEdListAll, box.x, y, box.w, h, '', function () {
            const idx = __afEdListPage * __afEdPerPage + sl;
            if (idx < __afEdCurrentItems().length) { __afEdSel = idx; __afEdPrev = false; __afPanelPage = 4; __afPanelRefresh(); }
          });
          __afEdItems.push({ w: b, x: box.x, y: y, bw: box.w, h: h });
        })(slot);
      }
    })();
    __afEdHalves(__afEdListAll, 7, '‹ Пред.', function () {
      __afEdListPage = (__afEdListPage + __afEdPages() - 1) % __afEdPages(); __afPanelRefresh();
    }, 'След. ›', function () {
      __afEdListPage = (__afEdListPage + 1) % __afEdPages(); __afPanelRefresh();
    });
    __afEdFull(__afEdListAll, 8, 'Сбросить все правки', function () { __afPanelPage = 6; __afPanelRefresh(); });
    __afEdHalves(__afEdListAll, 9, 'Отмена', function () { __afEdCancel(0); }, 'ОК', function () { __afEdOk(0); });

    // Подтверждение сброса всех правок текущей сцены.
    const __afEdConfTitle = __afEdTitle(__afEdConfAll, 2, 0xffd60a);
    const __afEdConfText = __afEdTitle(__afEdConfAll, 3, 0xffffff);
    __afEdFull(__afEdConfAll, 5, 'Да, удалить', function () { __afEdResetAll(); __afPanelPage = 3; __afPanelRefresh(); });
    __afEdFull(__afEdConfAll, 6, 'Нет', function () { __afPanelPage = 3; __afPanelRefresh(); });

    // Правка выбранного компонента: две колонки крупных кнопок «−» и «+».
    const __afEdEditTitle = __afEdTitle(__afEdEditAll, 0, 0xffd60a);
    const __afEdValues = __afEdTitle(__afEdEditAll, 1, 0xffffff);
    const __afEdSwatches = [];
    (function () {
      const box = __afEdSharedBox([2]);
      const y = __afPanelRowY + 2 * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const gap = 2;
      const cw = Math.max(8, Math.floor((box.w - gap * 7) / 8));
      for (let c = 0; c < 8; c++) {
        (function (color) {
          const sw = createWidget(widget.BUTTON, {
            show_level: show_level.ONLY_NORMAL,
            x: box.x + c * (cw + gap), y: y, w: cw, h: h, text: '',
            normal_color: color, press_color: color,
            radius: Math.max(3, Math.round(6 * __afPanelScale)),
            click_func: function () { __afEdSetColor(color); },
          });
          __afPanelSetVisible(sw, false);
          __afEdEditAll.push(sw);
          __afEdSwatches.push(sw);
        })(__afEdColors[c]);
      }
    })();
    const __afEdCtlBox = __afEdSharedBox([3, 4, 5, 6]);
    const __afEdRowS = __afEdHalves(__afEdEditAll, 3, '−  Размер', function () { __afEdChange('s', -__afEdStep); }, '+  Размер', function () { __afEdChange('s', __afEdStep); }, __afEdCtlBox);
    const __afEdRowX = __afEdHalves(__afEdEditAll, 4, '−  X', function () { __afEdChange('x', -__afEdStep); }, '+  X', function () { __afEdChange('x', __afEdStep); }, __afEdCtlBox);
    const __afEdRowY = __afEdHalves(__afEdEditAll, 5, '−  Y', function () { __afEdChange('y', -__afEdStep); }, '+  Y', function () { __afEdChange('y', __afEdStep); }, __afEdCtlBox);
    const __afEdRowA = __afEdHalves(__afEdEditAll, 6, '−  Прозр.', function () { __afEdChange('a', -__afEdStep); }, '+  Прозр.', function () { __afEdChange('a', __afEdStep); }, __afEdCtlBox);
    const __afEdRow7 = __afEdHalves(__afEdEditAll, 7, '', function () {
      __afEdStep = __afEdStep === 1 ? 5 : (__afEdStep === 5 ? 10 : 1); __afPanelRefresh();
    }, '', function () { __afEdToggleVis(); });
    __afEdHalves(__afEdEditAll, 8, 'Сбросить', function () { __afEdResetOne(); }, 'Просмотр', function () {
      __afEdPrev = true; __afPanelRefresh();
    });
    __afEdHalves(__afEdEditAll, 9, 'Отмена', function () { __afEdCancel(3); }, 'ОК', function () { __afEdOk(3); });
    const __afEdPrevList = [];
    const __afEdBackPrev = __afEdFull(__afEdPrevList, 9, '‹ К правкам', function () {
      __afEdPrev = false; __afPanelRefresh();
    });
    const __afEdFrame = createWidget(widget.STROKE_RECT, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: 0, w: 10, h: 10, line_width: 2, color: 0xffd60a,
    });
    __afPanelSetVisible(__afEdFrame, false);

    function __afEdCut(text, n) {
      text = String(text);
      return text.length > n ? text.slice(0, n - 1) + '.' : text;
    }
    function __afEdRefresh() {
      const vis = __afPanelVisible;
      // Закрыли панель без «ОК» — несохранённые правки откатываются.
      if (!vis && __afEdDirty) __afEdRollback();
      const activeProfile = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night' ? 'night' : 'day';
      if (__afEdProfile && __afEdProfile !== activeProfile && (__afPanelPage === 3 || __afPanelPage === 4 || __afPanelPage === 6)) {
        __afPanelPage = 3; __afEdSel = 0; __afEdListPage = 0; __afEdPrev = false;
      }
      __afEdProfile = activeProfile;
      const onList = vis && __afPanelPage === 3;
      const inEd = vis && __afPanelPage === 4;
      const onEd = inEd && !__afEdPrev;
      const onConf = vis && __afPanelPage === 6;
      const currentItems = __afEdCurrentItems();
      if (__afEdSel >= currentItems.length) __afEdSel = 0;
      const it = currentItems[__afEdSel];
      const cp = it ? __afEdCaps(it) : { pos: false, size: 0, alpha: false, color: false, vis: false };
      __afPanelSetVisible(__afEdMenu, vis && __afPanelPage === 0);
      __afEdListAll.forEach(function (w) { __afPanelSetVisible(w, onList); });
      __afEdConfAll.forEach(function (w) { __afPanelSetVisible(w, onConf); });
      __afEdEditAll.forEach(function (w) { __afPanelSetVisible(w, onEd); });
      // Недоступные для этого компонента свойства в интерфейсе не показываются.
      __afPanelSetVisible(__afEdRowS.a, onEd && !!cp.size); __afPanelSetVisible(__afEdRowS.b, onEd && !!cp.size);
      __afPanelSetVisible(__afEdRowX.a, onEd && cp.pos); __afPanelSetVisible(__afEdRowX.b, onEd && cp.pos);
      __afPanelSetVisible(__afEdRowY.a, onEd && cp.pos); __afPanelSetVisible(__afEdRowY.b, onEd && cp.pos);
      __afPanelSetVisible(__afEdRowA.a, onEd && cp.alpha); __afPanelSetVisible(__afEdRowA.b, onEd && cp.alpha);
      __afPanelSetVisible(__afEdRow7.b, onEd && cp.vis);
      __afEdSwatches.forEach(function (w) { __afPanelSetVisible(w, onEd && cp.color); });
      __afEdPrevList.forEach(function (w) { __afPanelSetVisible(w, inEd && __afEdPrev); });
      // Рамка только в режиме просмотра: поверх панели она перекрывала бы кнопки.
      __afPanelSetVisible(__afEdFrame, inEd && __afEdPrev && !!it);
      if (inEd && __afEdPrev) {
        __afPanelSetVisible(__afPanelBg, false);
        __afPanelSetVisible(__afPanelTitle, false);
        __afPanelSetVisible(__afPanelClose, false);
      }
      __afPanelSetRowText(__afEdMenu, 'Правка компонентов  ›', __afPanelRowY + 2 * __afPanelRowH, __afPanelLargeRowHeight(__afPanelRowY + 2 * __afPanelRowH));
      __afEdStatic.forEach(function (r) { __afPanelSetText(r.w, r.t, r.x, r.y, r.bw, r.h); });
      const sceneName = activeProfile === 'night' ? 'Ночь' : 'День';
      if (onConf) {
        __afPanelSetText(__afEdConfTitle.w, 'Удалить все правки?', __afEdConfTitle.x, __afEdConfTitle.y, __afEdConfTitle.bw, __afEdConfTitle.h);
        __afPanelSetText(__afEdConfText.w, 'Сцена: ' + sceneName, __afEdConfText.x, __afEdConfText.y, __afEdConfText.bw, __afEdConfText.h);
      }
      if (onList) {
        __afPanelSetText(__afEdListTitle.w, (currentItems.length ? 'Компоненты: ' : 'Нет компонентов: ') + sceneName + ' ' + (__afEdListPage + 1) + '/' + __afEdPages(), __afEdListTitle.x, __afEdListTitle.y, __afEdListTitle.bw, __afEdListTitle.h);
        for (let sl = 0; sl < __afEdItems.length; sl++) {
          const idx = __afEdListPage * __afEdPerPage + sl;
          const row = __afEdItems[sl];
          const item = currentItems[idx];
          if (!item) { __afPanelSetVisible(row.w, false); continue; }
          const label = (__afEdChanged(item) ? '* ' : '') + (idx + 1) + '. ' + item.n + (item.d ? ' - ' + item.d : '');
          __afPanelSetText(row.w, __afEdCut(label, 26), row.x, row.y, row.bw, row.h);
        }
      }
      if (inEd && it) {
        const g = __afEdGeom(it);
        try { __afEdFrame.setProperty(prop.MORE, { x: g.x - 2, y: g.y - 2, w: g.w + 4, h: g.h + 4 }); } catch (e) {}
      }
      if (onEd && it) {
        const g = __afEdGeom(it);
        const st = __afEdSt[it.id] || __afEdZero();
        const sceneTag = activeProfile === 'night' ? ' [НОЧЬ]' : ' [ДЕНЬ]';
        let line = '';
        if (cp.size === 1) line = 'Размер ' + g.s + '   ';
        else if (cp.size === 2) line = 'Масштаб ' + (100 + st.s) + '%   ';
        line += 'X ' + (it.x + st.x) + '   Y ' + (it.y + st.y);
        if (st.a >= 0) line += '   П ' + st.a + '%';
        if (st.h) line += '   СКРЫТ';
        __afPanelSetText(__afEdEditTitle.w, __afEdCut(it.n + (it.d ? ' - ' + it.d : '') + sceneTag, 26), __afEdEditTitle.x, __afEdEditTitle.y, __afEdEditTitle.bw, __afEdEditTitle.h);
        __afPanelSetText(__afEdValues.w, line, __afEdValues.x, __afEdValues.y, __afEdValues.bw, __afEdValues.h);
        __afPanelSetText(__afEdRow7.a, 'Шаг: ' + __afEdStep, __afEdRow7.ax, __afEdRow7.y, __afEdRow7.bw, __afEdRow7.h);
        __afPanelSetText(__afEdRow7.b, st.h ? 'Показать' : 'Скрыть', __afEdRow7.bx, __afEdRow7.y, __afEdRow7.bw, __afEdRow7.h);
      }
    }
    // ---- Плавающий AOD: вкл./выкл., частота, шаг, отступ ----
    const __afFlIvList = [1, 5, 10, 30, 60];
    const __afFlStList = [1, 2, 3, 4, 6, 8, 10, 15, 20, 30, 40, 60];
    const __afFlMgList = [0, 6, 12, 20, 30, 40, 60, 90];
    function __afFlMove(list, value, dir) {
      let i = 0;
      for (let k = 0; k < list.length; k++) if (Math.abs(list[k] - value) < Math.abs(list[i] - value)) i = k;
      i = Math.max(0, Math.min(list.length - 1, i + dir));
      return list[i];
    }
    function __afFlIvText(v) { return v === 60 ? 'Частота 1 мин' : 'Частота ' + v + ' с'; }
    function __afPanelValueRow(row, items, onMinus, onPlus) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelLargeRowHeight(y);
      const box = __afPanelRowBox(y, h);
      const stepW = Math.min(Math.max(54, Math.round(72 * __afPanelScale)), Math.max(20, Math.floor((box.w - 8) / 3)));
      const midW = Math.max(1, box.w - 2 * stepW - 4);
      const minus = __afPanelButton(box.x, y, stepW, h, '−', onMinus);
      const value = __afPanelButton(box.x + stepW + 2, y, midW, h, '', function () {});
      const plus = __afPanelButton(box.x + box.w - stepW, y, stepW, h, '+', onPlus);
      items.push(minus, value, plus);
      return { value: value, x: box.x + stepW + 2, y: y, w: midW, h: h };
    }
    const __afFlMenuY = __afPanelRowY + 4 * __afPanelRowH;
    const __afFlMenu = __afPanelRowButton(__afFlMenuY, 'Плавающий AOD  ›', function () {
      __afPanelPage = 5; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afFlMenuY));
    const __afFlDetails = [];
    const __afFlToggle = __afPanelRowButton(__afPanelRowY, '', function () {
      __afFloatCur.on = !__afFloatCur.on; __afFloatApply(); __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY));
    __afFlDetails.push(__afFlToggle);
    const __afFlIv = __afPanelValueRow(2, __afFlDetails,
      function () { __afFloatCur.iv = __afFlMove(__afFlIvList, __afFloatCur.iv, -1); __afFloatApply(); __afPanelRefresh(); },
      function () { __afFloatCur.iv = __afFlMove(__afFlIvList, __afFloatCur.iv, 1); __afFloatApply(); __afPanelRefresh(); });
    const __afFlSt = __afPanelValueRow(4, __afFlDetails,
      function () { __afFloatCur.st = __afFlMove(__afFlStList, __afFloatCur.st, -1); __afFloatApply(); __afPanelRefresh(); },
      function () { __afFloatCur.st = __afFlMove(__afFlStList, __afFloatCur.st, 1); __afFloatApply(); __afPanelRefresh(); });
    const __afFlMg = __afPanelValueRow(6, __afFlDetails,
      function () { __afFloatCur.mg = __afFlMove(__afFlMgList, __afFloatCur.mg, -1); __afFloatApply(); __afPanelRefresh(); },
      function () { __afFloatCur.mg = __afFlMove(__afFlMgList, __afFloatCur.mg, 1); __afFloatApply(); __afPanelRefresh(); });
    const __afFlBackY = __afPanelRowY + 9 * __afPanelRowH;
    const __afFlBack = __afPanelRowButton(__afFlBackY, '‹ Назад', function () {
      __afPanelPage = 0; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afFlBackY));
    __afFlDetails.push(__afFlBack);
    function __afFlRefresh() {
      const vis = __afPanelVisible;
      __afPanelSetVisible(__afFlMenu, vis && __afPanelPage === 0);
      __afFlDetails.forEach(function (w) { __afPanelSetVisible(w, vis && __afPanelPage === 5); });
      __afPanelSetRowText(__afFlMenu, 'Плавающий AOD  ›', __afFlMenuY, __afPanelLargeRowHeight(__afFlMenuY));
      __afPanelSetRowText(__afFlToggle, 'Плавающий AOD: ' + (__afFloatCur.on ? 'ВКЛ' : 'ВЫКЛ'), __afPanelRowY, __afPanelLargeRowHeight(__afPanelRowY));
      __afPanelSetText(__afFlIv.value, __afFlIvText(__afFloatCur.iv), __afFlIv.x, __afFlIv.y, __afFlIv.w, __afFlIv.h);
      __afPanelSetText(__afFlSt.value, 'Шаг ' + __afFloatCur.st + ' px', __afFlSt.x, __afFlSt.y, __afFlSt.w, __afFlSt.h);
      __afPanelSetText(__afFlMg.value, 'Отступ ' + __afFloatCur.mg + ' px', __afFlMg.x, __afFlMg.y, __afFlMg.w, __afFlMg.h);
      __afPanelSetRowText(__afFlBack, __afFloatSaveOk ? '‹ Назад' : '‹ Назад · ошибка записи', __afFlBackY, __afPanelLargeRowHeight(__afFlBackY));
    }
    __afPanelRefresh();
    __afProfileRefresh();
    self._dayNightTimer = setInterval(__afProfileRefresh, 30000);
    try { createWidget(widget.WIDGET_DELEGATE, { resume_call: function () { try { __afProfileRefresh(); } catch (e) {} } }); } catch (e) {}
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._timeTimerNight) { clearInterval(this._timeTimerNight); this._timeTimerNight = null; }
    if (this._sensorTimerNight) { clearInterval(this._sensorTimerNight); this._sensorTimerNight = null; }
    if (this._smoothTimerNight) { clearInterval(this._smoothTimerNight); this._smoothTimerNight = null; }
    if (this._dayNightTimer) { clearInterval(this._dayNightTimer); this._dayNightTimer = null; }
    try { __taDestroy(); } catch (e) {}
    if (this._floatTimers) { for (let i = 0; i < this._floatTimers.length; i++) clearInterval(this._floatTimers[i]); this._floatTimers = null; }
    try { __heartStop(); } catch (e) {}
    try { const fo = this._flashOffs || []; for (let i = 0; i < fo.length; i++) { try { fo[i](); } catch (e) {} } } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
