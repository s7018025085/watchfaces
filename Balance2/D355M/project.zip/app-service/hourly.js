import { Vibrator, VIBRATOR_SCENE_SHORT_LIGHT, VIBRATOR_SCENE_SHORT_MIDDLE, VIBRATOR_SCENE_SHORT_STRONG, VIBRATOR_SCENE_DURATION } from '@zos/sensor'
import { set } from '@zos/alarm'
import { writeFileSync } from '@zos/fs'
import * as notif from '@zos/notification'
import * as sysTimer from '@zos/timer'

function parse(param) {
  const out = {};
  String(param || '').split('&').forEach(function (pair) {
    const i = pair.indexOf('=');
    if (i > 0) {
      const key = pair.slice(0, i);
      const val = pair.slice(i + 1);
      out[key] = key === 'fn' ? val : Number(val);
    }
  });
  return out;
}

function quiet(enabled, start, end, hour) {
  if (!enabled || start === end) return false;
  if (start < end) return hour >= start && hour < end;
  return hour >= start || hour < end;
}

// Отметка запуска для экрана диагностики циферблата (если общая папка данных доступна).
function mark(fn, rec) {
  if (!fn) return;
  try { writeFileSync({ path: fn, data: JSON.stringify(rec), options: { encoding: 'utf8' } }); } catch (e) {}
}

function errText(e) { return String(e && e.message ? e.message : e).slice(0, 30); }

function run(param) {
  const p = parse(param);
  const test = p.t === 1;
  const rec = { t: Date.now(), st: 'start', test: test ? 1 : 0, nid: 0, e: '' };
  mark(p.fn, rec);
  // Час, к которому относится сигнал (будильник мог сработать чуть раньше/позже).
  const target = new Date(Date.now() + 90 * 1000);
  target.setMinutes(0, 0, 0);
  const hour = target.getHours();
  const strength = p.s === 0 || p.s === 2 ? p.s : 1;
  const silent = !test && (quiet(p.nq === 1, p.ns, p.ne, hour) || quiet(p.pq === 1, p.ps, p.pe, hour));
  // Следующий будильник взводим всегда (даже если этот час «тихий»), кроме тестового.
  if (!test) {
    try {
      const next = new Date(target.getTime());
      next.setHours(next.getHours() + 1);
      rec.nid = set({ url: 'app-service/hourly', time: Math.floor(next.getTime() / 1000), param: param, store: true });
    } catch (e) { rec.e = 'next ' + errText(e); }
  }
  if (silent) { rec.st = 'quiet'; mark(p.fn, rec); return; }
  try {
    const vibrator = new Vibrator();
    vibrator.stop();
    vibrator.setMode([VIBRATOR_SCENE_SHORT_LIGHT, VIBRATOR_SCENE_SHORT_MIDDLE, VIBRATOR_SCENE_SHORT_STRONG][strength]);
    vibrator.start();
    rec.st = 'ok';
  } catch (e) { rec.st = 'err'; rec.e = errText(e); }
  mark(p.fn, rec);
  if (test) diagnose(p, rec);
}

// Только тестовый запуск (t=1): проверяем два запасных пути и пишем результат в отметку.
// ntf: системное уведомление из сервиса (доказывает, что сервис запустился, даже если
// вибрация не пошла); tm: системный таймер createSysTimer (API 4.0), который по документации
// работает независимо от состояния экрана, — через 3 с даёт длинную вибрацию.
function diagnose(p, rec) {
  rec.ntf = 'no'; rec.tm = 'no';
  try {
    if (typeof notif !== 'undefined' && notif && typeof notif.notify === 'function') {
      const d = new Date();
      notif.notify({ title: 'AmazFace', content: 'Test service ' + d.getHours() + ':' + (d.getMinutes() < 10 ? '0' : '') + d.getMinutes() });
      rec.ntf = 'ok';
    }
  } catch (e) { rec.ntf = 'err'; rec.e = rec.e || errText(e); }
  try {
    if (typeof sysTimer !== 'undefined' && sysTimer && typeof sysTimer.createSysTimer === 'function') {
      sysTimer.createSysTimer(false, 3000, function () {
        try {
          const v = new Vibrator();
          v.stop();
          v.setMode(VIBRATOR_SCENE_DURATION);
          v.start();
          rec.tm = 'fired';
        } catch (e) { rec.tm = 'err'; rec.e = rec.e || errText(e); }
        mark(p.fn, rec);
      });
      rec.tm = 'set';
    }
  } catch (e) { rec.tm = 'err'; rec.e = rec.e || errText(e); }
  mark(p.fn, rec);
}

AppService({
  onInit(param) {
    try { run(param); } catch (e) {}
  },
  onDestroy() {},
})
