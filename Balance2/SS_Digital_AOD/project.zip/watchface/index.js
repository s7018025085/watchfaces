import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { setBrightness, getBrightness, setAutoBrightness, getAutoBrightness } from '@zos/display'
import { launchApp, SYSTEM_APP_ALTIMETER, SYSTEM_APP_CALENDAR, SYSTEM_APP_STATUS, SYSTEM_APP_WEATHER } from '@zos/router'
import { Time, Battery, Step, Distance, Barometer } from '@zos/sensor'
import { setInterval, clearInterval, setTimeout, clearTimeout } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// ---- Анимация текста (AmazFace): общий рантайм --------------------------------
var __TA = { list: [], all: [], timer: 0, paused: false };
var __taFx = {};
function __taClamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function __taEase(name, t) {
  t = __taClamp(t, 0, 1);
  if (name === 'in') return t * t * t;
  if (name === 'out') { var u = 1 - t; return 1 - u * u * u; }
  if (name === 'inout') return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  return t;
}
function __taMix(c1, c2, t) {
  var r = Math.round(((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
  var g = Math.round(((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
  var b = Math.round((c1 & 255) * (1 - t) + (c2 & 255) * t);
  return (r << 16) | (g << 8) | b;
}
function __taChars(s) {
  var out = [], i = 0, n, c;
  s = String(s == null ? '' : s);
  n = s.length;
  while (i < n) {
    c = s.charCodeAt(i);
    if (c >= 0xD800 && c <= 0xDBFF && i + 1 < n) { out.push(s.substr(i, 2)); i += 2; }
    else { out.push(s.charAt(i)); i += 1; }
  }
  return out;
}
function __taParseNum(s) {
  var m = /-?\d[\d,]*(?:\.\d+)?/.exec(String(s == null ? '' : s));
  if (!m) return null;
  var tok = m[0], clean = tok.replace(/,/g, ''), dot = clean.indexOf('.');
  return { pre: String(s).slice(0, m.index), post: String(s).slice(m.index + tok.length), val: parseFloat(clean), dec: dot >= 0 ? clean.length - dot - 1 : 0, sep: tok.indexOf(',') >= 0 };
}
function __taFmtNum(n, dec, sep) {
  var s = Math.abs(n).toFixed(dec), parts;
  if (sep) { parts = s.split('.'); parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ','); s = parts.join('.'); }
  return (n < 0 && parseFloat(s.replace(/,/g, '')) !== 0 ? '-' : '') + s;
}
function __taGroups(s) {
  var out = [], re = /\d+/g, m;
  s = String(s == null ? '' : s);
  while ((m = re.exec(s)) !== null) out.push({ i: m.index, s: m[0] });
  return out;
}
function __taPhase(a, el) {
  var c = a.cfg, d = c.delay || 0, dur = Math.max(1, a.durOv || c.dur), n = c.rep || 0, gap = c.pause || 0, t, cyc, rep, q, k;
  if (a.perp) return { k: 0, e: 0, ms: Math.max(0, el), rep: 0, done: false, hold: false };
  if (el < d) return { k: 0, e: __taEase(c.ease, 0), ms: 0, rep: 0, done: false, hold: true };
  t = el - d; cyc = dur + gap;
  if (t >= n * cyc + dur) return { k: 1, e: 1, ms: dur, rep: n, done: true, hold: false };
  rep = Math.floor(t / cyc); q = t - rep * cyc; k = q >= dur ? 1 : q / dur;
  return { k: k, e: __taEase(c.ease, k), ms: q >= dur ? dur : q, rep: rep, done: false, hold: false };
}
function __taFinal(a) {
  var s = { text: a.text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: true, alpha: 255 }, fx = __taFx[a.cfg.fx];
  if (fx.final) fx.final(a, s);
  return s;
}
function __taSample(a, el) {
  var ph = __taPhase(a, el), s = __taFinal(a), fx = __taFx[a.cfg.fx], o, key;
  if (ph.done) return { s: s, done: true, ph: ph };
  o = fx.frame(a, ph.k, ph);
  for (key in o) { if (Object.prototype.hasOwnProperty.call(o, key)) s[key] = o[key]; }
  return { s: s, done: false, ph: ph };
}
function __taAlpha(target, v) {
  var wd = target;
  if (!wd) return;
  try { wd.setAlpha(v); } catch (e) {}
}
function __taApply(a, s) {
  var o = {}, any = false, L = a.last, cut, tx = s.text, rest;
  if (a.cellLayout) {
    __taApplyCells(a, s);
    a.last = { text: tx, text2: null, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
    return;
  }
  if (a.w2) {
    cut = tx.indexOf(a.cfg.sep);
    rest = cut >= 0 ? tx.slice(cut + a.cfg.sep.length) : '';
    if (cut >= 0) tx = tx.slice(0, cut);
    if (rest !== L.text2) { try { a.w2.setProperty(prop.MORE, { text: rest }); } catch (e1) {} L.text2 = rest; }
  }
  if (tx !== L.text) { o.text = tx; any = true; }
  if (s.color !== L.color) { o.color = s.color; any = true; }
  if (s.x !== L.x) { o.x = s.x; any = true; }
  if (s.y !== L.y) { o.y = s.y; any = true; }
  if (s.size !== L.size) { o.text_size = s.size; any = true; }
  if (a.c && s.vis !== L.vis) { try { a.c.setProperty(prop.VISIBLE, s.vis); } catch (e2) {} }
  if (s.alpha !== L.alpha && s.alpha !== undefined) {
    __taAlpha(a.w, s.alpha); __taAlpha(a.w2, s.alpha); __taAlpha(a.c, s.alpha);
  }
  a.last = { text: tx, text2: L.text2, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis, alpha: s.alpha };
  if (any && a.w) { try { a.w.setProperty(prop.MORE, o); } catch (e3) {} }
}
function __taShow(a) { __taApply(a, __taFinal(a)); }
// Условия повторного запуска эффектов при изменении исходного текста.
// Для «Проявления» и «Пульсации размера» посимвольный режим дополнительно
// ограничивает сами стили изменившимися разрядами; остальные эффекты фильтруют запуск целиком.
function __taChangeAllowed(a, oldText, newText) {
  var mode = a.cfg.track || 'all', oldD, newD, i, off;
  if (mode === 'all') return true;
  if (mode === 'off') return false;
  oldD = String(oldText == null ? '' : oldText).replace(/[^0-9]/g, '');
  newD = String(newText == null ? '' : newText).replace(/[^0-9]/g, '');
  if (mode === 'changed') return oldD !== newD;
  if (mode === 'seconds' && !a.cfg.trackSec) return false;
  if (mode === 'units') off = 1;
  else if (mode === 'tens') off = 2;
  else if (mode === 'seconds') {
    for (i = 1; i <= 2; i++) {
      if (oldD.charAt(oldD.length - i) !== newD.charAt(newD.length - i)) return true;
    }
    return false;
  } else return true;
  if (oldD.length < off || newD.length < off) return false;
  return oldD.charAt(oldD.length - off) !== newD.charAt(newD.length - off);
}
// Определяет только цифры, которым разрешено анимироваться в посимвольных режимах.
function __taCharTargets(a, why) {
  var cur = __taChars(a.text), old = __taChars(a.prevText || ''), mode = a.cfg.track || 'all';
  var digits = [], target = {}, i, idx, off;
  for (i = 0; i < cur.length; i++) if (cur[i] >= '0' && cur[i] <= '9') digits.push(i);
  if (why === 'open') {
    if (mode === 'seconds' && a.cfg.trackSec) {
      off = Math.max(0, digits.length - 2);
      for (i = off; i < digits.length; i++) target[digits[i]] = true;
    } else if (mode === 'tens' || mode === 'units') {
      off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
      if (off >= 0) target[digits[off]] = true;
    } else if (mode === 'changed') {
      for (i = 0; i < digits.length; i++) target[digits[i]] = true;
    }
    return target;
  }
  if (why !== 'update' && why !== 'wake') return target;
  if (mode === 'seconds') {
    if (!a.cfg.trackSec) return target;
    off = Math.max(0, digits.length - 2);
    for (i = off; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else if (mode === 'tens' || mode === 'units') {
    off = mode === 'tens' ? digits.length - 2 : digits.length - 1;
    if (off >= 0) { idx = digits[off]; if (old[idx] !== cur[idx]) target[idx] = true; }
  } else {
    for (i = 0; i < digits.length; i++) { idx = digits[i]; if (old[idx] !== cur[idx]) target[idx] = true; }
  }
  return target;
}
function __taApplyCells(a, s) {
  var l = a.cellLayout, ws = l.widgets, chars = __taChars(s.text), n = ws.length;
  var count = Math.min(chars.length, n), gap = Number(l.gap || 0), total = 0, start, x, cellX, i, ch, col, size, o, prev, w, cw, scale, renderW, al, widths = [];
  // La anchura de composición siempre usa la métrica base para que una pulsación
  // no empuje las cifras vecinas. Solo se ensancha la celda animada, simétricamente.
  for (i = 0; i < count; i++) {
    ch = chars[i]; cw = Math.max(1, Number((l.charWidths && l.charWidths[ch]) || l.defaultWidth || 1));
    widths[i] = cw; total += cw;
  }
  if (count > 1) total += gap * (count - 1);
  if (l.align === 'LEFT') start = Number(l.x || 0);
  else if (l.align === 'RIGHT') start = Number(l.x || 0) + Number(l.w || 0) - total;
  else start = Number(l.x || 0) + Number(l.w || 0) / 2 - total / 2;
  x = start;
  if (!a.cellLast) a.cellLast = [];
  for (i = 0; i < n; i++) {
    ch = i < count ? chars[i] : '';
    cw = i < count ? widths[i] : Math.max(1, Number(l.defaultWidth || 1));
    col = s.charColors && s.charColors[i] != null ? s.charColors[i] : s.color;
    size = s.charSizes && s.charSizes[i] != null ? s.charSizes[i] : s.size;
    scale = a.base.size > 0 ? Math.max(1, Number(size || a.base.size) / a.base.size) : 1;
    renderW = Math.max(cw, Math.ceil(cw * scale));
    cellX = x - (renderW - cw) / 2;
    prev = a.cellLast[i] || { text: null, color: null, size: null, x: null, w: null, alpha: 255 };
    al = s.charAlphas && s.charAlphas[i] != null ? s.charAlphas[i] : (s.alpha == null ? 255 : s.alpha);
    o = {};
    if (ch !== prev.text) o.text = ch;
    if (col !== prev.color) o.color = col;
    if (size !== prev.size) o.text_size = size;
    if (Math.round(cellX) !== prev.x) o.x = Math.round(cellX);
    if (renderW !== prev.w) o.w = renderW;
    w = ws[i];
    if (Object.keys(o).length && w) { try { w.setProperty(prop.MORE, o); } catch (e) {} }
    if (al !== prev.alpha) __taAlpha(w, al);
    a.cellLast[i] = { text: ch, color: col, size: size, x: Math.round(cellX), w: renderW, alpha: al };
    x += cw + gap;
  }
}

function __taEnsure() {
  var ms = 1000, i;
  if (__TA.timer || !__TA.list.length) return;
  for (i = 0; i < __TA.list.length; i++) { if (__TA.list[i].step < ms) ms = __TA.list[i].step; }
  __TA.timer = setInterval(__taStep, Math.max(30, ms));
}
function __taDrop(a) {
  var i = __TA.list.indexOf(a);
  if (i >= 0) __TA.list.splice(i, 1);
  if (!__TA.list.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taStep() {
  var now = Date.now(), keep = [], i, a, r, fx;
  for (i = 0; i < __TA.list.length; i++) {
    a = __TA.list[i];
    r = __taSample(a, now - a.t0);
    fx = __taFx[a.cfg.fx];
    if (r.done) { a.on = false; if (fx.done) fx.done(a); __taShow(a); }
    else { __taApply(a, r.s); keep.push(a); }
  }
  __TA.list = keep;
  if (!keep.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taBegin(a, why) {
  var fx = __taFx[a.cfg.fx];
  a.durOv = 0;
  if (fx.init) fx.init(a, why);
  a.t0 = Date.now(); a.on = true; a.why = why;
}
function __taPlay(a, why) {
  var r;
  if (__TA.paused) return;
  if (a.on && a.cfg.retrig === 'ignore') return;
  __taBegin(a, why);
  r = __taSample(a, 0);
  __taApply(a, r.s);
  if (__TA.list.indexOf(a) < 0) __TA.list.push(a);
  __taEnsure();
}
function __taStop(a) { a.on = false; __taDrop(a); __taShow(a); }
function __taSetText(a, text) {
  var c = a.cfg, fx = __taFx[c.fx], old = a.text, changed;
  text = text == null ? '' : String(text);
  changed = text !== old;
  a.prevText = old;
  a.text = text;
  if (fx.live) { fx.live(a, old, text, changed); return; }
  if (!a.opened) {
    if (fx.can && !fx.can(a)) { __taShow(a); return; }
    a.opened = true;
    if (c.open) __taPlay(a, 'open'); else __taShow(a);
    return;
  }
  if (!changed) { if (!a.on) __taShow(a); return; }
  // Применяется одинаково ко всем эффектам с обработчиком изменения (в том числе
  // count/flash/flip, у которых специальная обработка обновления значения).
  // При проигнорированном изменении сразу показываем новое значение без старого кадра.
  if (!__taChangeAllowed(a, old, text)) { if (a.on) __taStop(a); else __taShow(a); return; }
  if (fx.onChange) { fx.onChange(a, old, text); return; }
  if (c.change && (!fx.can || fx.can(a))) { __taPlay(a, 'update'); return; }
  if (!a.on) __taShow(a);
}
function __taCreate(w, cfg, base, w2, cw, cellLayout) {
  var fx = __taFx[cfg.fx];
  var a = { w: w, w2: w2 || null, c: cw || null, cellLayout: cellLayout || null, cellLast: [], charMode: !!cfg.charMode || !!cellLayout, charTargets: null, cfg: cfg, base: base, text: '', prevText: '', t0: 0, on: false, opened: false, why: '', durOv: 0, perp: !!(fx.perp && cfg.iv < 1000), blink: 0, cnt: null, curV: null, fl: null, step: 50, last: { text: null, text2: null, color: base.fin, x: base.x, y: base.y, size: base.size, vis: true, alpha: 255 } };
  a.step = fx.step ? fx.step(cfg) : 50;
  __TA.all.push(a);
  return a;
}
function __taPause() {
  var i, a;
  __TA.paused = true;
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = [];
  for (i = 0; i < __TA.all.length; i++) { a = __TA.all[i]; a.on = false; __taShow(a); }
}
function __taResume() {
  var now = Date.now(), i, a, fx;
  __TA.paused = false;
  for (i = 0; i < __TA.all.length; i++) {
    a = __TA.all[i]; fx = __taFx[a.cfg.fx];
    if (!a.opened) continue;
    if (fx.resume) { fx.resume(a); continue; }
    if (a.cfg.wake && now - a.t0 > 800) __taPlay(a, 'wake');
  }
}
function __taDestroy() {
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = []; __TA.all = []; __TA.paused = false;
}

__taFx.reveal = {
  step: function () { return 50; },
  init: function (a, why) { if (a.charMode) a.charTargets = __taCharTargets(a, why); },
  frame: function (a, k, ph) {
    var colors, alphas, ch, i, al;
    if (a.cfg.ta) {
      // «Из прозрачного»: цвет сразу конечный, меняется только прозрачность 0 → 255.
      al = Math.round(255 * ph.e);
      if (a.charMode) {
        alphas = []; ch = __taChars(a.text);
        for (i = 0; i < ch.length; i++) alphas[i] = a.charTargets && a.charTargets[i] ? al : 255;
        return { charAlphas: alphas };
      }
      return { alpha: al };
    }
    if (a.charMode) {
      colors = []; ch = __taChars(a.text);
      for (i = 0; i < ch.length; i++) colors[i] = a.charTargets && a.charTargets[i] ? __taMix(a.cfg.c1, a.base.fin, ph.e) : null;
      return { charColors: colors };
    }
    return { color: __taMix(a.cfg.c1, a.base.fin, ph.e) };
  }
};


const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _distance = null;
let _barometer = null;

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    const __afEd = [];

    const __afProfileWidgets = { day: [], night: [] };
    const __afProfileWidgetState = new Map();
    let __afActiveProfile = '';
    function __afCreateProfileWidget(profile, id, options) {
      const w = createWidget(id, options);
      const record = { widget: w, profile: profile, visible: true };
      __afProfileWidgetState.set(w, record);
      __afProfileWidgets[profile].push(record);
      try { w.setProperty(prop.VISIBLE, profile === __afActiveProfile); } catch (e) {}
      return w;
    }
    function __afCreateDayWidget(id, options) { return __afCreateProfileWidget('day', id, options); }
    function __afCreateNightWidget(id, options) { return __afCreateProfileWidget('night', id, options); }
    function __afSetProfileVisible(w, visible) {
      const record = __afProfileWidgetState.get(w);
      if (!record) { try { w.setProperty(prop.VISIBLE, !!visible); } catch (e) {} return; }
      record.visible = !!visible;
      try { w.setProperty(prop.VISIBLE, record.visible && record.profile === __afActiveProfile); } catch (e) {}
    }
    function __afProfileApply(profile) {
      profile = profile === 'night' ? 'night' : 'day';
      if (profile === __afActiveProfile) return;
      try { const offs = self._flashOffs || []; for (let i = 0; i < offs.length; i++) { try { offs[i](); } catch (e) {} } } catch (e) {}
      __afActiveProfile = profile;
      ['day', 'night'].forEach(function (key) {
        const list = __afProfileWidgets[key] || [];
        for (let i = 0; i < list.length; i++) {
          const record = list[i];
          try { record.widget.setProperty(prop.VISIBLE, record.visible && key === profile); } catch (e) {}
        }
      });
    }
    let __afProfileTime = null;
    try { __afProfileTime = new Time(); } catch (e) {}
    function __afProfileRefresh() {
      const mode = __afProfilePrefs.profileMode || 'day';
      let target = mode === 'night' ? 'night' : 'day';
      if (mode === 'auto') {
        const now = __afProfileTime ? new Date(__afProfileTime.getTime()) : new Date();
        const hour = now.getHours();
        const start = Number(__afProfilePrefs.profileStart);
        const end = Number(__afProfilePrefs.profileEnd);
        const night = start !== end && (start < end ? hour >= start && hour < end : hour >= start || hour < end);
        target = night ? 'night' : 'day';
      }
      __afProfileApply(target);
      try { if (typeof __afPanelRefresh === 'function') __afPanelRefresh(); } catch (e) {}
    }
    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "photo_2026_11_05_22_12_36_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_text_001_ch0 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 24, y: 167, w: 61, h: 140, text_size: 110, color: 0xe58b19, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_0_text_001_ch1 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 24, y: 167, w: 61, h: 140, text_size: 110, color: 0xe58b19, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_0_text_001_a = __taCreate(null, { fx: "reveal", dur: 800, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "restart", open: false, wake: true, change: true, track: "changed", trackSec: false, charMode: true, c1: 0x000000, ta: 1 }, { x: 24, y: 167, color: 0xe58b19, fin: 0xe58b19, size: 110 }, null, null, { widgets: [normal_w_0_text_001_ch0, normal_w_0_text_001_ch1], charWidths: {"0":61,"1":61,"2":61,"3":61,"4":61,"5":61,"6":61,"7":61,"8":61,"9":61,"-":37,"+":64,",":31,".":31,"%":98," ":31,":":37,"/":31}, defaultWidth: 61, x: 24, w: 150, align: "CENTER_H", gap: 0 });
          const normal_w_0_text_001 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_0_text_001_a, o.text); } else { for (let i = 0; i < 2; i++) { [normal_w_0_text_001_ch0, normal_w_0_text_001_ch1][i].setProperty(k, o); } } } };
          const normal_w_1_text_003_ch0 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 178, y: 167, w: 61, h: 140, text_size: 110, color: 0xe3cb37, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_003_ch1 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 178, y: 167, w: 61, h: 140, text_size: 110, color: 0xe3cb37, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_003_a = __taCreate(null, { fx: "reveal", dur: 800, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "restart", open: false, wake: true, change: true, track: "changed", trackSec: false, charMode: true, c1: 0x000000, ta: 1 }, { x: 178, y: 167, color: 0xe3cb37, fin: 0xe3cb37, size: 110 }, null, null, { widgets: [normal_w_1_text_003_ch0, normal_w_1_text_003_ch1], charWidths: {"0":61,"1":61,"2":61,"3":61,"4":61,"5":61,"6":61,"7":61,"8":61,"9":61,"-":37,"+":64,",":31,".":31,"%":98," ":31,":":37,"/":31}, defaultWidth: 61, x: 178, w: 150, align: "CENTER_H", gap: 0 });
          const normal_w_1_text_003 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_1_text_003_a, o.text); } else { for (let i = 0; i < 2; i++) { [normal_w_1_text_003_ch0, normal_w_1_text_003_ch1][i].setProperty(k, o); } } } };
          const normal_w_2_text_004 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 190, w: 140, h: 50, text_size: 45, color: 0x47cad7, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "text_004", n: "Текст", d: "AIR_PRESSURE", h: normal_w_2_text_004, x: 310, y: 190, w: 140, ht: 50, s: 45, c: 0x47cad7, ah: "CENTER_H" });
          const normal_w_3_text_005 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 230, w: 150, h: 50, text_size: 29, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "давление" });
          __afEd.push({ id: "text_005", n: "Текст", d: "давление", h: normal_w_3_text_005, x: 310, y: 230, w: 150, ht: 50, s: 29, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_4_text_006 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 256, y: 300, w: 160, h: 40, text_size: 29, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "дистанция" });
          __afEd.push({ id: "text_006", n: "Текст", d: "дистанция", h: normal_w_4_text_006, x: 256, y: 300, w: 160, ht: 40, s: 29, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_5_text_007 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 259, y: 347, w: 160, h: 50, text_size: 45, color: 0x47cad7, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "text_007", n: "Текст", d: "STEP", h: normal_w_5_text_007, x: 259, y: 347, w: 160, ht: 50, s: 45, c: 0x47cad7, ah: "CENTER_H" });
          const normal_w_6_text_008 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 75, y: 322, w: 160, h: 50, text_size: 45, color: 0x47cad7, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "text_008", n: "Текст", d: "DISTANCE", h: normal_w_6_text_008, x: 75, y: 322, w: 160, ht: 50, s: 45, c: 0x47cad7, ah: "CENTER_H" });
          const normal_w_7_text_009 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 100, y: 370, w: 120, h: 50, text_size: 33, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "Км" });
          __afEd.push({ id: "text_009", n: "Текст", d: "Км", h: normal_w_7_text_009, x: 100, y: 370, w: 120, ht: 50, s: 33, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_8_text_010 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 250, y: 90, w: 120, h: 50, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "text_010", n: "Текст", d: "BATTERY", h: normal_w_8_text_010, x: 250, y: 90, w: 120, ht: 50, s: 36, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_9_text_011 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 60, y: 131, w: 180, h: 50, text_size: 21, color: 0x47cad7, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "text_011", n: "Текст", d: "WEEKDAY", h: normal_w_9_text_011, x: 60, y: 131, w: 180, ht: 50, s: 21, c: 0x47cad7, ah: "CENTER_H" });
          const normal_w_10_text_012 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 78, y: 65, w: 170, h: 80, text_size: 41, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "text_012", n: "Текст", d: "DATE", h: normal_w_10_text_012, x: 78, y: 65, w: 170, ht: 80, s: 41, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_11_weather_icon_001 = __afCreateDayWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 350, y: 100, w: 64, h: 64, image_array: ["weather/64x64/0_cloudy.png", "weather/64x64/1_showers.png", "weather/64x64/2_snow_showers.png", "weather/64x64/3_sunny.png", "weather/64x64/4_overcast.png", "weather/64x64/5_light_rain.png", "weather/64x64/6_light_snow.png", "weather/64x64/7_moderate_rain.png", "weather/64x64/8_moderate_snow.png", "weather/64x64/9_heavy_snow.png", "weather/64x64/10_heavy_rain.png", "weather/64x64/11_sandstorm.png", "weather/64x64/12_rain_snow.png", "weather/64x64/13_fog.png", "weather/64x64/14_hazy.png", "weather/64x64/15_thunderstorm.png", "weather/64x64/16_snowstorm.png", "weather/64x64/17_floating_dust.png", "weather/64x64/18_very_heavy_rainstorm.png", "weather/64x64/19_rain_hail.png", "weather/64x64/20_thunderstorm_hail.png", "weather/64x64/21_heavy_rainstorm.png", "weather/64x64/22_dust.png", "weather/64x64/23_heavy_sandstorm.png", "weather/64x64/24_rainstorm.png", "weather/64x64/25_unknown.png", "weather/64x64/26_cloudy_night.png", "weather/64x64/27_showers_night.png", "weather/64x64/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 7, alpha: 255 });
          const normal_w_12_weather_temp_001 = __afCreateDayWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 250, y: 132, w: 120, h: 40, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          __afEd.push({ id: "weather_temp_001", n: "Температура", d: "WEATHER_TEMP", h: normal_w_12_weather_temp_001, x: 250, y: 132, w: 120, ht: 40, s: 32, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_13_image_002 = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 317, y: 407, w: 30, h: 30, src: "edited_30x30.png" });
          normal_w_13_image_002.setAlpha(255);
          const normal_tap_0_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 190, w: 140, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_ALTIMETER, native: true }); } catch (e) {} } });
          normal_tap_0_tap_001.setAlpha(0);
          const normal_tap_1_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 259, y: 347, w: 160, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STATUS, native: true }); } catch (e) {} } });
          normal_tap_1_tap_001.setAlpha(0);
          const normal_tap_2_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 5, y: 292, w: 90, h: 70, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afOpenSettings(); } catch (e) {} } });
          normal_tap_2_tap_001.setAlpha(0);
          const normal_tap_3_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 60, y: 81, w: 180, h: 100, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          normal_tap_3_tap_001.setAlpha(0);
          const normal_tap_4_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 350, y: 100, w: 64, h: 64, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_4_tap_001.setAlpha(0);
          const normal_tap_5_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 267, y: 397, w: 150, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_normal_(!__flashOn_normal_); } catch (e) {} } });
          normal_tap_5_tap_001.setAlpha(0);
          let __flashOn_normal_ = false;
          const __flash_normal_ = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0xffffff });
          const __flashBtn_normal_ = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_normal_(false); } catch (e) {} } });
          __flashBtn_normal_.setAlpha(0);
          let __flashSaved_normal_ = null;
          function __flashBr_normal_(on) {
            try {
              if (on) {
                if (__flashSaved_normal_) return;
                __flashSaved_normal_ = { auto: !!getAutoBrightness(), level: getBrightness() };
                setAutoBrightness({ autoBright: false });
                setBrightness({ brightness: 100 });
              } else if (__flashSaved_normal_) {
                const s = __flashSaved_normal_;
                __flashSaved_normal_ = null;
                if (typeof s.level === 'number') setBrightness({ brightness: s.level });
                setAutoBrightness({ autoBright: s.auto });
              }
            } catch (e) {}
          }
          function __flashSet_normal_(on) {
            try {
              __flashOn_normal_ = !!on;
              __afSetProfileVisible(__flash_normal_, __flashOn_normal_);
              __afSetProfileVisible(__flashBtn_normal_, __flashOn_normal_);
            } catch (e) {}
            try { __flashBr_normal_(__flashOn_normal_); } catch (e) {}
          }
          __flashSet_normal_(false);
          self._flashOffs = self._flashOffs || [];
          self._flashOffs.push(() => __flashSet_normal_(false));
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            __afCreateDayWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} try { const fo = self._flashOffs || []; for (let i = 0; i < fo.length; i++) { try { fo[i](); } catch (e) {} } } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _distance = new Distance(); } catch (e) {}
          try { _barometer = new Barometer(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_0_text_001.setProperty(prop.MORE, { text: formatHour(now, "HH", true) });
            normal_w_1_text_003.setProperty(prop.MORE, { text: formatUnit(now.getMinutes(), true) });
            normal_w_9_text_011.setProperty(prop.MORE, { text: formatWeekday(now, "EEEE", "RU") });
            normal_w_10_text_012.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _barometer ? _barometer.getAirPressure() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_2_text_004.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_2_text_004.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_5_text_007.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_5_text_007.setProperty(prop.MORE, { text: '--' }); }
            try {
              const raw = _distance ? _distance.getCurrent() : null;
              // Единица возвращаемого значения в документации не указана (⚠) — принята за метры.
              let v = typeof raw === 'number' ? raw / 1000 : null;
              const txt = v !== null ? v.toFixed(2) : '--';
              normal_w_6_text_008.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_6_text_008.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_8_text_010.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + " %" : '--') });
            } catch (e) { normal_w_8_text_010.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // Night profile widgets — isolated lexical scope
    {
          const __bgColor_night_ = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_night_.setAlpha(255);
          const __bgImage_night_ = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "photo_2026_11_05_22_12_36_bg_kopiya.png" });
          __bgImage_night_.setAlpha(255);
          const night_w_0_text_001_ch0 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 24, y: 170, w: 61, h: 140, text_size: 110, color: 0xb0701c, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const night_w_0_text_001_ch1 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 24, y: 170, w: 61, h: 140, text_size: 110, color: 0xb0701c, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const night_w_0_text_001_a = __taCreate(null, { fx: "reveal", dur: 800, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "restart", open: false, wake: true, change: true, track: "changed", trackSec: false, charMode: true, c1: 0x000000, ta: 1 }, { x: 24, y: 170, color: 0xb0701c, fin: 0xb0701c, size: 110 }, null, null, { widgets: [night_w_0_text_001_ch0, night_w_0_text_001_ch1], charWidths: {"0":61,"1":61,"2":61,"3":61,"4":61,"5":61,"6":61,"7":61,"8":61,"9":61,"-":37,"+":64,",":31,".":31,"%":98," ":31,":":37,"/":31}, defaultWidth: 61, x: 24, w: 150, align: "CENTER_H", gap: 0 });
          const night_w_0_text_001 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(night_w_0_text_001_a, o.text); } else { for (let i = 0; i < 2; i++) { [night_w_0_text_001_ch0, night_w_0_text_001_ch1][i].setProperty(k, o); } } } };
          const night_w_1_text_003_ch0 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 178, y: 170, w: 61, h: 140, text_size: 110, color: 0x96882c, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const night_w_1_text_003_ch1 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 178, y: 170, w: 61, h: 140, text_size: 110, color: 0x96882c, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const night_w_1_text_003_a = __taCreate(null, { fx: "reveal", dur: 800, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "restart", open: false, wake: true, change: true, track: "changed", trackSec: false, charMode: true, c1: 0x000000, ta: 1 }, { x: 178, y: 170, color: 0x96882c, fin: 0x96882c, size: 110 }, null, null, { widgets: [night_w_1_text_003_ch0, night_w_1_text_003_ch1], charWidths: {"0":61,"1":61,"2":61,"3":61,"4":61,"5":61,"6":61,"7":61,"8":61,"9":61,"-":37,"+":64,",":31,".":31,"%":98," ":31,":":37,"/":31}, defaultWidth: 61, x: 178, w: 150, align: "CENTER_H", gap: 0 });
          const night_w_1_text_003 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(night_w_1_text_003_a, o.text); } else { for (let i = 0; i < 2; i++) { [night_w_1_text_003_ch0, night_w_1_text_003_ch1][i].setProperty(k, o); } } } };
          const night_w_2_text_004 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 190, w: 140, h: 50, text_size: 45, color: 0x1d5358, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:text_004", n: "Текст", d: "AIR_PRESSURE", h: night_w_2_text_004, x: 310, y: 190, w: 140, ht: 50, s: 45, c: 0x1d5358, ah: "CENTER_H" });
          const night_w_3_text_005 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 306, y: 230, w: 160, h: 50, text_size: 29, color: 0x757575, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "давление" });
          __afEd.push({ id: "night:text_005", n: "Текст", d: "давление", h: night_w_3_text_005, x: 306, y: 230, w: 160, ht: 50, s: 29, c: 0x757575, ah: "CENTER_H" });
          const night_w_4_text_006 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 256, y: 300, w: 160, h: 40, text_size: 29, color: 0x757575, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "дистанция" });
          __afEd.push({ id: "night:text_006", n: "Текст", d: "дистанция", h: night_w_4_text_006, x: 256, y: 300, w: 160, ht: 40, s: 29, c: 0x757575, ah: "CENTER_H" });
          const night_w_5_text_007 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 259, y: 347, w: 160, h: 50, text_size: 45, color: 0x184549, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:text_007", n: "Текст", d: "STEP", h: night_w_5_text_007, x: 259, y: 347, w: 160, ht: 50, s: 45, c: 0x184549, ah: "CENTER_H" });
          const night_w_6_text_008 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 75, y: 322, w: 160, h: 50, text_size: 45, color: 0x184549, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:text_008", n: "Текст", d: "DISTANCE", h: night_w_6_text_008, x: 75, y: 322, w: 160, ht: 50, s: 45, c: 0x184549, ah: "CENTER_H" });
          const night_w_7_text_009 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 100, y: 370, w: 120, h: 50, text_size: 33, color: 0x757575, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "Км" });
          __afEd.push({ id: "night:text_009", n: "Текст", d: "Км", h: night_w_7_text_009, x: 100, y: 370, w: 120, ht: 50, s: 33, c: 0x757575, ah: "CENTER_H" });
          const night_w_8_text_010 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 250, y: 90, w: 120, h: 50, text_size: 36, color: 0x757575, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:text_010", n: "Текст", d: "BATTERY", h: night_w_8_text_010, x: 250, y: 90, w: 120, ht: 50, s: 36, c: 0x757575, ah: "CENTER_H" });
          const night_w_9_text_011 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 60, y: 131, w: 180, h: 50, text_size: 21, color: 0x184549, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "night:text_011", n: "Текст", d: "WEEKDAY", h: night_w_9_text_011, x: 60, y: 131, w: 180, ht: 50, s: 21, c: 0x184549, ah: "CENTER_H" });
          const night_w_10_text_012 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 78, y: 65, w: 170, h: 80, text_size: 41, color: 0x757575, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "night:text_012", n: "Текст", d: "DATE", h: night_w_10_text_012, x: 78, y: 65, w: 170, ht: 80, s: 41, c: 0x757575, ah: "CENTER_H" });
          const night_w_11_weather_icon_001 = __afCreateNightWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 350, y: 100, w: 64, h: 64, image_array: ["weather/64x64/0_cloudy.png", "weather/64x64/1_showers.png", "weather/64x64/2_snow_showers.png", "weather/64x64/3_sunny.png", "weather/64x64/4_overcast.png", "weather/64x64/5_light_rain.png", "weather/64x64/6_light_snow.png", "weather/64x64/7_moderate_rain.png", "weather/64x64/8_moderate_snow.png", "weather/64x64/9_heavy_snow.png", "weather/64x64/10_heavy_rain.png", "weather/64x64/11_sandstorm.png", "weather/64x64/12_rain_snow.png", "weather/64x64/13_fog.png", "weather/64x64/14_hazy.png", "weather/64x64/15_thunderstorm.png", "weather/64x64/16_snowstorm.png", "weather/64x64/17_floating_dust.png", "weather/64x64/18_very_heavy_rainstorm.png", "weather/64x64/19_rain_hail.png", "weather/64x64/20_thunderstorm_hail.png", "weather/64x64/21_heavy_rainstorm.png", "weather/64x64/22_dust.png", "weather/64x64/23_heavy_sandstorm.png", "weather/64x64/24_rainstorm.png", "weather/64x64/25_unknown.png", "weather/64x64/26_cloudy_night.png", "weather/64x64/27_showers_night.png", "weather/64x64/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 12, alpha: 77 });
          const night_w_12_weather_temp_001 = __afCreateNightWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 250, y: 132, w: 120, h: 40, text_size: 32, color: 0x757575, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          __afEd.push({ id: "night:weather_temp_001", n: "Температура", d: "WEATHER_TEMP", h: night_w_12_weather_temp_001, x: 250, y: 132, w: 120, ht: 40, s: 32, c: 0x757575, ah: "CENTER_H" });
          const night_w_13_image_001 = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 320, y: 410, w: 30, h: 30, src: "edited_30x30.png" });
          night_w_13_image_001.setAlpha(120);
          const night_tap_0_tap_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 279, y: 397, w: 140, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_night_(!__flashOn_night_); } catch (e) {} } });
          night_tap_0_tap_001.setAlpha(0);
          const night_tap_1_tap_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 15, y: 302, w: 90, h: 90, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afOpenSettings(); } catch (e) {} } });
          night_tap_1_tap_001.setAlpha(0);
          let __flashOn_night_ = false;
          const __flash_night_ = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0xffffff });
          const __flashBtn_night_ = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, normal_src: "", press_src: "", enable: true, click_func: () => { try { __flashSet_night_(false); } catch (e) {} } });
          __flashBtn_night_.setAlpha(0);
          let __flashSaved_night_ = null;
          function __flashBr_night_(on) {
            try {
              if (on) {
                if (__flashSaved_night_) return;
                __flashSaved_night_ = { auto: !!getAutoBrightness(), level: getBrightness() };
                setAutoBrightness({ autoBright: false });
                setBrightness({ brightness: 100 });
              } else if (__flashSaved_night_) {
                const s = __flashSaved_night_;
                __flashSaved_night_ = null;
                if (typeof s.level === 'number') setBrightness({ brightness: s.level });
                setAutoBrightness({ autoBright: s.auto });
              }
            } catch (e) {}
          }
          function __flashSet_night_(on) {
            try {
              __flashOn_night_ = !!on;
              __afSetProfileVisible(__flash_night_, __flashOn_night_);
              __afSetProfileVisible(__flashBtn_night_, __flashOn_night_);
            } catch (e) {}
            try { __flashBr_night_(__flashOn_night_); } catch (e) {}
          }
          __flashSet_night_(false);
          self._flashOffs = self._flashOffs || [];
          self._flashOffs.push(() => __flashSet_night_(false));
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            __afCreateNightWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} try { const fo = self._flashOffs || []; for (let i = 0; i < fo.length; i++) { try { fo[i](); } catch (e) {} } } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _distance = new Distance(); } catch (e) {}
          try { _barometer = new Barometer(); } catch (e) {}
      
          function _tickNight() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            night_w_0_text_001.setProperty(prop.MORE, { text: formatHour(now, "HH", true) });
            night_w_1_text_003.setProperty(prop.MORE, { text: formatUnit(now.getMinutes(), true) });
            night_w_9_text_011.setProperty(prop.MORE, { text: formatWeekday(now, "EEEE", "RU") });
            night_w_10_text_012.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
          }
          _tickNight();
          self._timeTimerNight = setInterval(_tickNight, 1000);
      
          function _tickSensorsNight() {
            try {
              const v = _barometer ? _barometer.getAirPressure() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              night_w_2_text_004.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_2_text_004.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              night_w_5_text_007.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_5_text_007.setProperty(prop.MORE, { text: '--' }); }
            try {
              const raw = _distance ? _distance.getCurrent() : null;
              // Единица возвращаемого значения в документации не указана (⚠) — принята за метры.
              let v = typeof raw === 'number' ? raw / 1000 : null;
              const txt = v !== null ? v.toFixed(2) : '--';
              night_w_6_text_008.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_6_text_008.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              night_w_8_text_010.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "" : '--') });
            } catch (e) { night_w_8_text_010.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNight();
          self._sensorTimerNight = setInterval(_tickSensorsNight, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 20, y: 170, w: 320, h: 130, text_size: 110, color: 0x734911, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          // Плавающий текст AOD: шаг 6px, обновление раз в 5 с (⚠ unverified, см. docs/AOD_FLOAT.md)
          let aod_w_0_text_001_fl_x = 20, aod_w_0_text_001_fl_y = 170, aod_w_0_text_001_fl_vx = 6, aod_w_0_text_001_fl_vy = 4;
          function aod_w_0_text_001_fl_in(px, py) { const xs = [px, px + 320], ys = [py, py + 130]; for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { const dx = xs[i] - 240, dy = ys[j] - 240; if (dx * dx + dy * dy > 51984) return false; } return true; }
          function aod_w_0_text_001_fl_step() {
            try {
              if (!aod_w_0_text_001_fl_in(aod_w_0_text_001_fl_x, aod_w_0_text_001_fl_y)) {
                // Старт вне допустимой области: возвращаем текст к центру экрана.
                aod_w_0_text_001_fl_x += (240 - (aod_w_0_text_001_fl_x + 320 / 2)) > 0 ? 6 : -6;
                aod_w_0_text_001_fl_y += (240 - (aod_w_0_text_001_fl_y + 130 / 2)) > 0 ? 4 : -4;
              } else {
                let nx = aod_w_0_text_001_fl_x + aod_w_0_text_001_fl_vx;
                if (!aod_w_0_text_001_fl_in(nx, aod_w_0_text_001_fl_y)) { aod_w_0_text_001_fl_vx = -aod_w_0_text_001_fl_vx; nx = aod_w_0_text_001_fl_x + aod_w_0_text_001_fl_vx; if (!aod_w_0_text_001_fl_in(nx, aod_w_0_text_001_fl_y)) nx = aod_w_0_text_001_fl_x; }
                let ny = aod_w_0_text_001_fl_y + aod_w_0_text_001_fl_vy;
                if (!aod_w_0_text_001_fl_in(nx, ny)) { aod_w_0_text_001_fl_vy = -aod_w_0_text_001_fl_vy; ny = aod_w_0_text_001_fl_y + aod_w_0_text_001_fl_vy; if (!aod_w_0_text_001_fl_in(nx, ny)) ny = aod_w_0_text_001_fl_y; }
                aod_w_0_text_001_fl_x = nx; aod_w_0_text_001_fl_y = ny;
              }
              aod_w_0_text_001.setProperty(prop.MORE, { x: Math.round(aod_w_0_text_001_fl_x), y: Math.round(aod_w_0_text_001_fl_y) });
            } catch (e) {}
          }
          (self._floatTimers = self._floatTimers || []).push(setInterval(aod_w_0_text_001_fl_step, 5000));
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_text_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
// Параметры расписания живут только в памяти текущего запуска циферблата.
    const __afPanelW = 480;
    const __afPanelH = 480;
    const __afProfilePrefs = { profileMode: "auto", profileStart: 22, profileEnd: 7 };

    const __afPanelScale = Math.min(__afPanelW, __afPanelH) / 480;
    const __afPanelPad = Math.max(6, Math.round(10 * __afPanelScale));
    const __afPanelSafePad = Math.max(6, Math.round(12 * __afPanelScale));
    const __afPanelHeaderH = Math.min(__afPanelH, Math.max(32, Math.round(38 * __afPanelScale)));
    const __afPanelBottomPad = Math.max(8, Math.round(12 * __afPanelScale));
    const __afPanelRowH = Math.max(16, Math.min(
      Math.max(18, Math.round(44 * __afPanelScale)),
      Math.floor((__afPanelH - __afPanelHeaderH - __afPanelPad - __afPanelBottomPad) / 10)
    ));
    const __afPanelHeight = Math.min(__afPanelH, __afPanelHeaderH + 10 * __afPanelRowH + __afPanelPad + __afPanelBottomPad);
    const __afPanelTop = __afPanelH - __afPanelHeight;
    const __afPanelRowY = __afPanelTop + __afPanelHeaderH + __afPanelPad;
    const __afPanelFont = Math.max(12, Math.min(Math.round(20 * __afPanelScale), Math.round((__afPanelRowH - 2) * 0.62)));
    const __afPanelStepW = Math.max(24, Math.round(46 * __afPanelScale));
    let __afPanelVisible = false;
    let __afPanelPage = 0;
    function __afPanelCircleInset(y) {
      const halfW = __afPanelW / 2;
      const halfH = __afPanelH / 2;
      const normalized = Math.max(-1, Math.min(1, (y - halfH) / Math.max(1, halfH)));
      return halfW * (1 - Math.sqrt(Math.max(0, 1 - normalized * normalized)));
    }
    function __afPanelRowBox(y, height) {
      const inset = Math.max(__afPanelCircleInset(y), __afPanelCircleInset(y + height));
      const x = Math.ceil(inset + __afPanelSafePad);
      const right = Math.floor(__afPanelW - inset - __afPanelSafePad);
      return { x: x, w: Math.max(1, right - x) };
    }
    function __afPanelSetVisible(w, visible) { w.setProperty(prop.VISIBLE, !!visible); }
    function __afPanelSetText(w, text, x, y, width, height) {
      w.setProperty(prop.MORE, { x: x, y: y, w: width, h: height, text: text });
    }
    function __afPanelSetRowText(w, text, y, height) {
      const box = __afPanelRowBox(y, height);
      __afPanelSetText(w, text, box.x, y, box.w, height);
    }
    function __afPanelButton(x, y, width, height, text, click) {
      const w = createWidget(widget.BUTTON, {
        show_level: show_level.ONLY_NORMAL,
        x: x, y: y, w: width, h: height, text: text,
        color: 0xffffff, text_size: __afPanelFont,
        normal_color: 0x253140, press_color: 0x3a4b60,
        radius: Math.max(4, Math.round(8 * __afPanelScale)),
        click_func: click,
      });
      __afPanelSetVisible(w, false);
      return w;
    }
    function __afPanelHour(value) { return (value < 10 ? '0' : '') + value + ':00'; }
    function __afPanelLargeRowHeight(y) { return Math.min(__afPanelRowH + 10, Math.max(1, __afPanelH - y)); }
    function __afPanelTimeRow(label, key, row, items, large) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = large ? __afPanelLargeRowHeight(y) : __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const desiredStepW = large ? Math.max(54, Math.round(72 * __afPanelScale)) : __afPanelStepW;
      const stepW = Math.min(desiredStepW, Math.max(20, Math.floor((box.w - 8) / 3)));
      const midW = Math.max(1, box.w - 2 * stepW - 4);
      const minus = __afPanelButton(box.x, y, stepW, h, '−', function () {
        __afProfilePrefs[key] = (__afProfilePrefs[key] + 23) % 24;
        __afProfileRefresh(); __afPanelRefresh();
      });
      const value = __afPanelButton(box.x + stepW + 2, y, midW, h, label, function () {});
      const plus = __afPanelButton(box.x + box.w - stepW, y, stepW, h, '+', function () {
        __afProfilePrefs[key] = (__afProfilePrefs[key] + 1) % 24;
        __afProfileRefresh(); __afPanelRefresh();
      });
      items.push(minus, value, plus);
      return { value: value, x: box.x + stepW + 2, y: y, w: midW, h: h };
    }
    function __afPanelRowButton(y, text, click, height) {
      const h = Math.min(height || __afPanelRowH - 2, Math.max(1, __afPanelH - y));
      const box = __afPanelRowBox(y, h);
      return __afPanelButton(box.x, y, box.w, h, text, click);
    }

    // The transparent screen-sized button makes the lower sheet modal while it is open.
    const __afPanelScrim = createWidget(widget.BUTTON, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: 0, w: __afPanelW, h: __afPanelH, text: '',
      normal_src: '', press_src: '', click_func: function () {},
    });
    __afPanelScrim.setAlpha(0);
    __afPanelSetVisible(__afPanelScrim, false);
    const __afPanelBg = createWidget(widget.FILL_RECT, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: __afPanelTop, w: __afPanelW, h: __afPanelHeight, color: 0x111923,
    });
    __afPanelSetVisible(__afPanelBg, false);
    const __afPanelHeaderY = __afPanelTop + 2;
    const __afPanelHeaderInnerH = Math.max(20, __afPanelHeaderH - 4);
    const __afPanelHeaderBox = __afPanelRowBox(__afPanelHeaderY, __afPanelHeaderInnerH);
    // Шестерёнка слева (просто значок), крупная кнопка закрытия справа.
    // Вверху круглого экрана строка узкая, поэтому шестерёнка небольшая, а кнопке
    // закрытия отдаётся всё остальное место (она заметно шире прежней).
    const __afPanelGearW = Math.max(20, Math.min(Math.round(34 * __afPanelScale), Math.floor(__afPanelHeaderBox.w / 3)));
    const __afPanelCloseSize = Math.max(24, __afPanelHeaderBox.w - __afPanelGearW - 4);
    const __afPanelTitle = __afPanelButton(__afPanelHeaderBox.x, __afPanelHeaderY, __afPanelGearW, __afPanelHeaderInnerH, '⚙', function () {});
    const __afPanelClose = __afPanelButton(__afPanelHeaderBox.x + __afPanelHeaderBox.w - __afPanelCloseSize, __afPanelHeaderY, __afPanelCloseSize, __afPanelHeaderInnerH, '×', function () {
      __afPanelVisible = false; __afPanelRefresh();
    });
    
    const __afProfileMenu = __afPanelRowButton(__afPanelRowY, 'День и ночь  ›', function () {
      __afPanelPage = 1; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY));
    const __afProfileDetails = [];
    const __afProfileMode = __afPanelRowButton(__afPanelRowY, '', function () {
      const modes = ['auto', 'day', 'night'];
      const i = modes.indexOf(__afProfilePrefs.profileMode);
      __afProfilePrefs.profileMode = modes[(i + 1 + modes.length) % modes.length];
      __afProfileRefresh(); __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY));
    __afProfileDetails.push(__afProfileMode);
    const __afProfileStart = __afPanelTimeRow('Ночной профиль с 22:00', 'profileStart', 2, __afProfileDetails, true);
    const __afProfileEnd = __afPanelTimeRow('Дневной профиль с 07:00', 'profileEnd', 4, __afProfileDetails, true);
    const __afProfileBack = __afPanelRowButton(__afPanelRowY + 9 * __afPanelRowH, '‹ Назад', function () {
      __afPanelPage = 0; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY + 9 * __afPanelRowH));
    __afProfileDetails.push(__afProfileBack);
    function __afPanelRefresh() {
      __afPanelSetVisible(__afPanelScrim, __afPanelVisible);
      __afPanelSetVisible(__afPanelBg, __afPanelVisible);
      __afPanelSetVisible(__afPanelTitle, __afPanelVisible);
      __afPanelSetVisible(__afPanelClose, __afPanelVisible);
      
      __afPanelSetVisible(__afProfileMenu, __afPanelVisible && __afPanelPage === 0);
      __afProfileDetails.forEach(function (w) { __afPanelSetVisible(w, __afPanelVisible && __afPanelPage === 1); });
      __afPanelSetText(__afPanelTitle, '⚙', __afPanelHeaderBox.x, __afPanelHeaderY, __afPanelGearW, __afPanelHeaderInnerH);
      
      __afPanelSetRowText(__afProfileMenu, 'День и ночь  ›', __afPanelRowY, __afPanelLargeRowHeight(__afPanelRowY));
      const profileNames = { auto: 'АВТО', day: 'ДЕНЬ', night: 'НОЧЬ' };
      __afPanelSetRowText(__afProfileMode, 'Режим циферблата: ' + (profileNames[__afProfilePrefs.profileMode] || 'АВТО'), __afPanelRowY, __afPanelLargeRowHeight(__afPanelRowY));
      __afPanelSetText(__afProfileStart.value, 'Ночной профиль с ' + __afPanelHour(__afProfilePrefs.profileStart), __afProfileStart.x, __afProfileStart.y, __afProfileStart.w, __afProfileStart.h);
      __afPanelSetText(__afProfileEnd.value, 'Дневной профиль с ' + __afPanelHour(__afProfilePrefs.profileEnd), __afProfileEnd.x, __afProfileEnd.y, __afProfileEnd.w, __afProfileEnd.h);
      __afPanelSetRowText(__afProfileBack, '‹ Назад', __afPanelRowY + 9 * __afPanelRowH, __afPanelLargeRowHeight(__afPanelRowY + 9 * __afPanelRowH));
      try { __afEdRefresh(); } catch (e) {}
    }
    function __afOpenSettings() {
      __afPanelVisible = true; __afPanelPage = 0; __afPanelRefresh();
    }
    // ---- Редактор текста на часах: список -> экран редактирования выбранного текста ----
    const __afEdPath = "amazface_edits_2621279_1793898696330.json";
    const __afEdSt = {};
    let __afEdSel = 0;
    let __afEdProfile = '';
    let __afEdPrev = false;
    let __afEdStep = 2;
    let __afEdListPage = 0;
    const __afEdPerPage = 6;
    const __afEdColors = [
      0xff3b30, 0xff9500, 0xffcc00, 0x34c759, 0x00c7be, 0x0a84ff, 0xbf5af2, 0xff2d92,
      0x000000, 0xffffff, 0xd0d0d0, 0x909090, 0x8e1b14, 0xa85d00, 0x1d7a34, 0x0050a8,
    ];
    function __afEdCurrentItems() {
      const night = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night';
      return __afEd.filter(function (it) { return (String(it.id).indexOf('night:') === 0) === night; });
    }
    function __afEdLoad() {
      try {
        const result = hmFS.stat(__afEdPath);
        if (!result || result[1] !== 0 || !result[0] || result[0].size <= 0 || result[0].size > 8192) return;
        const file = hmFS.open(__afEdPath, hmFS.O_RDONLY);
        if (typeof file !== 'number' || file < 0) return;
        try {
          const bytes = new Uint8Array(result[0].size);
          hmFS.read(file, bytes.buffer, 0, bytes.length);
          const data = JSON.parse(String.fromCharCode.apply(null, bytes));
          if (!data || typeof data !== 'object') return;
          for (let i = 0; i < __afEd.length; i++) {
            const v = data[__afEd[i].id];
            if (Array.isArray(v) && v.length === 4) __afEdSt[__afEd[i].id] = [Number(v[0]) || 0, Number(v[1]) || 0, Number(v[2]) || 0, Number(v[3]) >= 0 ? Number(v[3]) : -1];
          }
        } finally { hmFS.close(file); }
      } catch (e) {}
    }
    function __afEdSave() {
      let file = -1;
      try {
        const out = {};
        for (const id in __afEdSt) {
          const v = __afEdSt[id];
          if (v[0] !== 0 || v[1] !== 0 || v[2] !== 0 || v[3] >= 0) out[id] = v;
        }
        const raw = JSON.stringify(out);
        const bytes = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) & 255;
        file = hmFS.open(__afEdPath, hmFS.O_RDWR | hmFS.O_CREAT | hmFS.O_TRUNC);
        if (typeof file === 'number' && file >= 0) hmFS.write(file, bytes.buffer, 0, bytes.length);
      } catch (e) {
      } finally {
        try { if (file >= 0) hmFS.close(file); } catch (e) {}
      }
    }
    function __afEdChanged(it) {
      const v = __afEdSt[it.id];
      return !!v && (v[0] !== 0 || v[1] !== 0 || v[2] !== 0 || v[3] >= 0);
    }
    function __afEdGeom(it) {
      const st = __afEdSt[it.id] || [0, 0, 0, -1];
      const ns = Math.max(8, Math.min(200, Math.round(it.s + st[2])));
      const nw = Math.max(1, Math.round(it.w * ns / it.s));
      const nh = Math.max(1, Math.round(it.ht * ns / it.s));
      let nx = it.x + st[0];
      if (it.ah === 'RIGHT') nx -= (nw - it.w);
      else if (it.ah !== 'LEFT') nx -= Math.floor((nw - it.w) / 2);
      const ny = it.y + st[1] - Math.floor((nh - it.ht) / 2);
      return { x: nx, y: ny, w: nw, h: nh, s: ns, c: st[3] >= 0 ? st[3] : it.c };
    }
    function __afEdApply(it) {
      const g = __afEdGeom(it);
      try { it.h.setProperty(prop.MORE, { x: g.x, y: g.y, w: g.w, h: g.h, text_size: g.s, color: g.c }); } catch (e) {}
    }
    function __afEdTouch(it) {
      return __afEdSt[it.id] || (__afEdSt[it.id] = [0, 0, 0, -1]);
    }
    function __afEdChange(k, d) {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      const st = __afEdTouch(it);
      st[k] += d;
      if (k === 2 && it.s + st[2] < 8) st[2] = 8 - it.s;
      if (k === 2 && it.s + st[2] > 200) st[2] = 200 - it.s;
      __afEdApply(it); __afEdSave(); __afPanelRefresh();
    }
    function __afEdSetColor(c) {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      __afEdTouch(it)[3] = c;
      __afEdApply(it); __afEdSave(); __afPanelRefresh();
    }
    function __afEdResetOne() {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      delete __afEdSt[it.id];
      __afEdApply(it); __afEdSave(); __afPanelRefresh();
    }
    function __afEdResetAll() {
      const items = __afEdCurrentItems();
      for (let i = 0; i < items.length; i++) { delete __afEdSt[items[i].id]; __afEdApply(items[i]); }
      __afEdSave(); __afPanelRefresh();
    }
    __afEdLoad();
    (function () { for (let i = 0; i < __afEd.length; i++) { if (__afEdSt[__afEd[i].id]) __afEdApply(__afEd[i]); } })();

    // Страница 3 — список текстов, страница 4 — редактирование выбранного.
    const __afEdListAll = [];
    const __afEdEditAll = [];
    const __afEdStatic = [];
    function __afEdBtn(list, x, y, w, h, text, click) {
      const b = __afPanelButton(x, y, w, h, text, click);
      list.push(b);
      if (text) __afEdStatic.push({ w: b, t: text, x: x, y: y, bw: w, h: h });
      return b;
    }
    function __afEdTitle(list, row, color) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const w = createWidget(widget.TEXT, {
        show_level: show_level.ONLY_NORMAL,
        x: box.x, y: y, w: box.w, h: h, text: '',
        color: color, text_size: __afPanelFont,
        align_h: align.CENTER_H, align_v: align.CENTER_V,
      });
      __afPanelSetVisible(w, false);
      list.push(w);
      return { w: w, x: box.x, y: y, bw: box.w, h: h };
    }
    function __afEdFull(list, row, text, click) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const b = __afEdBtn(list, box.x, y, box.w, h, text, click);
      return { w: b, x: box.x, y: y, bw: box.w, h: h };
    }
    // Общая ширина для нескольких строк: на круглом экране у каждой строки своя, а колонки должны быть ровными.
    function __afEdSharedBox(rows) {
      let left = 0, right = __afPanelW;
      rows.forEach(function (row) {
        const b = __afPanelRowBox(__afPanelRowY + row * __afPanelRowH, __afPanelRowH - 2);
        left = Math.max(left, b.x); right = Math.min(right, b.x + b.w);
      });
      return { x: left, w: Math.max(1, right - left) };
    }
    function __afEdHalves(list, row, textA, clickA, textB, clickB, shared) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const box = shared || __afPanelRowBox(y, h);
      const half = Math.floor((box.w - 4) / 2);
      const a = __afEdBtn(list, box.x, y, half, h, textA, clickA);
      const b = __afEdBtn(list, box.x + box.w - half, y, half, h, textB, clickB);
      return { a: a, b: b, ax: box.x, bx: box.x + box.w - half, y: y, bw: half, h: h };
    }
    function __afEdPages() { return Math.max(1, Math.ceil(__afEdCurrentItems().length / __afEdPerPage)); }

    const __afEdMenu = __afPanelRowButton(__afPanelRowY + 2 * __afPanelRowH, 'Редактор текста  ›', function () {
      __afEdSel = 0; __afEdListPage = 0; __afEdPrev = false; __afPanelPage = 3; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY + 2 * __afPanelRowH));

    // Список.
    const __afEdListTitle = __afEdTitle(__afEdListAll, 0, 0xffd60a);
    const __afEdItems = [];
    (function () {
      for (let slot = 0; slot < __afEdPerPage; slot++) {
        (function (sl) {
          const y = __afPanelRowY + (1 + sl) * __afPanelRowH;
          const h = __afPanelRowH - 2;
          const box = __afPanelRowBox(y, h);
          const b = __afEdBtn(__afEdListAll, box.x, y, box.w, h, '', function () {
            const idx = __afEdListPage * __afEdPerPage + sl;
            if (idx < __afEdCurrentItems().length) { __afEdSel = idx; __afEdPrev = false; __afPanelPage = 4; __afPanelRefresh(); }
          });
          __afEdItems.push({ w: b, x: box.x, y: y, bw: box.w, h: h });
        })(slot);
      }
    })();
    __afEdHalves(__afEdListAll, 7, '‹ Пред.', function () {
      __afEdListPage = (__afEdListPage + __afEdPages() - 1) % __afEdPages(); __afPanelRefresh();
    }, 'След. ›', function () {
      __afEdListPage = (__afEdListPage + 1) % __afEdPages(); __afPanelRefresh();
    });
    __afEdFull(__afEdListAll, 8, 'Сбросить все правки', function () { __afEdResetAll(); });
    __afEdFull(__afEdListAll, 9, '‹ Назад', function () {
      __afPanelPage = 0; __afPanelRefresh();
    });

    // Редактирование выбранного текста: две колонки крупных кнопок «−» и «+».
    const __afEdEditTitle = __afEdTitle(__afEdEditAll, 0, 0xffd60a);
    const __afEdValues = __afEdTitle(__afEdEditAll, 1, 0xffffff);
    (function () {
      const box = __afEdSharedBox([2, 3]);
      for (let r = 0; r < 2; r++) {
        const y = __afPanelRowY + (2 + r) * __afPanelRowH;
        const h = __afPanelRowH - 2;
        const gap = 2;
        const cw = Math.max(8, Math.floor((box.w - gap * 7) / 8));
        for (let c = 0; c < 8; c++) {
          (function (color) {
            const sw = createWidget(widget.BUTTON, {
              show_level: show_level.ONLY_NORMAL,
              x: box.x + c * (cw + gap), y: y, w: cw, h: h, text: '',
              normal_color: color, press_color: color,
              radius: Math.max(3, Math.round(6 * __afPanelScale)),
              click_func: function () { __afEdSetColor(color); },
            });
            __afPanelSetVisible(sw, false);
            __afEdEditAll.push(sw);
          })(__afEdColors[r * 8 + c]);
        }
      }
    })();
    const __afEdCtlBox = __afEdSharedBox([4, 5, 6]);
    __afEdHalves(__afEdEditAll, 4, '−  Размер', function () { __afEdChange(2, -__afEdStep); }, '+  Размер', function () { __afEdChange(2, __afEdStep); }, __afEdCtlBox);
    __afEdHalves(__afEdEditAll, 5, '−  X', function () { __afEdChange(0, -__afEdStep); }, '+  X', function () { __afEdChange(0, __afEdStep); }, __afEdCtlBox);
    __afEdHalves(__afEdEditAll, 6, '−  Y', function () { __afEdChange(1, -__afEdStep); }, '+  Y', function () { __afEdChange(1, __afEdStep); }, __afEdCtlBox);
    const __afEdRow7 = __afEdHalves(__afEdEditAll, 7, '', function () {
      __afEdStep = __afEdStep === 2 ? 5 : 2; __afPanelRefresh();
    }, 'Сбросить', function () { __afEdResetOne(); });
    __afEdFull(__afEdEditAll, 8, 'Показать на циферблате', function () {
      __afEdPrev = true; __afPanelRefresh();
    });
    __afEdFull(__afEdEditAll, 9, '‹ К списку', function () {
      __afPanelPage = 3; __afEdPrev = false; __afPanelRefresh();
    });
    const __afEdPrevList = [];
    const __afEdBackPrev = __afEdFull(__afEdPrevList, 9, '‹ К правкам', function () {
      __afEdPrev = false; __afPanelRefresh();
    });
    const __afEdFrame = createWidget(widget.STROKE_RECT, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: 0, w: 10, h: 10, line_width: 2, color: 0xffd60a,
    });
    __afPanelSetVisible(__afEdFrame, false);

    function __afEdCut(text, n) {
      text = String(text);
      return text.length > n ? text.slice(0, n - 1) + '.' : text;
    }
    function __afEdRefresh() {
      const vis = __afPanelVisible;
      const activeProfile = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night' ? 'night' : 'day';
      if (__afEdProfile && __afEdProfile !== activeProfile && (__afPanelPage === 3 || __afPanelPage === 4)) {
        __afPanelPage = 3; __afEdSel = 0; __afEdListPage = 0; __afEdPrev = false;
      }
      __afEdProfile = activeProfile;
      const onList = vis && __afPanelPage === 3;
      const inEd = vis && __afPanelPage === 4;
      const onEd = inEd && !__afEdPrev;
      const currentItems = __afEdCurrentItems();
      if (__afEdSel >= currentItems.length) __afEdSel = 0;
      const it = currentItems[__afEdSel];
      __afPanelSetVisible(__afEdMenu, vis && __afPanelPage === 0);
      __afEdListAll.forEach(function (w) { __afPanelSetVisible(w, onList); });
      __afEdEditAll.forEach(function (w) { __afPanelSetVisible(w, onEd); });
      __afEdPrevList.forEach(function (w) { __afPanelSetVisible(w, inEd && __afEdPrev); });
      // Рамка только в режиме просмотра: поверх панели она перекрывала бы кнопки.
      __afPanelSetVisible(__afEdFrame, inEd && __afEdPrev && !!it);
      if (inEd && __afEdPrev) {
        __afPanelSetVisible(__afPanelBg, false);
        __afPanelSetVisible(__afPanelTitle, false);
        __afPanelSetVisible(__afPanelClose, false);
      }
      __afPanelSetRowText(__afEdMenu, 'Редактор текста  ›', __afPanelRowY + 2 * __afPanelRowH, __afPanelLargeRowHeight(__afPanelRowY + 2 * __afPanelRowH));
      __afEdStatic.forEach(function (r) { __afPanelSetText(r.w, r.t, r.x, r.y, r.bw, r.h); });
      if (onList) {
        const sceneName = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night' ? 'Ночь' : 'День';
        __afPanelSetText(__afEdListTitle.w, (currentItems.length ? 'Тексты: ' : 'Нет текстов: ') + sceneName + ' ' + (__afEdListPage + 1) + '/' + __afEdPages(), __afEdListTitle.x, __afEdListTitle.y, __afEdListTitle.bw, __afEdListTitle.h);
        for (let sl = 0; sl < __afEdItems.length; sl++) {
          const idx = __afEdListPage * __afEdPerPage + sl;
          const row = __afEdItems[sl];
          const item = currentItems[idx];
          if (!item) { __afPanelSetVisible(row.w, false); continue; }
          const label = (__afEdChanged(item) ? '* ' : '') + (idx + 1) + '. ' + item.n + (item.d ? ' - ' + item.d : '');
          __afPanelSetText(row.w, __afEdCut(label, 26), row.x, row.y, row.bw, row.h);
        }
      }
      if (inEd && it) {
        const g = __afEdGeom(it);
        try { __afEdFrame.setProperty(prop.MORE, { x: g.x - 2, y: g.y - 2, w: g.w + 4, h: g.h + 4 }); } catch (e) {}
      }
      if (onEd && it) {
        const g = __afEdGeom(it);
        const st = __afEdSt[it.id] || [0, 0, 0, -1];
        const sceneTag = activeProfile === 'night' ? ' [НОЧЬ]' : ' [ДЕНЬ]';
        __afPanelSetText(__afEdEditTitle.w, __afEdCut(it.n + (it.d ? ' - ' + it.d : '') + sceneTag, 26), __afEdEditTitle.x, __afEdEditTitle.y, __afEdEditTitle.bw, __afEdEditTitle.h);
        __afPanelSetText(__afEdValues.w, 'Размер ' + g.s + '   X ' + (it.x + st[0]) + '   Y ' + (it.y + st[1]), __afEdValues.x, __afEdValues.y, __afEdValues.bw, __afEdValues.h);
        __afPanelSetText(__afEdRow7.a, 'Шаг: ' + __afEdStep + ' px', __afEdRow7.ax, __afEdRow7.y, __afEdRow7.bw, __afEdRow7.h);
      }
    }
    __afPanelRefresh();
    __afProfileRefresh();
    self._dayNightTimer = setInterval(__afProfileRefresh, 30000);
    try { createWidget(widget.WIDGET_DELEGATE, { resume_call: function () { try { __afProfileRefresh(); } catch (e) {} } }); } catch (e) {}
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._timeTimerNight) { clearInterval(this._timeTimerNight); this._timeTimerNight = null; }
    if (this._sensorTimerNight) { clearInterval(this._sensorTimerNight); this._sensorTimerNight = null; }
    if (this._smoothTimerNight) { clearInterval(this._smoothTimerNight); this._smoothTimerNight = null; }
    if (this._dayNightTimer) { clearInterval(this._dayNightTimer); this._dayNightTimer = null; }
    try { __taDestroy(); } catch (e) {}
    if (this._floatTimers) { for (let i = 0; i < this._floatTimers.length; i++) clearInterval(this._floatTimers[i]); this._floatTimers = null; }
    try { const fo = this._flashOffs || []; for (let i = 0; i < fo.length; i++) { try { fo[i](); } catch (e) {} } } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
