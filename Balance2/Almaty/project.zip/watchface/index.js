import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { launchApp, SYSTEM_APP_CALENDAR, SYSTEM_APP_HR, SYSTEM_APP_SPORT, SYSTEM_APP_STATUS, SYSTEM_APP_WEATHER } from '@zos/router'
import { Time, Battery, Step, Calorie, Barometer, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// ---- Анимация текста (AmazFace): общий рантайм --------------------------------
var __TA = { list: [], all: [], timer: 0, paused: false };
var __taFx = {};
function __taClamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function __taEase(name, t) {
  t = __taClamp(t, 0, 1);
  if (name === 'in') return t * t * t;
  if (name === 'out') { var u = 1 - t; return 1 - u * u * u; }
  if (name === 'inout') return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  return t;
}
function __taMix(c1, c2, t) {
  var r = Math.round(((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
  var g = Math.round(((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
  var b = Math.round((c1 & 255) * (1 - t) + (c2 & 255) * t);
  return (r << 16) | (g << 8) | b;
}
function __taChars(s) {
  var out = [], i = 0, n, c;
  s = String(s == null ? '' : s);
  n = s.length;
  while (i < n) {
    c = s.charCodeAt(i);
    if (c >= 0xD800 && c <= 0xDBFF && i + 1 < n) { out.push(s.substr(i, 2)); i += 2; }
    else { out.push(s.charAt(i)); i += 1; }
  }
  return out;
}
function __taParseNum(s) {
  var m = /-?\d[\d,]*(?:\.\d+)?/.exec(String(s == null ? '' : s));
  if (!m) return null;
  var tok = m[0], clean = tok.replace(/,/g, ''), dot = clean.indexOf('.');
  return { pre: String(s).slice(0, m.index), post: String(s).slice(m.index + tok.length), val: parseFloat(clean), dec: dot >= 0 ? clean.length - dot - 1 : 0, sep: tok.indexOf(',') >= 0 };
}
function __taFmtNum(n, dec, sep) {
  var s = Math.abs(n).toFixed(dec), parts;
  if (sep) { parts = s.split('.'); parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ','); s = parts.join('.'); }
  return (n < 0 && parseFloat(s.replace(/,/g, '')) !== 0 ? '-' : '') + s;
}
function __taGroups(s) {
  var out = [], re = /\d+/g, m;
  s = String(s == null ? '' : s);
  while ((m = re.exec(s)) !== null) out.push({ i: m.index, s: m[0] });
  return out;
}
function __taPhase(a, el) {
  var c = a.cfg, d = c.delay || 0, dur = Math.max(1, a.durOv || c.dur), n = c.rep || 0, gap = c.pause || 0, t, cyc, rep, q, k;
  if (a.perp) return { k: 0, e: 0, ms: Math.max(0, el), rep: 0, done: false, hold: false };
  if (el < d) return { k: 0, e: __taEase(c.ease, 0), ms: 0, rep: 0, done: false, hold: true };
  t = el - d; cyc = dur + gap;
  if (t >= n * cyc + dur) return { k: 1, e: 1, ms: dur, rep: n, done: true, hold: false };
  rep = Math.floor(t / cyc); q = t - rep * cyc; k = q >= dur ? 1 : q / dur;
  return { k: k, e: __taEase(c.ease, k), ms: q >= dur ? dur : q, rep: rep, done: false, hold: false };
}
function __taFinal(a) {
  var s = { text: a.text, color: a.base.fin, x: a.base.x, y: a.base.y, size: a.base.size, vis: true }, fx = __taFx[a.cfg.fx];
  if (fx.final) fx.final(a, s);
  return s;
}
function __taSample(a, el) {
  var ph = __taPhase(a, el), s = __taFinal(a), fx = __taFx[a.cfg.fx], o, key;
  if (ph.done) return { s: s, done: true, ph: ph };
  o = fx.frame(a, ph.k, ph);
  for (key in o) { if (Object.prototype.hasOwnProperty.call(o, key)) s[key] = o[key]; }
  return { s: s, done: false, ph: ph };
}
function __taApply(a, s) {
  var o = {}, any = false, L = a.last, cut, tx = s.text, rest;
  if (a.w2) {
    cut = tx.indexOf(a.cfg.sep);
    rest = cut >= 0 ? tx.slice(cut + a.cfg.sep.length) : '';
    if (cut >= 0) tx = tx.slice(0, cut);
    if (rest !== L.text2) { try { a.w2.setProperty(prop.MORE, { text: rest }); } catch (e1) {} L.text2 = rest; }
  }
  if (tx !== L.text) { o.text = tx; any = true; }
  if (s.color !== L.color) { o.color = s.color; any = true; }
  if (s.x !== L.x) { o.x = s.x; any = true; }
  if (s.y !== L.y) { o.y = s.y; any = true; }
  if (s.size !== L.size) { o.text_size = s.size; any = true; }
  if (a.c && s.vis !== L.vis) { try { a.c.setProperty(prop.VISIBLE, s.vis); } catch (e2) {} }
  a.last = { text: tx, text2: L.text2, color: s.color, x: s.x, y: s.y, size: s.size, vis: s.vis };
  if (any && a.w) { try { a.w.setProperty(prop.MORE, o); } catch (e3) {} }
}
function __taShow(a) { __taApply(a, __taFinal(a)); }
function __taEnsure() {
  var ms = 1000, i;
  if (__TA.timer || !__TA.list.length) return;
  for (i = 0; i < __TA.list.length; i++) { if (__TA.list[i].step < ms) ms = __TA.list[i].step; }
  __TA.timer = setInterval(__taStep, Math.max(30, ms));
}
function __taDrop(a) {
  var i = __TA.list.indexOf(a);
  if (i >= 0) __TA.list.splice(i, 1);
  if (!__TA.list.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taStep() {
  var now = Date.now(), keep = [], i, a, r, fx;
  for (i = 0; i < __TA.list.length; i++) {
    a = __TA.list[i];
    r = __taSample(a, now - a.t0);
    fx = __taFx[a.cfg.fx];
    if (r.done) { a.on = false; if (fx.done) fx.done(a); __taShow(a); }
    else { __taApply(a, r.s); keep.push(a); }
  }
  __TA.list = keep;
  if (!keep.length && __TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
}
function __taBegin(a, why) {
  var fx = __taFx[a.cfg.fx];
  a.durOv = 0;
  if (fx.init) fx.init(a, why);
  a.t0 = Date.now(); a.on = true; a.why = why;
}
function __taPlay(a, why) {
  var r;
  if (__TA.paused) return;
  if (a.on && a.cfg.retrig === 'ignore') return;
  __taBegin(a, why);
  r = __taSample(a, 0);
  __taApply(a, r.s);
  if (__TA.list.indexOf(a) < 0) __TA.list.push(a);
  __taEnsure();
}
function __taStop(a) { a.on = false; __taDrop(a); __taShow(a); }
function __taSetText(a, text) {
  var c = a.cfg, fx = __taFx[c.fx], old = a.text, changed;
  text = text == null ? '' : String(text);
  changed = text !== old;
  a.text = text;
  if (fx.live) { fx.live(a, old, text, changed); return; }
  if (!a.opened) {
    if (fx.can && !fx.can(a)) { __taShow(a); return; }
    a.opened = true;
    if (c.open) __taPlay(a, 'open'); else __taShow(a);
    return;
  }
  if (!changed) { if (!a.on) __taShow(a); return; }
  if (fx.onChange) { fx.onChange(a, old, text); return; }
  if (c.change && (!fx.can || fx.can(a))) { __taPlay(a, 'update'); return; }
  if (!a.on) __taShow(a);
}
function __taCreate(w, cfg, base, w2, cw) {
  var fx = __taFx[cfg.fx];
  var a = { w: w, w2: w2 || null, c: cw || null, cfg: cfg, base: base, text: '', t0: 0, on: false, opened: false, why: '', durOv: 0, perp: !!(fx.perp && cfg.iv < 1000), blink: 0, cnt: null, curV: null, fl: null, step: 50, last: { text: null, text2: null, color: base.fin, x: base.x, y: base.y, size: base.size, vis: true } };
  a.step = fx.step ? fx.step(cfg) : 50;
  __TA.all.push(a);
  return a;
}
function __taPause() {
  var i, a;
  __TA.paused = true;
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = [];
  for (i = 0; i < __TA.all.length; i++) { a = __TA.all[i]; a.on = false; __taShow(a); }
}
function __taResume() {
  var now = Date.now(), i, a, fx;
  __TA.paused = false;
  for (i = 0; i < __TA.all.length; i++) {
    a = __TA.all[i]; fx = __taFx[a.cfg.fx];
    if (!a.opened) continue;
    if (fx.resume) { fx.resume(a); continue; }
    if (a.cfg.wake && now - a.t0 > 800) __taPlay(a, 'wake');
  }
}
function __taDestroy() {
  if (__TA.timer) { clearInterval(__TA.timer); __TA.timer = 0; }
  __TA.list = []; __TA.all = []; __TA.paused = false;
}

__taFx.roll = {
  step: function (c) { return Math.max(30, Math.min(100, Math.round(1000 / Math.max(1, c.speed)))); },
  can: function (a) { return /\d/.test(a.text); },
  frame: function (a, k, ph) {
    var c = a.cfg, ch = __taChars(a.text), idx = [], q, n, tick, sg, w, mx, v, stopK;
    for (q = 0; q < ch.length; q++) { if (ch[q] >= '0' && ch[q] <= '9') idx.push(q); }
    n = idx.length;
    if (!n) return {};
    tick = Math.floor((ph.ms / 1000) * c.speed);
    sg = c.dir === 'down' ? -1 : 1;
    for (w = 0; w < n; w++) {
      if (c.digits === 'off' || (c.digits === 'tens' && w !== n - 2) || (c.digits === 'units' && w !== n - 1)) continue;
      stopK = c.order === 'ltr' ? (w + 1) / n : 1;
      if (k >= stopK) continue;
      mx = (c.mask && c.mask[w] !== undefined && c.mask[w] !== null) ? c.mask[w] : 9;
      v = (((tick * sg + w * 3) % (mx + 1)) + (mx + 1)) % (mx + 1);
      ch[idx[w]] = String(v);
    }
    return { text: ch.join('') };
  }
};


const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _barometer = null;
let _heart = null;

// Dual scene runtime: Normal and AOD are both exported into this one watchface.
// Zepp OS controls visibility through the documented widget show_level property.
WatchFace({
  build() {
    const self = this;

    // Normal scene widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "chatgpt_image_21_sent_2026_g_2.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_fill_rect_001 = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 92, y: 322, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_0_fill_rect_001.setAlpha(255);
          const normal_w_1_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 322, w: 80, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_2_fill_rect_002 = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 150, y: 372, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_2_fill_rect_002.setAlpha(255);
          const normal_w_3_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 322, w: 70, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_4_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 360, y: 322, w: 70, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_5_fill_rect_003 = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 294, y: 372, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_5_fill_rect_003.setAlpha(255);
          const normal_w_6_fill_rect_004 = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 420, w: 70, h: 30, radius: 0, color: 0x00133c });
          normal_w_6_fill_rect_004.setAlpha(255);
          const normal_w_7_date_full_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 147, y: 368, w: 90, h: 40, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_8_altitude_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 290, y: 368, w: 90, h: 40, text_size: 26, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_9_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 226, y: 422, w: 80, h: 30, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_10_weather_icon_001 = createWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 50, w: 64, h: 64, image_array: ["weather/0_cloudy.png", "weather/1_showers.png", "weather/2_snow_showers.png", "weather/3_sunny.png", "weather/4_overcast.png", "weather/5_light_rain.png", "weather/6_light_snow.png", "weather/7_moderate_rain.png", "weather/8_moderate_snow.png", "weather/9_heavy_snow.png", "weather/10_heavy_rain.png", "weather/11_sandstorm.png", "weather/12_rain_snow.png", "weather/13_fog.png", "weather/14_hazy.png", "weather/15_thunderstorm.png", "weather/16_snowstorm.png", "weather/17_floating_dust.png", "weather/18_very_heavy_rainstorm.png", "weather/19_rain_hail.png", "weather/20_thunderstorm_hail.png", "weather/21_heavy_rainstorm.png", "weather/22_dust.png", "weather/23_heavy_sandstorm.png", "weather/24_rainstorm.png", "weather/25_unknown.png", "weather/26_cloudy_night.png", "weather/27_showers_night.png", "weather/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 3, alpha: 255 });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 20, y: 100, w: 120, h: 40, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_w_12_text_002_w = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: -5, y: 150, w: 490, h: 80, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
          const normal_w_12_text_002_a = __taCreate(normal_w_12_text_002_w, { fx: "roll", dur: 900, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "restart", open: true, wake: false, change: false, speed: 20, dir: "up", order: "ltr", mask: [2, 9, 5, 9, 5, 9] }, { x: -5, y: 150, color: 0xffffff, fin: 0xffffff, size: 100 });
          const normal_w_12_text_002 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(normal_w_12_text_002_a, o.text); } else { normal_w_12_text_002_w.setProperty(k, o); } } };
          const normal_tap_0_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 322, w: 80, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STATUS, native: true }); } catch (e) {} } });
          normal_tap_0_tap_001.setAlpha(0);
          const normal_tap_1_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 322, w: 70, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_HR, native: true }); } catch (e) {} } });
          normal_tap_1_tap_001.setAlpha(0);
          const normal_tap_2_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 360, y: 322, w: 70, h: 30, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_SPORT, native: true }); } catch (e) {} } });
          normal_tap_2_tap_001.setAlpha(0);
          const normal_tap_3_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 147, y: 368, w: 90, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          normal_tap_3_tap_001.setAlpha(0);
          const normal_tap_4_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 50, w: 64, h: 64, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_4_tap_001.setAlpha(0);
          const normal_tap_5_tap_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 20, y: 100, w: 120, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_5_tap_001.setAlpha(0);
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            createWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _barometer = new Barometer(); } catch (e) {}
          try { _heart = new HeartRate(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_7_date_full_001.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
            normal_w_12_text_002.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", true) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_1_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_1_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heart ? _heart.getCurrent() : null;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_3_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_4_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_4_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _barometer ? _barometer.getAltitude() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_8_altitude_001.setProperty(prop.MORE, { text: "" + txt + " м" });
            } catch (e) { normal_w_8_altitude_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_9_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_9_battery_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_text_002 = createWidget(widget.TEXT, { show_level: show_level.ONLY_AOD,
          x: -5, y: 150, w: 490, h: 80, text_size: 100, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_846_SourceSansSchoolBold.ttf", text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_text_002.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", true) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __taDestroy(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
