import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time } from '@zos/sensor'
import { setInterval, clearInterval, setTimeout, clearTimeout } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    const __afProfileWidgets = { day: [], night: [] };
    const __afProfileWidgetState = new Map();
    let __afActiveProfile = '';
    function __afCreateProfileWidget(profile, id, options) {
      const w = createWidget(id, options);
      const record = { widget: w, profile: profile, visible: true };
      __afProfileWidgetState.set(w, record);
      __afProfileWidgets[profile].push(record);
      try { w.setProperty(prop.VISIBLE, profile === __afActiveProfile); } catch (e) {}
      return w;
    }
    function __afCreateDayWidget(id, options) { return __afCreateProfileWidget('day', id, options); }
    function __afCreateNightWidget(id, options) { return __afCreateProfileWidget('night', id, options); }
    function __afSetProfileVisible(w, visible) {
      const record = __afProfileWidgetState.get(w);
      if (!record) { try { w.setProperty(prop.VISIBLE, !!visible); } catch (e) {} return; }
      record.visible = !!visible;
      try { w.setProperty(prop.VISIBLE, record.visible && record.profile === __afActiveProfile); } catch (e) {}
    }
    function __afProfileApply(profile) {
      profile = profile === 'night' ? 'night' : 'day';
      if (profile === __afActiveProfile) return;
      try { const offs = self._flashOffs || []; for (let i = 0; i < offs.length; i++) { try { offs[i](); } catch (e) {} } } catch (e) {}
      __afActiveProfile = profile;
      ['day', 'night'].forEach(function (key) {
        const list = __afProfileWidgets[key] || [];
        for (let i = 0; i < list.length; i++) {
          const record = list[i];
          try { record.widget.setProperty(prop.VISIBLE, record.visible && key === profile); } catch (e) {}
        }
      });
    }
    let __afProfileTime = null;
    try { __afProfileTime = new Time(); } catch (e) {}
    function __afProfileRefresh() {
      const mode = __afProfilePrefs.profileMode || 'day';
      let target = mode === 'night' ? 'night' : 'day';
      if (mode === 'auto') {
        const now = __afProfileTime ? new Date(__afProfileTime.getTime()) : new Date();
        const hour = now.getHours();
        const start = Number(__afProfilePrefs.profileStart);
        const end = Number(__afProfilePrefs.profileEnd);
        const night = start !== end && (start < end ? hour >= start && hour < end : hour >= start || hour < end);
        target = night ? 'night' : 'day';
      }
      __afProfileApply(target);
      try { if (typeof __afPanelRefresh === 'function') __afPanelRefresh(); } catch (e) {}
    }
    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "photo_2026_11_16_22_02_00_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_text_005 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 411, y: 218, w: 60, h: 50, text_size: 36, color: 0xf6e493, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_text_006 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 219, w: 90, h: 50, text_size: 36, color: 0xf6e493, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afCreateDayWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 31, hour_posY: 172, hour_path: "strelki_hour_hand.png" });
          __afCreateDayWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 35, minute_posY: 254, minute_path: "strelki_minute_hand.png" });
          // Секундная стрелка: плавный ход не подтверждён официальной документацией
          // (⚠ unverified) — отдельный IMG сохраняет порядок слоя.
          const normal_w_second_smooth_180 = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "strelki_second_hand.png", pos_x: 203, pos_y: -23, center_x: 240, center_y: 240 });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_0_text_005.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            normal_w_1_text_006.setProperty(prop.MORE, { text: formatWeekday(now, "EEE3", "RU") });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          self._smoothTimerNormal = setInterval(() => {
            try {
              const now = _time ? new Date(_time.getTime()) : new Date();
              let deg = (now.getSeconds() + now.getMilliseconds() / 1000) * 6;
              normal_w_second_smooth_180.setProperty(prop.MORE, { angle: deg });
            } catch (e) {
              if (self._smoothTimerNormal) { clearInterval(self._smoothTimerNormal); self._smoothTimerNormal = null; }
            }
          }, 50);
      
    }

    // Night profile widgets — isolated lexical scope
    {
          const __afGrpAl_night_ = new Map(); const __afGrpP_night_ = { "group_8a4e13bad1804a4fa3a18156a7a664f5": 0 }; const __afGrpTm_night_ = {};
          function __afGrpApply_night_(g) { const l = __afGrpW_night_[g] || []; const p = __afGrpP_night_[g]; for (let i = 0; i < l.length; i++) { const a = __afGrpAl_night_.has(l[i]) ? __afGrpAl_night_.get(l[i]) : 255; try { l[i].setAlpha(Math.round(a * p)); } catch (e) {} } }
          function __afGrpSA_night_(g, w, a) { __afGrpAl_night_.set(w, a); const p = __afGrpP_night_[g]; try { w.setAlpha(p === undefined || p >= 1 ? a : Math.round(a * p)); } catch (e) {} }
          function __afGrpFade_night_(g, off, ms) { const l = __afGrpW_night_[g] || []; if (__afGrpTm_night_[g]) { clearInterval(__afGrpTm_night_[g]); __afGrpTm_night_[g] = null; } __afGrpOff_night_[g] = !!off; if (__afGrpP_night_[g] === undefined) __afGrpP_night_[g] = off ? 1 : 0; if (!off) { __afGrpApply_night_(g); for (let i = 0; i < l.length; i++) { const d = __afGrpDes_night_.has(l[i]) ? __afGrpDes_night_.get(l[i]) : true; try { __afSetProfileVisible(l[i], d); } catch (e) {} } } const N = 10; __afGrpTm_night_[g] = setInterval(function () { let p = __afGrpP_night_[g] + (off ? -1 : 1) / N; if (p < 0) p = 0; if (p > 1) p = 1; __afGrpP_night_[g] = p; __afGrpApply_night_(g); if (p === (off ? 0 : 1)) { clearInterval(__afGrpTm_night_[g]); __afGrpTm_night_[g] = null; if (off) { for (let i = 0; i < l.length; i++) { try { __afSetProfileVisible(l[i], false); } catch (e) {} } } } }, Math.max(16, Math.round(ms / N))); }
          const __afGrpW_night_ = {}; const __afGrpDes_night_ = new Map(); const __afGrpOff_night_ = { "group_8a4e13bad1804a4fa3a18156a7a664f5": true };
          function __afGrpCreate_night_(g, id, o) { const w = __afCreateNightWidget(id, o); (__afGrpW_night_[g] = __afGrpW_night_[g] || []).push(w); if (o && typeof o.alpha === 'number') __afGrpAl_night_.set(w, o.alpha); if (__afGrpP_night_[g] === 0) { try { w.setAlpha(0); } catch (e) {} } if (__afGrpOff_night_[g]) { try { __afSetProfileVisible(w, false); } catch (e) {} } return w; }
          function __afGrpVis_night_(g, w, v) { __afGrpDes_night_.set(w, !!v); try { __afSetProfileVisible(w, !!v && !__afGrpOff_night_[g]); } catch (e) {} }
          function __afGrpSet_night_(g, off) { if (__afGrpTm_night_[g]) { clearInterval(__afGrpTm_night_[g]); __afGrpTm_night_[g] = null; } if (__afGrpP_night_[g] !== undefined) { __afGrpP_night_[g] = off ? 0 : 1; if (!off) __afGrpApply_night_(g); } __afGrpOff_night_[g] = !!off; const l = __afGrpW_night_[g] || []; for (let i = 0; i < l.length; i++) { const d = __afGrpDes_night_.has(l[i]) ? __afGrpDes_night_.get(l[i]) : true; try { __afSetProfileVisible(l[i], d && !off); } catch (e) {} } }
          const __bgColor_night_ = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_night_.setAlpha(255);
          const __bgImage_night_ = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "photo_2026_11_16_22_02_00_bg_kopiya.png" });
          __bgImage_night_.setAlpha(255);
          const night_w_0_text_001 = __afGrpCreate_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT, { x: 90, y: 170, w: 110, h: 50, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const night_w_1_text_002 = __afGrpCreate_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT, { x: 90, y: 262, w: 110, h: 50, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const night_w_2_text_003 = __afGrpCreate_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT, { x: 90, y: 218, w: 110, h: 50, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const night_w_3_text_005 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 411, y: 218, w: 60, h: 50, text_size: 36, color: 0xf6e493, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const night_w_4_text_006 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 219, w: 90, h: 50, text_size: 36, color: 0xf6e493, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afCreateNightWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 31, hour_posY: 172, hour_path: "strelki_hour_hand.png" });
          __afCreateNightWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 35, minute_posY: 254, minute_path: "strelki_minute_hand.png" });
          // Секундная стрелка: плавный ход не подтверждён официальной документацией
          // (⚠ unverified) — отдельный IMG сохраняет порядок слоя.
          const night_w_second_smooth_180 = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "strelki_second_hand.png", pos_x: 203, pos_y: -23, center_x: 240, center_y: 240 });
          const night_w_5_text_008_w = __afGrpCreate_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT, { x: 290, y: 170, w: 140, h: 50, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const night_w_5_text_008_a = __taCreate(night_w_5_text_008_w, { fx: "count", dur: 1200, delay: 0, ease: "out", rep: 0, pause: 500, retrig: "restart", open: true, wake: false, change: false, track: "changed", trackSec: false, charMode: false, from: 0, to: 1000, fixed: false, dec: -1, upd: "continue" }, { x: 290, y: 170, color: 0xabd059, fin: 0xabd059, size: 36 });
          const night_w_5_text_008 = { setProperty: function (k, o) { if (o && typeof o.text === 'string') { __taSetText(night_w_5_text_008_a, o.text); } else { night_w_5_text_008_w.setProperty(k, o); } } };
          __afGrpCreate_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", widget.TEXT_FONT, { x: 350, y: 270, w: 50, h: 40, text_size: 36, color: 0xabd059, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const night_w_7_weather_icon_001 = __afCreateNightWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 283, y: 250, w: 64, h: 64, image_array: ["weather/64x64/0_cloudy.png", "weather/64x64/1_showers.png", "weather/64x64/2_snow_showers.png", "weather/64x64/3_sunny.png", "weather/64x64/4_overcast.png", "weather/64x64/5_light_rain.png", "weather/64x64/6_light_snow.png", "weather/64x64/7_moderate_rain.png", "weather/64x64/8_moderate_snow.png", "weather/64x64/9_heavy_snow.png", "weather/64x64/10_heavy_rain.png", "weather/64x64/11_sandstorm.png", "weather/64x64/12_rain_snow.png", "weather/64x64/13_fog.png", "weather/64x64/14_hazy.png", "weather/64x64/15_thunderstorm.png", "weather/64x64/16_snowstorm.png", "weather/64x64/17_floating_dust.png", "weather/64x64/18_very_heavy_rainstorm.png", "weather/64x64/19_rain_hail.png", "weather/64x64/20_thunderstorm_hail.png", "weather/64x64/21_heavy_rainstorm.png", "weather/64x64/22_dust.png", "weather/64x64/23_heavy_sandstorm.png", "weather/64x64/24_rainstorm.png", "weather/64x64/25_unknown.png", "weather/64x64/26_cloudy_night.png", "weather/64x64/27_showers_night.png", "weather/64x64/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 3, alpha: 255 });
          const night_tap_0_tap_zone_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 200, y: 280, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afGrpFade_night_("group_8a4e13bad1804a4fa3a18156a7a664f5", !__afGrpOff_night_["group_8a4e13bad1804a4fa3a18156a7a664f5"], 300); } catch (e) {} } });
          night_tap_0_tap_zone_001.setAlpha(0);
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            __afCreateNightWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __taResume(); } catch (e) {}
              },
              pause_call: function () { try { __taPause(); } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNight() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            night_w_3_text_005.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            night_w_4_text_006.setProperty(prop.MORE, { text: formatWeekday(now, "EEE3", "RU") });
          }
          _tickNight();
          self._timeTimerNight = setInterval(_tickNight, 1000);
      
          function _tickSensorsNight() {
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              night_w_0_text_001.setProperty(prop.MORE, { text: "❤️" + txt + "" });
            } catch (e) { night_w_0_text_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              night_w_1_text_002.setProperty(prop.MORE, { text: "🚶🏻‍♂️" + txt + "" });
            } catch (e) { night_w_1_text_002.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              night_w_2_text_003.setProperty(prop.MORE, { text: "🔥" + txt + "" });
            } catch (e) { night_w_2_text_003.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              night_w_5_text_008.setProperty(prop.MORE, { text: (typeof v === 'number' ? "🔋" + v + "%" : '--') });
            } catch (e) { night_w_5_text_008.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNight();
          self._sensorTimerNight = setInterval(_tickSensorsNight, 5000);
      
          self._smoothTimerNight = setInterval(() => {
            try {
              const now = _time ? new Date(_time.getTime()) : new Date();
              let deg = (now.getSeconds() + now.getMilliseconds() / 1000) * 6;
              night_w_second_smooth_180.setProperty(prop.MORE, { angle: deg });
            } catch (e) {
              if (self._smoothTimerNight) { clearInterval(self._smoothTimerNight); self._smoothTimerNight = null; }
            }
          }, 50);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 120, y: 120, w: 240, h: 100, text_size: 84, color: 0xc6ea74, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          // Плавающий текст AOD: шаг 6px, обновление раз в 1 с (⚠ unverified, см. docs/AOD_FLOAT.md)
          let aod_w_0_text_001_fl_x = 120, aod_w_0_text_001_fl_y = 120, aod_w_0_text_001_fl_dx = 1, aod_w_0_text_001_fl_dy = 1;
          function aod_w_0_text_001_fl_in(px, py) { const r = 240; const xs = [px, px + 240], ys = [py, py + 100]; for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { const dx = xs[i] - 240, dy = ys[j] - 240; if (dx * dx + dy * dy > r * r) return false; } return true; }
          function aod_w_0_text_001_fl_step() {
            try {
              const sx = 6, sy = 4;
              if (!aod_w_0_text_001_fl_in(aod_w_0_text_001_fl_x, aod_w_0_text_001_fl_y)) {
                // Старт вне допустимой области: возвращаем текст к центру экрана.
                aod_w_0_text_001_fl_x += (240 - (aod_w_0_text_001_fl_x + 240 / 2)) > 0 ? sx : -sx;
                aod_w_0_text_001_fl_y += (240 - (aod_w_0_text_001_fl_y + 100 / 2)) > 0 ? sy : -sy;
              } else {
                let nx = aod_w_0_text_001_fl_x + aod_w_0_text_001_fl_dx * sx;
                if (!aod_w_0_text_001_fl_in(nx, aod_w_0_text_001_fl_y)) { aod_w_0_text_001_fl_dx = -aod_w_0_text_001_fl_dx; nx = aod_w_0_text_001_fl_x + aod_w_0_text_001_fl_dx * sx; if (!aod_w_0_text_001_fl_in(nx, aod_w_0_text_001_fl_y)) nx = aod_w_0_text_001_fl_x; }
                let ny = aod_w_0_text_001_fl_y + aod_w_0_text_001_fl_dy * sy;
                if (!aod_w_0_text_001_fl_in(nx, ny)) { aod_w_0_text_001_fl_dy = -aod_w_0_text_001_fl_dy; ny = aod_w_0_text_001_fl_y + aod_w_0_text_001_fl_dy * sy; if (!aod_w_0_text_001_fl_in(nx, ny)) ny = aod_w_0_text_001_fl_y; }
                aod_w_0_text_001_fl_x = nx; aod_w_0_text_001_fl_y = ny;
              }
              aod_w_0_text_001.setProperty(prop.MORE, { x: Math.round(aod_w_0_text_001_fl_x), y: Math.round(aod_w_0_text_001_fl_y) });
            } catch (e) {}
          }
          (self._floatTimers = self._floatTimers || []).push(setInterval(aod_w_0_text_001_fl_step, 1000));
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_text_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
    const __afProfilePrefs = { profileMode: "auto", profileStart: 22, profileEnd: 7 };
    __afProfileRefresh();
    self._dayNightTimer = setInterval(__afProfileRefresh, 30000);
    try { createWidget(widget.WIDGET_DELEGATE, { resume_call: function () { try { __afProfileRefresh(); } catch (e) {} } }); } catch (e) {}
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._timeTimerNight) { clearInterval(this._timeTimerNight); this._timeTimerNight = null; }
    if (this._sensorTimerNight) { clearInterval(this._sensorTimerNight); this._sensorTimerNight = null; }
    if (this._smoothTimerNight) { clearInterval(this._smoothTimerNight); this._smoothTimerNight = null; }
    if (this._dayNightTimer) { clearInterval(this._dayNightTimer); this._dayNightTimer = null; }
    if (this._floatTimers) { for (let i = 0; i < this._floatTimers.length; i++) clearInterval(this._floatTimers[i]); this._floatTimers = null; }
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
