import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time } from '@zos/sensor'
import { setInterval, clearInterval, setTimeout, clearTimeout } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    const __afProfileWidgets = { day: [], night: [] };
    const __afProfileWidgetState = new Map();
    let __afActiveProfile = '';
    function __afCreateProfileWidget(profile, id, options) {
      const w = createWidget(id, options);
      const record = { widget: w, profile: profile, visible: true };
      __afProfileWidgetState.set(w, record);
      __afProfileWidgets[profile].push(record);
      try { w.setProperty(prop.VISIBLE, profile === __afActiveProfile); } catch (e) {}
      return w;
    }
    function __afCreateDayWidget(id, options) { return __afCreateProfileWidget('day', id, options); }
    function __afCreateNightWidget(id, options) { return __afCreateProfileWidget('night', id, options); }
    function __afSetProfileVisible(w, visible) {
      const record = __afProfileWidgetState.get(w);
      if (!record) { try { w.setProperty(prop.VISIBLE, !!visible); } catch (e) {} return; }
      record.visible = !!visible;
      try { w.setProperty(prop.VISIBLE, record.visible && record.profile === __afActiveProfile); } catch (e) {}
    }
    function __afProfileApply(profile) {
      profile = profile === 'night' ? 'night' : 'day';
      if (profile === __afActiveProfile) return;
      try { const offs = self._flashOffs || []; for (let i = 0; i < offs.length; i++) { try { offs[i](); } catch (e) {} } } catch (e) {}
      __afActiveProfile = profile;
      ['day', 'night'].forEach(function (key) {
        const list = __afProfileWidgets[key] || [];
        for (let i = 0; i < list.length; i++) {
          const record = list[i];
          try { record.widget.setProperty(prop.VISIBLE, record.visible && key === profile); } catch (e) {}
        }
      });
    }
    let __afProfileTime = null;
    try { __afProfileTime = new Time(); } catch (e) {}
    function __afProfileRefresh() {
      const mode = __afProfilePrefs.profileMode || 'day';
      let target = mode === 'night' ? 'night' : 'day';
      if (mode === 'auto') {
        const now = __afProfileTime ? new Date(__afProfileTime.getTime()) : new Date();
        const hour = now.getHours();
        const start = Number(__afProfilePrefs.profileStart);
        const end = Number(__afProfilePrefs.profileEnd);
        const night = start !== end && (start < end ? hour >= start && hour < end : hour >= start || hour < end);
        target = night ? 'night' : 'day';
      }
      __afProfileApply(target);
      try { if (typeof __afPanelRefresh === 'function') __afPanelRefresh(); } catch (e) {}
    }
    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "kristallicheskiy_zakat_nad_siluetami_derevev_1_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_text_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 155, y: 132, w: 170, h: 90, text_size: 90, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          const normal_w_1_text_002 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 243, y: 140, w: 170, h: 90, text_size: 60, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_1_text_002.setAlpha(133); } catch (e) {}
          const normal_w_2_text_003 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 142, w: 170, h: 90, text_size: 50, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_2_text_003.setAlpha(133); } catch (e) {}
          const normal_w_3_text_004 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 370, y: 145, w: 170, h: 90, text_size: 40, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_3_text_004.setAlpha(133); } catch (e) {}
          const normal_w_4_text_005 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 68, y: 140, w: 170, h: 90, text_size: 60, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_4_text_005.setAlpha(133); } catch (e) {}
          const normal_w_5_text_006 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 3, y: 142, w: 170, h: 90, text_size: 50, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_5_text_006.setAlpha(133); } catch (e) {}
          const normal_w_6_text_007 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: -50, y: 145, w: 170, h: 90, text_size: 40, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_6_text_007.setAlpha(133); } catch (e) {}
          const normal_w_7_text_008 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: -50, y: 195, w: 170, h: 90, text_size: 20, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_7_text_008.setAlpha(133); } catch (e) {}
          const normal_w_8_text_009 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 5, y: 195, w: 170, h: 90, text_size: 30, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_8_text_009.setAlpha(133); } catch (e) {}
          const normal_w_9_text_010 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 70, y: 195, w: 170, h: 90, text_size: 40, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_9_text_010.setAlpha(133); } catch (e) {}
          const normal_w_10_text_011 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 370, y: 195, w: 170, h: 90, text_size: 30, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_10_text_011.setAlpha(133); } catch (e) {}
          const normal_w_11_text_012 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 195, w: 170, h: 90, text_size: 30, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_11_text_012.setAlpha(133); } catch (e) {}
          const normal_w_12_text_013 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 240, y: 195, w: 170, h: 90, text_size: 40, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { normal_w_12_text_013.setAlpha(133); } catch (e) {}
          const normal_w_13_text_014 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 155, y: 220, w: 170, h: 90, text_size: 90, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_0_text_001.setProperty(prop.MORE, { text: formatHour(now, "HH", false) });
            normal_w_1_text_002.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + 3600000), "HH", true) });
            normal_w_2_text_003.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + 7200000), "HH", true) });
            normal_w_3_text_004.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + 10800000), "HH", true) });
            normal_w_4_text_005.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + -3600000), "HH", true) });
            normal_w_5_text_006.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + -7200000), "HH", true) });
            normal_w_6_text_007.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + -10800000), "HH", true) });
            normal_w_7_text_008.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 57) % 60, true) });
            normal_w_8_text_009.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 58) % 60, true) });
            normal_w_9_text_010.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 59) % 60, true) });
            normal_w_10_text_011.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 3) % 60, true) });
            normal_w_11_text_012.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 2) % 60, true) });
            normal_w_12_text_013.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 1) % 60, true) });
            normal_w_13_text_014.setProperty(prop.MORE, { text: formatUnit(now.getMinutes(), false) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
    }

    // Night profile widgets — isolated lexical scope
    {
          const __bgColor_night_ = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_night_.setAlpha(255);
          const __bgImage_night_ = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "zvezdnaya_noch_nad_gornym_lesom_1_bg.png" });
          __bgImage_night_.setAlpha(255);
          const night_w_0_text_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 155, y: 132, w: 170, h: 90, text_size: 90, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          const night_w_1_text_002 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 243, y: 140, w: 170, h: 90, text_size: 60, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_1_text_002.setAlpha(133); } catch (e) {}
          const night_w_2_text_003 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 142, w: 170, h: 90, text_size: 50, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_2_text_003.setAlpha(133); } catch (e) {}
          const night_w_3_text_004 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 370, y: 145, w: 170, h: 90, text_size: 40, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_3_text_004.setAlpha(133); } catch (e) {}
          const night_w_4_text_005 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 68, y: 140, w: 170, h: 90, text_size: 60, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_4_text_005.setAlpha(133); } catch (e) {}
          const night_w_5_text_006 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 3, y: 142, w: 170, h: 90, text_size: 50, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_5_text_006.setAlpha(133); } catch (e) {}
          const night_w_6_text_007 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: -50, y: 145, w: 170, h: 90, text_size: 40, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_6_text_007.setAlpha(133); } catch (e) {}
          const night_w_7_text_008 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: -50, y: 195, w: 170, h: 90, text_size: 20, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_7_text_008.setAlpha(133); } catch (e) {}
          const night_w_8_text_009 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 5, y: 195, w: 170, h: 90, text_size: 30, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_8_text_009.setAlpha(133); } catch (e) {}
          const night_w_9_text_010 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 70, y: 195, w: 170, h: 90, text_size: 40, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_9_text_010.setAlpha(133); } catch (e) {}
          const night_w_10_text_011 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 370, y: 195, w: 170, h: 90, text_size: 30, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_10_text_011.setAlpha(133); } catch (e) {}
          const night_w_11_text_012 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 195, w: 170, h: 90, text_size: 30, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_11_text_012.setAlpha(133); } catch (e) {}
          const night_w_12_text_013 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 240, y: 195, w: 170, h: 90, text_size: 40, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          try { night_w_12_text_013.setAlpha(133); } catch (e) {}
          const night_w_13_text_014 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 155, y: 220, w: 170, h: 90, text_size: 90, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickNight() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            night_w_0_text_001.setProperty(prop.MORE, { text: formatHour(now, "HH", false) });
            night_w_1_text_002.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + 3600000), "HH", true) });
            night_w_2_text_003.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + 7200000), "HH", true) });
            night_w_3_text_004.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + 10800000), "HH", true) });
            night_w_4_text_005.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + -3600000), "HH", true) });
            night_w_5_text_006.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + -7200000), "HH", true) });
            night_w_6_text_007.setProperty(prop.MORE, { text: formatHour(new Date(now.getTime() + -10800000), "HH", true) });
            night_w_7_text_008.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 57) % 60, true) });
            night_w_8_text_009.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 58) % 60, true) });
            night_w_9_text_010.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 59) % 60, true) });
            night_w_10_text_011.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 3) % 60, true) });
            night_w_11_text_012.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 2) % 60, true) });
            night_w_12_text_013.setProperty(prop.MORE, { text: formatUnit((now.getMinutes() + 1) % 60, true) });
            night_w_13_text_014.setProperty(prop.MORE, { text: formatUnit(now.getMinutes(), false) });
          }
          _tickNight();
          self._timeTimerNight = setInterval(_tickNight, 1000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 155, y: 132, w: 170, h: 90, text_size: 90, color: 0x636363, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
          const aod_w_1_text_014 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 155, y: 220, w: 170, h: 90, text_size: 90, color: 0x636363, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_454d56e292cd4511907e9356a2f04e3b_Roboto-VariableFont_wdth_wght.ttf", text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_text_001.setProperty(prop.MORE, { text: formatHour(now, "HH", false) });
            aod_w_1_text_014.setProperty(prop.MORE, { text: formatUnit(now.getMinutes(), false) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
    const __afProfilePrefs = { profileMode: "auto", profileStart: 22, profileEnd: 7 };
    __afProfileRefresh();
    self._dayNightTimer = setInterval(__afProfileRefresh, 30000);
    try { createWidget(widget.WIDGET_DELEGATE, { resume_call: function () { try { __afProfileRefresh(); } catch (e) {} } }); } catch (e) {}
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._timeTimerNight) { clearInterval(this._timeTimerNight); this._timeTimerNight = null; }
    if (this._sensorTimerNight) { clearInterval(this._sensorTimerNight); this._sensorTimerNight = null; }
    if (this._smoothTimerNight) { clearInterval(this._smoothTimerNight); this._smoothTimerNight = null; }
    if (this._dayNightTimer) { clearInterval(this._dayNightTimer); this._dayNightTimer = null; }
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
